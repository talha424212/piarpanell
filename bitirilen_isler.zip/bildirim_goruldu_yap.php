<?php
session_start();

if (!isset($_SESSION['kullanici'])) {
    http_response_code(403);
    echo json_encode(['ok' => false, 'hata' => 'Yetkisiz']);
    exit;
}

require_once 'baglan.php'; // $db değişkenini buradan alıyoruz

try {
    $calisan_id = $_SESSION['kullanici']['id'];

    $stmt = $db->prepare("UPDATE isler SET islerim_goruldu = 1 WHERE calisan_id = ?");
    $stmt->execute([$calisan_id]);

    echo json_encode(['ok' => true]);
} catch (PDOException $e) {
    echo json_encode(['ok' => false, 'hata' => $e->getMessage()]);
}
