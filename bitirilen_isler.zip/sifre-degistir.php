<?php
session_start();
require_once 'baglan.php';

// Kullanıcı girişi kontrolü
if (!isset($_SESSION['kullanici'])) {
    header('Location: giris.php');
    exit;
}

$kullanici = $_SESSION['kullanici'];
$kullanici_id = $kullanici['id'] ?? $kullanici['kullanici_id'] ?? null;

if (!$kullanici_id) {
    header('Location: giris.php');
    exit;
}

// Kullanıcı bilgilerini al
$sql = "SELECT * FROM kullanicilar WHERE id = ?";
$stmt = $db->prepare($sql);
$stmt->execute([$kullanici_id]);
$kullanici_bilgi = $stmt->fetch(PDO::FETCH_ASSOC);

// Şifre değiştirme işlemi
if (isset($_POST['sifre_degistir'])) {
    $mevcut_sifre = $_POST['mevcut_sifre'];
    $yeni_sifre = $_POST['yeni_sifre'];
    $yeni_sifre_tekrar = $_POST['yeni_sifre_tekrar'];
    
    // Mevcut şifreyi kontrol et
    if ($mevcut_sifre !== $kullanici_bilgi['sifre']) {
        $mesaj = "Mevcut şifreniz yanlış!";
        $mesaj_tip = "error";
    }
    // Yeni şifrelerin eşleşip eşleşmediğini kontrol et
    elseif ($yeni_sifre !== $yeni_sifre_tekrar) {
        $mesaj = "Yeni şifreler eşleşmiyor!";
        $mesaj_tip = "error";
    }
    // Şifre uzunluğunu kontrol et
    elseif (strlen($yeni_sifre) < 6) {
        $mesaj = "Yeni şifre en az 6 karakter olmalıdır!";
        $mesaj_tip = "error";
    }
    else {
        // Şifreyi güncelle
        $sql = "UPDATE kullanicilar SET sifre = ? WHERE id = ?";
        $stmt = $db->prepare($sql);
        
        if ($stmt->execute([$yeni_sifre, $kullanici_id])) {
            $mesaj = "Şifreniz başarıyla değiştirildi!";
            $mesaj_tip = "success";
            
            // Kullanıcı bilgilerini güncelle
            $kullanici_bilgi['sifre'] = $yeni_sifre;
        } else {
            $mesaj = "Bir hata oluştu!";
            $mesaj_tip = "error";
        }
    }
}
?>

<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Şifre Değiştir - Piar Panel</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.6/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
    <style>
        :root {
            --primary-gradient: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            --secondary-gradient: linear-gradient(135deg, #f093fb 0%, #f5576c 100%);
            --success-gradient: linear-gradient(135deg, #4facfe 0%, #00f2fe 100%);
            --warning-gradient: linear-gradient(135deg, #43e97b 0%, #38f9d7 100%);
            --danger-gradient: linear-gradient(135deg, #fa709a 0%, #fee140 100%);
            --glass-bg: rgba(255, 255, 255, 0.1);
            --glass-border: rgba(255, 255, 255, 0.2);
        }

        body {
            background: var(--primary-gradient);
            min-height: 100vh;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            overflow-x: hidden;
        }

        .particles {
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            pointer-events: none;
            z-index: 1;
        }

        .particle {
            position: absolute;
            background: rgba(255, 255, 255, 0.1);
            border-radius: 50%;
            animation: float 6s ease-in-out infinite;
        }

        @keyframes float {
            0%, 100% { transform: translateY(0px) rotate(0deg); }
            50% { transform: translateY(-20px) rotate(180deg); }
        }

        .main-container {
            position: relative;
            z-index: 2;
            padding: 20px;
        }

        .page-header {
            background: var(--glass-bg);
            backdrop-filter: blur(20px);
            border: 1px solid var(--glass-border);
            border-radius: 20px;
            padding: 30px;
            margin-bottom: 30px;
            box-shadow: 0 8px 32px rgba(0, 0, 0, 0.1);
        }

        .page-title {
            color: white;
            font-size: 2.5rem;
            font-weight: 700;
            margin: 0;
            text-shadow: 0 2px 4px rgba(0, 0, 0, 0.3);
        }

        .page-subtitle {
            color: rgba(255, 255, 255, 0.8);
            font-size: 1.1rem;
            margin: 10px 0 0 0;
        }

        .content-container {
            background: var(--glass-bg);
            backdrop-filter: blur(20px);
            border: 1px solid var(--glass-border);
            border-radius: 20px;
            padding: 30px;
            margin-bottom: 30px;
            box-shadow: 0 8px 32px rgba(0, 0, 0, 0.1);
            max-width: 600px;
            margin-left: auto;
            margin-right: auto;
        }

        .section-title {
            color: white;
            font-size: 1.5rem;
            font-weight: 600;
            margin-bottom: 25px;
            display: flex;
            align-items: center;
            gap: 10px;
        }

        .btn-modern {
            background: var(--glass-bg);
            backdrop-filter: blur(20px);
            border: 1px solid var(--glass-border);
            color: white;
            padding: 12px 25px;
            border-radius: 15px;
            font-weight: 500;
            transition: all 0.3s ease;
            text-decoration: none;
            display: inline-flex;
            align-items: center;
            gap: 8px;
        }

        .btn-modern:hover {
            background: rgba(255, 255, 255, 0.2);
            color: white;
            transform: translateY(-2px);
            box-shadow: 0 5px 15px rgba(0, 0, 0, 0.2);
        }

        .btn-success-modern {
            background: var(--success-gradient);
            border: none;
        }

        .btn-warning-modern {
            background: var(--warning-gradient);
            border: none;
        }

        .form-control {
            background: var(--glass-bg);
            backdrop-filter: blur(20px);
            border: 1px solid var(--glass-border);
            color: white;
            border-radius: 15px;
            padding: 12px 15px;
        }

        .form-control:focus {
            background: rgba(255, 255, 255, 0.15);
            border-color: rgba(255, 255, 255, 0.5);
            color: white;
            box-shadow: 0 0 0 0.2rem rgba(255, 255, 255, 0.25);
        }

        .form-control::placeholder {
            color: rgba(255, 255, 255, 0.6);
        }

        .form-label {
            color: white;
            font-weight: 500;
            margin-bottom: 8px;
        }

        .alert-modern {
            background: var(--glass-bg);
            backdrop-filter: blur(20px);
            border: 1px solid var(--glass-border);
            border-radius: 15px;
            color: white;
        }

        .alert-success {
            border-left: 4px solid #4facfe;
        }

        .alert-error {
            border-left: 4px solid #fa709a;
        }

        .password-strength {
            margin-top: 10px;
            padding: 10px;
            border-radius: 10px;
            font-size: 0.9rem;
        }

        .strength-weak {
            background: rgba(255, 107, 107, 0.2);
            color: #ff6b6b;
            border: 1px solid rgba(255, 107, 107, 0.3);
        }

        .strength-medium {
            background: rgba(255, 193, 7, 0.2);
            color: #ffc107;
            border: 1px solid rgba(255, 193, 7, 0.3);
        }

        .strength-strong {
            background: rgba(40, 167, 69, 0.2);
            color: #28a745;
            border: 1px solid rgba(40, 167, 69, 0.3);
        }

        .security-tips {
            background: var(--glass-bg);
            backdrop-filter: blur(20px);
            border: 1px solid var(--glass-border);
            border-radius: 15px;
            padding: 20px;
            margin-top: 20px;
        }

        .security-tips h5 {
            color: white;
            margin-bottom: 15px;
        }

        .security-tips ul {
            color: rgba(255, 255, 255, 0.8);
            margin: 0;
            padding-left: 20px;
        }

        .security-tips li {
            margin-bottom: 8px;
        }

        @media (max-width: 768px) {
            .page-title {
                font-size: 2rem;
            }
            
            .content-container {
                padding: 20px;
                margin: 0 10px 30px 10px;
            }
        }
    </style>
</head>
<body>
    <div id="particles" class="particles"></div>
    
    <?php include 'parcalar/sidebar.php'; ?>
    <?php include 'parcalar/navbar.php'; ?>
    
    <div class="main-content">
        <div class="main-container">
            <div class="page-header">
                <h1 class="page-title">
                    <i class="fas fa-key me-3"></i>
                    Şifre Değiştir
                </h1>
                <p class="page-subtitle">Hesap güvenliğiniz için şifrenizi güncelleyin</p>
            </div>

            <?php if (isset($mesaj)): ?>
            <div class="alert alert-modern alert-<?= $mesaj_tip ?> alert-dismissible fade show" role="alert" style="max-width: 600px; margin: 0 auto 30px auto;">
                <i class="fas fa-<?= $mesaj_tip === 'success' ? 'check-circle' : 'exclamation-triangle' ?> me-2"></i>
                <?= $mesaj ?>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="alert"></button>
            </div>
            <?php endif; ?>

            <div class="content-container">
                <h2 class="section-title">
                    <i class="fas fa-lock"></i>
                    Şifre Değiştirme
                </h2>
                
                <form method="POST" action="" id="sifreForm">
                    <div class="mb-3">
                        <label class="form-label">
                            <i class="fas fa-lock me-2"></i>
                            Mevcut Şifre
                        </label>
                        <input type="password" name="mevcut_sifre" class="form-control" required>
                    </div>
                    
                    <div class="mb-3">
                        <label class="form-label">
                            <i class="fas fa-key me-2"></i>
                            Yeni Şifre
                        </label>
                        <input type="password" name="yeni_sifre" class="form-control" id="yeniSifre" required>
                        <div id="passwordStrength" class="password-strength" style="display: none;"></div>
                    </div>
                    
                    <div class="mb-3">
                        <label class="form-label">
                            <i class="fas fa-key me-2"></i>
                            Yeni Şifre (Tekrar)
                        </label>
                        <input type="password" name="yeni_sifre_tekrar" class="form-control" id="yeniSifreTekrar" required>
                    </div>
                    
                    <div class="d-grid gap-2">
                        <button type="submit" name="sifre_degistir" class="btn btn-modern btn-success-modern">
                            <i class="fas fa-save me-2"></i>
                            Şifreyi Değiştir
                        </button>
                        <a href="profil.php" class="btn btn-modern">
                            <i class="fas fa-arrow-left me-2"></i>
                            Geri Dön
                        </a>
                    </div>
                </form>

                <div class="security-tips">
                    <h5>
                        <i class="fas fa-shield-alt me-2"></i>
                        Güvenlik İpuçları
                    </h5>
                    <ul>
                        <li>Şifreniz en az 6 karakter uzunluğunda olmalıdır</li>
                        <li>Büyük ve küçük harfler, rakamlar ve özel karakterler kullanın</li>
                        <li>Kişisel bilgilerinizi şifre olarak kullanmayın</li>
                        <li>Şifrenizi kimseyle paylaşmayın</li>
                        <li>Düzenli olarak şifrenizi değiştirin</li>
                    </ul>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.6/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/gsap/3.12.2/gsap.min.js"></script>
    
    <script>
        // Floating particles
        function createParticles() {
            const particlesContainer = document.getElementById('particles');
            const particleCount = 50;
            
            for (let i = 0; i < particleCount; i++) {
                const particle = document.createElement('div');
                particle.className = 'particle';
                particle.style.width = Math.random() * 10 + 5 + 'px';
                particle.style.height = particle.style.width;
                particle.style.left = Math.random() * 100 + '%';
                particle.style.top = Math.random() * 100 + '%';
                particle.style.animationDelay = Math.random() * 6 + 's';
                particle.style.animationDuration = (Math.random() * 3 + 3) + 's';
                particlesContainer.appendChild(particle);
            }
        }

        // GSAP Animations
        function initAnimations() {
            gsap.from('.page-header', {
                duration: 1,
                y: -50,
                opacity: 0,
                ease: "power2.out"
            });

            gsap.from('.content-container', {
                duration: 0.8,
                y: 30,
                opacity: 0,
                ease: "power2.out",
                delay: 0.3
            });
        }

        // Şifre gücü kontrolü
        function checkPasswordStrength(password) {
            const strengthDiv = document.getElementById('passwordStrength');
            
            if (password.length === 0) {
                strengthDiv.style.display = 'none';
                return;
            }
            
            let strength = 0;
            let feedback = '';
            
            if (password.length >= 6) strength++;
            if (password.length >= 8) strength++;
            if (/[a-z]/.test(password)) strength++;
            if (/[A-Z]/.test(password)) strength++;
            if (/[0-9]/.test(password)) strength++;
            if (/[^A-Za-z0-9]/.test(password)) strength++;
            
            if (strength <= 2) {
                feedback = 'Zayıf şifre';
                strengthDiv.className = 'password-strength strength-weak';
            } else if (strength <= 4) {
                feedback = 'Orta güçlükte şifre';
                strengthDiv.className = 'password-strength strength-medium';
            } else {
                feedback = 'Güçlü şifre';
                strengthDiv.className = 'password-strength strength-strong';
            }
            
            strengthDiv.textContent = feedback;
            strengthDiv.style.display = 'block';
        }

        // Şifre eşleşme kontrolü
        function checkPasswordMatch() {
            const password = document.getElementById('yeniSifre').value;
            const confirmPassword = document.getElementById('yeniSifreTekrar').value;
            const submitBtn = document.querySelector('button[type="submit"]');
            
            if (confirmPassword && password !== confirmPassword) {
                document.getElementById('yeniSifreTekrar').style.borderColor = '#fa709a';
                submitBtn.disabled = true;
            } else {
                document.getElementById('yeniSifreTekrar').style.borderColor = 'rgba(255, 255, 255, 0.2)';
                submitBtn.disabled = false;
            }
        }

        // Event listeners
        document.getElementById('yeniSifre').addEventListener('input', function() {
            checkPasswordStrength(this.value);
            checkPasswordMatch();
        });

        document.getElementById('yeniSifreTekrar').addEventListener('input', checkPasswordMatch);

        // Initialize
        document.addEventListener('DOMContentLoaded', function() {
            createParticles();
            initAnimations();
        });
    </script>
</body>
</html> 