<?php
session_start();
require_once 'baglan.php';
header('Content-Type: application/json');

if (!isset($_SESSION['kullanici']['id'])) {
    echo json_encode(['ok' => false, 'error' => 'Giriş gerekli.']);
    exit;
}
$kullanici_id = $_SESSION['kullanici']['id'];

try {
    // Sadece mevcut kullanıcıya ait olan ve okunmamış bildirimleri "görüldü" (1) olarak işaretle.
    $sql = "
        UPDATE etkinlikler e
        JOIN etkinlik_atananlar ea ON e.id = ea.etkinlik_id
        SET e.bildirim_goruldu = 1
        WHERE ea.kullanici_id = ? AND e.bildirim_goruldu = 0
    ";
    $stmt = $db->prepare($sql);
    $stmt->execute([$kullanici_id]);

    echo json_encode(['ok' => true, 'etkilenen_satir' => $stmt->rowCount()]);

} catch (Exception $e) {
    echo json_encode(['ok' => false, 'error' => 'Güncelleme sırasında hata oluştu.']);
}
?>