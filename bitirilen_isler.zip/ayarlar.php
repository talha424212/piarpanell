<?php
session_start();
require_once 'baglan.php';

// Kullanıcı girişi kontrolü
if (!isset($_SESSION['kullanici'])) {
    header('Location: giris.php');
    exit;
}

$kullanici = $_SESSION['kullanici'];
$kullanici_id = $kullanici['id'] ?? $kullanici['kullanici_id'] ?? null;

if (!$kullanici_id) {
    header('Location: giris.php');
    exit;
}

// Kullanıcı bilgilerini al
$sql = "SELECT * FROM kullanicilar WHERE id = ?";
$stmt = $db->prepare($sql);
$stmt->execute([$kullanici_id]);
$kullanici_bilgi = $stmt->fetch(PDO::FETCH_ASSOC);

// Ayarları güncelleme işlemi
if (isset($_POST['ayarlar_guncelle'])) {
    $islerimler = isset($_POST['islerimler']) ? 1 : 0;
    $email_islerimleri = isset($_POST['email_islerimleri']) ? 1 : 0;
    $tema = $_POST['tema'];
    $dil = $_POST['dil'];
    $zaman_dilimi = $_POST['zaman_dilimi'];
    
    // Ayarları veritabanında sakla (eğer ayarlar tablosu varsa)
    // Bu örnekte session'da saklıyoruz
    $_SESSION['user_settings'] = [
        'islerimler' => $islerimler,
        'email_islerimleri' => $email_islerimleri,
        'tema' => $tema,
        'dil' => $dil,
        'zaman_dilimi' => $zaman_dilimi
    ];
    
    $mesaj = "Ayarlarınız başarıyla güncellendi!";
    $mesaj_tip = "success";
}

// Mevcut ayarları al
$current_settings = $_SESSION['user_settings'] ?? [
    'islerimler' => 1,
    'email_islerimleri' => 1,
    'tema' => 'auto',
    'dil' => 'tr',
    'zaman_dilimi' => 'Europe/Istanbul'
];
?>

<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Ayarlar - Piar Panel</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.6/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
    <style>
        :root {
            --primary-gradient: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            --secondary-gradient: linear-gradient(135deg, #f093fb 0%, #f5576c 100%);
            --success-gradient: linear-gradient(135deg, #4facfe 0%, #00f2fe 100%);
            --warning-gradient: linear-gradient(135deg, #43e97b 0%, #38f9d7 100%);
            --danger-gradient: linear-gradient(135deg, #fa709a 0%, #fee140 100%);
            --glass-bg: rgba(255, 255, 255, 0.1);
            --glass-border: rgba(255, 255, 255, 0.2);
        }

        body {
            background: var(--primary-gradient);
            min-height: 100vh;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            overflow-x: hidden;
        }

        .particles {
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            pointer-events: none;
            z-index: 1;
        }

        .particle {
            position: absolute;
            background: rgba(255, 255, 255, 0.1);
            border-radius: 50%;
            animation: float 6s ease-in-out infinite;
        }

        @keyframes float {
            0%, 100% { transform: translateY(0px) rotate(0deg); }
            50% { transform: translateY(-20px) rotate(180deg); }
        }

        .main-container {
            position: relative;
            z-index: 2;
            padding: 20px;
        }

        .page-header {
            background: var(--glass-bg);
            backdrop-filter: blur(20px);
            border: 1px solid var(--glass-border);
            border-radius: 20px;
            padding: 30px;
            margin-bottom: 30px;
            box-shadow: 0 8px 32px rgba(0, 0, 0, 0.1);
        }

        .page-title {
            color: white;
            font-size: 2.5rem;
            font-weight: 700;
            margin: 0;
            text-shadow: 0 2px 4px rgba(0, 0, 0, 0.3);
        }

        .page-subtitle {
            color: rgba(255, 255, 255, 0.8);
            font-size: 1.1rem;
            margin: 10px 0 0 0;
        }

        .content-container {
            background: var(--glass-bg);
            backdrop-filter: blur(20px);
            border: 1px solid var(--glass-border);
            border-radius: 20px;
            padding: 30px;
            margin-bottom: 30px;
            box-shadow: 0 8px 32px rgba(0, 0, 0, 0.1);
        }

        .section-title {
            color: white;
            font-size: 1.5rem;
            font-weight: 600;
            margin-bottom: 25px;
            display: flex;
            align-items: center;
            gap: 10px;
        }

        .btn-modern {
            background: var(--glass-bg);
            backdrop-filter: blur(20px);
            border: 1px solid var(--glass-border);
            color: white;
            padding: 12px 25px;
            border-radius: 15px;
            font-weight: 500;
            transition: all 0.3s ease;
            text-decoration: none;
            display: inline-flex;
            align-items: center;
            gap: 8px;
        }

        .btn-modern:hover {
            background: rgba(255, 255, 255, 0.2);
            color: white;
            transform: translateY(-2px);
            box-shadow: 0 5px 15px rgba(0, 0, 0, 0.2);
        }

        .btn-success-modern {
            background: var(--success-gradient);
            border: none;
        }

        .form-control, .form-select {
            background: var(--glass-bg);
            backdrop-filter: blur(20px);
            border: 1px solid var(--glass-border);
            color: white;
            border-radius: 15px;
            padding: 12px 15px;
        }

        .form-control:focus, .form-select:focus {
            background: rgba(255, 255, 255, 0.15);
            border-color: rgba(255, 255, 255, 0.5);
            color: white;
            box-shadow: 0 0 0 0.2rem rgba(255, 255, 255, 0.25);
        }

        .form-label {
            color: white;
            font-weight: 500;
            margin-bottom: 8px;
        }

        .form-check {
            margin-bottom: 15px;
        }

        .form-check-input {
            background-color: var(--glass-bg);
            border: 1px solid var(--glass-border);
            border-radius: 10px;
        }

        .form-check-input:checked {
            background-color: #4facfe;
            border-color: #4facfe;
        }

        .form-check-label {
            color: white;
            font-weight: 500;
        }

        .alert-modern {
            background: var(--glass-bg);
            backdrop-filter: blur(20px);
            border: 1px solid var(--glass-border);
            border-radius: 15px;
            color: white;
        }

        .alert-success {
            border-left: 4px solid #4facfe;
        }

        .setting-card {
            background: rgba(255, 255, 255, 0.05);
            border: 1px solid var(--glass-border);
            border-radius: 15px;
            padding: 20px;
            margin-bottom: 20px;
            transition: all 0.3s ease;
        }

        .setting-card:hover {
            background: rgba(255, 255, 255, 0.1);
            transform: translateY(-2px);
        }

        .setting-icon {
            width: 50px;
            height: 50px;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 1.2rem;
            color: white;
            margin-bottom: 15px;
        }

        .icon-notifications { background: var(--success-gradient); }
        .icon-appearance { background: var(--secondary-gradient); }
        .icon-language { background: var(--warning-gradient); }
        .icon-security { background: var(--danger-gradient); }

        .theme-preview {
            width: 60px;
            height: 40px;
            border-radius: 10px;
            border: 2px solid transparent;
            cursor: pointer;
            transition: all 0.3s ease;
        }

        .theme-preview:hover {
            transform: scale(1.1);
        }

        .theme-preview.active {
            border-color: #4facfe;
        }

        .theme-light {
            background: linear-gradient(135deg, #f8f9fa 0%, #e9ecef 100%);
        }

        .theme-dark {
            background: linear-gradient(135deg, #343a40 0%, #212529 100%);
        }

        .theme-auto {
            background: linear-gradient(135deg, #f8f9fa 0%, #343a40 100%);
        }

        @media (max-width: 768px) {
            .page-title {
                font-size: 2rem;
            }
            
            .content-container {
                padding: 20px;
            }
        }
    </style>
</head>
<body>
    <div id="particles" class="particles"></div>
    
    <?php include 'parcalar/sidebar.php'; ?>
    <?php include 'parcalar/navbar.php'; ?>
    
    <div class="main-content">
        <div class="main-container">
            <div class="page-header">
                <h1 class="page-title">
                    <i class="fas fa-cog me-3"></i>
                    Ayarlar
                </h1>
                <p class="page-subtitle">Hesap ayarlarınızı yönetin ve kişiselleştirin</p>
            </div>

            <?php if (isset($mesaj)): ?>
            <div class="alert alert-modern alert-<?= $mesaj_tip ?> alert-dismissible fade show" role="alert">
                <i class="fas fa-<?= $mesaj_tip === 'success' ? 'check-circle' : 'exclamation-triangle' ?> me-2"></i>
                <?= $mesaj ?>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="alert"></button>
            </div>
            <?php endif; ?>

            <form method="POST" action="">
                <div class="content-container">
                    <h2 class="section-title">
                        <i class="fas fa-bell"></i>
                        islerim Ayarları
                    </h2>
                    
                    <div class="setting-card">
                        <div class="setting-icon icon-notifications">
                            <i class="fas fa-bell"></i>
                        </div>
                        <div class="form-check form-switch">
                            <input class="form-check-input" type="checkbox" name="islerimler" id="islerimler" 
                                   <?= $current_settings['islerimler'] ? 'checked' : '' ?>>
                            <label class="form-check-label" for="islerimler">
                                <strong>Masaüstü islerimleri</strong>
                                <br>
                                <small class="text-muted">Yeni mesajlar ve güncellemeler için islerim al</small>
                            </label>
                        </div>
                    </div>

                    <div class="setting-card">
                        <div class="setting-icon icon-notifications">
                            <i class="fas fa-envelope"></i>
                        </div>
                        <div class="form-check form-switch">
                            <input class="form-check-input" type="checkbox" name="email_islerimleri" id="email_islerimleri" 
                                   <?= $current_settings['email_islerimleri'] ? 'checked' : '' ?>>
                            <label class="form-check-label" for="email_islerimleri">
                                <strong>E-posta islerimleri</strong>
                                <br>
                                <small class="text-muted">Önemli güncellemeler için e-posta al</small>
                            </label>
                        </div>
                    </div>
                </div>

                <div class="content-container">
                    <h2 class="section-title">
                        <i class="fas fa-palette"></i>
                        Görünüm Ayarları
                    </h2>
                    
                    <div class="setting-card">
                        <div class="setting-icon icon-appearance">
                            <i class="fas fa-palette"></i>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">
                                <strong>Tema Seçimi</strong>
                            </label>
                            <div class="d-flex gap-3 align-items-center">
                                <div class="theme-preview theme-light <?= $current_settings['tema'] === 'light' ? 'active' : '' ?>" 
                                     onclick="selectTheme('light')" title="Açık Tema"></div>
                                <div class="theme-preview theme-dark <?= $current_settings['tema'] === 'dark' ? 'active' : '' ?>" 
                                     onclick="selectTheme('dark')" title="Koyu Tema"></div>
                                <div class="theme-preview theme-auto <?= $current_settings['tema'] === 'auto' ? 'active' : '' ?>" 
                                     onclick="selectTheme('auto')" title="Otomatik"></div>
                            </div>
                            <input type="hidden" name="tema" id="temaInput" value="<?= $current_settings['tema'] ?>">
                        </div>
                    </div>
                </div>

                <div class="content-container">
                    <h2 class="section-title">
                        <i class="fas fa-globe"></i>
                        Dil ve Bölge Ayarları
                    </h2>
                    
                    <div class="setting-card">
                        <div class="setting-icon icon-language">
                            <i class="fas fa-globe"></i>
                        </div>
                        <div class="row">
                            <div class="col-md-6 mb-3">
                                <label class="form-label">Dil</label>
                                <select name="dil" class="form-select">
                                    <option value="tr" <?= $current_settings['dil'] === 'tr' ? 'selected' : '' ?>>Türkçe</option>
                                    <option value="en" <?= $current_settings['dil'] === 'en' ? 'selected' : '' ?>>English</option>
                                    <option value="de" <?= $current_settings['dil'] === 'de' ? 'selected' : '' ?>>Deutsch</option>
                                    <option value="fr" <?= $current_settings['dil'] === 'fr' ? 'selected' : '' ?>>Français</option>
                                </select>
                            </div>
                            <div class="col-md-6 mb-3">
                                <label class="form-label">Zaman Dilimi</label>
                                <select name="zaman_dilimi" class="form-select">
                                    <option value="Europe/Istanbul" <?= $current_settings['zaman_dilimi'] === 'Europe/Istanbul' ? 'selected' : '' ?>>İstanbul (UTC+3)</option>
                                    <option value="Europe/London" <?= $current_settings['zaman_dilimi'] === 'Europe/London' ? 'selected' : '' ?>>Londra (UTC+0)</option>
                                    <option value="America/New_York" <?= $current_settings['zaman_dilimi'] === 'America/New_York' ? 'selected' : '' ?>>New York (UTC-5)</option>
                                    <option value="Asia/Tokyo" <?= $current_settings['zaman_dilimi'] === 'Asia/Tokyo' ? 'selected' : '' ?>>Tokyo (UTC+9)</option>
                                </select>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="content-container">
                    <h2 class="section-title">
                        <i class="fas fa-shield-alt"></i>
                        Güvenlik Ayarları
                    </h2>
                    
                    <div class="setting-card">
                        <div class="setting-icon icon-security">
                            <i class="fas fa-shield-alt"></i>
                        </div>
                        <div class="row">
                            <div class="col-md-6 mb-3">
                                <a href="sifre-degistir.php" class="btn btn-modern btn-warning-modern w-100">
                                    <i class="fas fa-key me-2"></i>
                                    Şifre Değiştir
                                </a>
                            </div>
                            <div class="col-md-6 mb-3">
                                <button type="button" class="btn btn-modern btn-danger-modern w-100" onclick="showLogoutModal()">
                                    <i class="fas fa-sign-out-alt me-2"></i>
                                    Tüm Oturumları Kapat
                                </button>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="content-container">
                    <div class="d-flex justify-content-between align-items-center">
                        <div>
                            <h2 class="section-title">
                                <i class="fas fa-save"></i>
                                Ayarları Kaydet
                            </h2>
                            <p class="text-muted mb-0">Değişikliklerinizi kaydetmek için aşağıdaki butona tıklayın</p>
                        </div>
                        <button type="submit" name="ayarlar_guncelle" class="btn btn-modern btn-success-modern">
                            <i class="fas fa-save me-2"></i>
                            Ayarları Kaydet
                        </button>
                    </div>
                </div>
            </form>
        </div>
    </div>

    <!-- Logout Modal -->
    <div class="modal fade modal-modern" id="logoutModal" tabindex="-1">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">
                        <i class="fas fa-exclamation-triangle me-2"></i>
                        Tüm Oturumları Kapat
                    </h5>
                    <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body">
                    <p>Bu işlem tüm cihazlardaki oturumlarınızı kapatacaktır. Devam etmek istediğinize emin misiniz?</p>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">İptal</button>
                    <a href="cikis.php" class="btn btn-modern btn-danger-modern">
                        <i class="fas fa-sign-out-alt me-2"></i>
                        Tümünü Kapat
                    </a>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.6/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/gsap/3.12.2/gsap.min.js"></script>
    
    <script>
        // Floating particles
        function createParticles() {
            const particlesContainer = document.getElementById('particles');
            const particleCount = 50;
            
            for (let i = 0; i < particleCount; i++) {
                const particle = document.createElement('div');
                particle.className = 'particle';
                particle.style.width = Math.random() * 10 + 5 + 'px';
                particle.style.height = particle.style.width;
                particle.style.left = Math.random() * 100 + '%';
                particle.style.top = Math.random() * 100 + '%';
                particle.style.animationDelay = Math.random() * 6 + 's';
                particle.style.animationDuration = (Math.random() * 3 + 3) + 's';
                particlesContainer.appendChild(particle);
            }
        }

        // GSAP Animations
        function initAnimations() {
            gsap.from('.page-header', {
                duration: 1,
                y: -50,
                opacity: 0,
                ease: "power2.out"
            });

            gsap.from('.content-container', {
                duration: 0.8,
                y: 30,
                opacity: 0,
                stagger: 0.2,
                ease: "power2.out",
                delay: 0.3
            });
        }

        // Tema seçimi
        function selectTheme(theme) {
            // Aktif tema sınıfını kaldır
            document.querySelectorAll('.theme-preview').forEach(el => {
                el.classList.remove('active');
            });
            
            // Seçilen temayı aktif yap
            event.target.classList.add('active');
            
            // Hidden input'u güncelle
            document.getElementById('temaInput').value = theme;
        }

        // Logout modal
        function showLogoutModal() {
            const modal = new bootstrap.Modal(document.getElementById('logoutModal'));
            modal.show();
        }

        // Initialize
        document.addEventListener('DOMContentLoaded', function() {
            createParticles();
            initAnimations();
        });
    </script>
</body>
</html> 