<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

session_start();
require_once 'baglan.php';

header('Content-Type: application/json');

if (!isset($_SESSION['kullanici'])) {
    echo json_encode(['adet' => 0, 'sesli' => false]);
    exit;
}

$kullanici_id = $_SESSION['kullanici']['id'];

try {
    $stmt = $db->prepare("SELECT * FROM islerimler WHERE kullanici_id = ? AND okundu = 0 ORDER BY id DESC LIMIT 1");
    $stmt->execute([$kullanici_id]);
    $islerim = $stmt->fetch(PDO::FETCH_ASSOC);

    if ($islerim) {
        $sesli = $islerim['sesli'] == 1;

        $db->prepare("UPDATE islerimler SET okundu = 1 WHERE id = ?")->execute([$islerim['id']]);

        echo json_encode(['adet' => 1, 'sesli' => $sesli]);
    } else {
        echo json_encode(['adet' => 0, 'sesli' => false]);
    }
} catch (PDOException $e) {
    http_response_code(500);
    echo json_encode(['adet' => 0, 'sesli' => false, 'hata' => $e->getMessage()]);
}
