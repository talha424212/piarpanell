<?php
session_start();
if (!isset($_SESSION['kullanici'])) {
    header("Location: giris.php");
    exit;
}

require_once 'baglan.php';

$kullanici_id = $_SESSION['kullanici']['id'];
$mesai_durum = '';
$izin_mesaji = '';

// Mesai başlatma
if (isset($_POST['baslat'])) {
    $stmt = $db->prepare("INSERT INTO mesailer (calisan_id, baslangic) VALUES (?, NOW())");
    $stmt->execute([$kullanici_id]);
    $mesai_durum = 'Mesai başladı.';
}

// Mesai bitirme
if (isset($_POST['bitir'])) {
    $stmt = $db->prepare("UPDATE mesailer SET bitis = NOW() WHERE calisan_id = ? AND bitis IS NULL");
    $stmt->execute([$kullanici_id]);
    $mesai_durum = 'Mesai bitti. İyi günler dileriz.';
}

// İzin talebi gönderme
if (isset($_POST['izin_iste'])) {
    $baslangic = $_POST['izin_baslangic'];
    $bitis = $_POST['izin_bitis'];
    $sebep = trim($_POST['izin_sebep']);

    $rapor_yolu = null;
    if (!empty($_FILES['izin_rapor']['name'])) {
        $uploads_dir = 'uploads/raporlar';
        if (!is_dir($uploads_dir)) {
            mkdir($uploads_dir, 0777, true);
        }
        $tmp_name = $_FILES['izin_rapor']['tmp_name'];
        $filename = basename($_FILES['izin_rapor']['name']);
        $uniq_name = time() . '_' . rand(1000,9999) . '_' . $filename;
        $hedef_yol = "$uploads_dir/$uniq_name";

        if (move_uploaded_file($tmp_name, $hedef_yol)) {
            $rapor_yolu = $hedef_yol;
        } else {
            $izin_mesaji = "Rapor yüklenirken hata oluştu.";
        }
    }

    if (!$izin_mesaji) {
        $stmt = $db->prepare("INSERT INTO izinler (calisan_id, baslangic, bitis, sebep, rapor_yolu, onay) VALUES (?, ?, ?, ?, ?, 'beklemede')");
        $stmt->execute([$kullanici_id, $baslangic, $bitis, $sebep, $rapor_yolu]);
        $izin_mesaji = "İzin talebiniz gönderildi. Onay bekleniyor.";
    }
}

$stmt = $db->prepare("SELECT * FROM mesailer WHERE calisan_id = ? ORDER BY id DESC LIMIT 1");
$stmt->execute([$kullanici_id]);
$son_mesai = $stmt->fetch(PDO::FETCH_ASSOC);

$stmt = $db->prepare("SELECT * FROM mesailer WHERE calisan_id = ? ORDER BY baslangic DESC");
$stmt->execute([$kullanici_id]);
$mesailer = $stmt->fetchAll(PDO::FETCH_ASSOC);

$stmt = $db->prepare("SELECT * FROM izinler WHERE calisan_id = ? ORDER BY baslangic DESC");
$stmt->execute([$kullanici_id]);
$izinler = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <title>Mesai ve İzin Durumu - Piar Panel</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.6/dist/css/bootstrap.min.css" rel="stylesheet" />
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet" />
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap" rel="stylesheet" />
    <style>
        * {
            font-family: 'Inter', sans-serif;
        }
        
        body {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            min-height: 100vh;
            position: relative;
        }
        
        body::before {
            content: '';
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: url('data:image/svg+xml,<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 100 100"><defs><pattern id="grain" width="100" height="100" patternUnits="userSpaceOnUse"><circle cx="25" cy="25" r="1" fill="rgba(255,255,255,0.1)"/><circle cx="75" cy="75" r="1" fill="rgba(255,255,255,0.1)"/><circle cx="50" cy="10" r="0.5" fill="rgba(255,255,255,0.1)"/><circle cx="10" cy="60" r="0.5" fill="rgba(255,255,255,0.1)"/><circle cx="90" cy="40" r="0.5" fill="rgba(255,255,255,0.1)"/></pattern></defs><rect width="100" height="100" fill="url(%23grain)"/></svg>');
            pointer-events: none;
            z-index: -1;
        }
        
        .main-content {
            margin-left: 280px;
            padding: 2rem;
            min-height: 100vh;
        }
        
        .page-header {
            background: rgba(255, 255, 255, 0.1);
            backdrop-filter: blur(20px);
            border-radius: 20px;
            padding: 2rem;
            margin-bottom: 2rem;
            border: 1px solid rgba(255, 255, 255, 0.2);
            box-shadow: 0 8px 32px rgba(0, 0, 0, 0.1);
        }
        
        .page-title {
            color: white;
            font-weight: 700;
            font-size: 2.5rem;
            margin: 0;
            text-shadow: 0 2px 4px rgba(0, 0, 0, 0.3);
            display: flex;
            align-items: center;
            gap: 1rem;
        }
        
        .page-subtitle {
            color: rgba(255, 255, 255, 0.8);
            font-weight: 400;
            margin: 0.5rem 0 0 0;
            font-size: 1.1rem;
        }
        
        .content-container {
            background: rgba(255, 255, 255, 0.95);
            backdrop-filter: blur(20px);
            border-radius: 20px;
            padding: 2rem;
            box-shadow: 0 20px 40px rgba(0, 0, 0, 0.1);
            border: 1px solid rgba(255, 255, 255, 0.2);
            transition: transform 0.3s ease, box-shadow 0.3s ease;
            margin-bottom: 2rem;
        }
        
        .content-container:hover {
            transform: translateY(-5px);
            box-shadow: 0 25px 50px rgba(0, 0, 0, 0.15);
        }
        
        .card {
            background: rgba(255, 255, 255, 0.9);
            border-radius: 15px;
            border: none;
            box-shadow: 0 8px 25px rgba(0, 0, 0, 0.1);
            transition: all 0.3s ease;
            overflow: hidden;
        }
        
        .card:hover {
            transform: translateY(-5px);
            box-shadow: 0 15px 35px rgba(0, 0, 0, 0.15);
        }
        
        .card-header {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            border: none;
            padding: 1.5rem;
            font-weight: 600;
            font-size: 1.2rem;
        }
        
        .card-body {
            padding: 1.5rem;
        }
        
        .btn {
            border-radius: 10px;
            font-weight: 500;
            padding: 0.75rem 1.5rem;
            transition: all 0.3s ease;
            border: none;
            display: inline-flex;
            align-items: center;
            gap: 0.5rem;
        }
        
        .btn:hover {
            transform: translateY(-2px);
            box-shadow: 0 5px 15px rgba(0, 0, 0, 0.2);
        }
        
        .btn-primary {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
        }
        
        .btn-success {
            background: linear-gradient(135deg, #28a745 0%, #20c997 100%);
        }
        
        .btn-danger {
            background: linear-gradient(135deg, #dc3545 0%, #e83e8c 100%);
        }
        
        .btn-warning {
            background: linear-gradient(135deg, #ffc107 0%, #fd7e14 100%);
        }
        
        .table {
            background: rgba(255, 255, 255, 0.9);
            border-radius: 15px;
            overflow: hidden;
            box-shadow: 0 5px 15px rgba(0, 0, 0, 0.1);
        }
        
        .table thead th {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            border: none;
            font-weight: 600;
            padding: 1rem;
        }
        
        .table tbody tr {
            transition: all 0.3s ease;
        }
        
        .table tbody tr:hover {
            background: rgba(102, 126, 234, 0.05);
            transform: scale(1.01);
        }
        
        .table td {
            padding: 1rem;
            border: none;
            border-bottom: 1px solid rgba(0, 0, 0, 0.05);
        }
        
        .badge {
            border-radius: 8px;
            font-weight: 500;
            padding: 0.5rem 0.75rem;
        }
        
        .badge-beklemede {
            background: linear-gradient(135deg, #ffc107 0%, #fd7e14 100%);
            color: white;
        }
        
        .badge-onaylandi {
            background: linear-gradient(135deg, #28a745 0%, #20c997 100%);
            color: white;
        }
        
        .badge-reddedildi {
            background: linear-gradient(135deg, #dc3545 0%, #e83e8c 100%);
            color: white;
        }
        
        .form-control, .form-select {
            border-radius: 10px;
            border: 2px solid #e9ecef;
            padding: 0.75rem;
            transition: all 0.3s ease;
        }
        
        .form-control:focus, .form-select:focus {
            border-color: #667eea;
            box-shadow: 0 0 0 0.2rem rgba(102, 126, 234, 0.25);
        }
        
        .alert {
            border-radius: 15px;
            border: none;
            padding: 1rem 1.5rem;
            margin-bottom: 1.5rem;
            box-shadow: 0 5px 15px rgba(0, 0, 0, 0.1);
        }
        
        .alert-info {
            background: linear-gradient(135deg, #d1ecf1 0%, #bee5eb 100%);
            color: #0c5460;
        }
        
        .alert-success {
            background: linear-gradient(135deg, #d4edda 0%, #c3e6cb 100%);
            color: #155724;
        }
        
        .alert-danger {
            background: linear-gradient(135deg, #f8d7da 0%, #f5c6cb 100%);
            color: #721c24;
        }
        
        .stats-cards {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 1.5rem;
            margin-bottom: 2rem;
        }
        
        .stat-card {
            background: rgba(255, 255, 255, 0.1);
            backdrop-filter: blur(20px);
            border-radius: 15px;
            padding: 1.5rem;
            border: 1px solid rgba(255, 255, 255, 0.2);
            box-shadow: 0 8px 32px rgba(0, 0, 0, 0.1);
            transition: all 0.3s ease;
            color: white;
            text-align: center;
        }
        
        .stat-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 15px 40px rgba(0, 0, 0, 0.2);
        }
        
        .stat-icon {
            font-size: 2rem;
            margin-bottom: 1rem;
            opacity: 0.9;
        }
        
        .stat-number {
            font-size: 1.8rem;
            font-weight: 700;
            margin-bottom: 0.5rem;
        }
        
        .stat-label {
            font-size: 0.9rem;
            opacity: 0.8;
            font-weight: 500;
        }
        
        .mesai-durum {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            padding: 1rem 1.5rem;
            border-radius: 15px;
            margin-bottom: 1.5rem;
            text-align: center;
            font-weight: 600;
            box-shadow: 0 5px 15px rgba(102, 126, 234, 0.3);
        }
        
        @media (max-width: 768px) {
            .main-content {
                margin-left: 0;
                padding: 1rem;
            }
            
            .page-title {
                font-size: 2rem;
            }
            
            .stats-cards {
                grid-template-columns: 1fr;
            }
        }
    </style>
</head>
<body>

<?php include 'parcalar/sidebar.php'; ?>
<?php include 'parcalar/navbar.php'; ?>

<div class="main-content">
    <div class="page-header">
        <h1 class="page-title">
            <i class="fas fa-clock"></i>
            Mesai ve İzin Durumu
        </h1>
        <p class="page-subtitle">Mesai takibi ve izin taleplerinizi yönetin</p>
    </div>

    <?php if ($mesai_durum): ?>
        <div class="mesai-durum">
            <i class="fas fa-info-circle me-2"></i>
            <?= htmlspecialchars($mesai_durum) ?>
        </div>
    <?php endif; ?>

    <?php if ($izin_mesaji): ?>
        <div class="alert alert-info">
            <i class="fas fa-info-circle me-2"></i>
            <?= htmlspecialchars($izin_mesaji) ?>
        </div>
    <?php endif; ?>

    <div class="stats-cards">
        <div class="stat-card">
            <div class="stat-icon">
                <i class="fas fa-clock"></i>
            </div>
            <div class="stat-number"><?= count($mesailer) ?></div>
            <div class="stat-label">Toplam Mesai</div>
        </div>
        <div class="stat-card">
            <div class="stat-icon">
                <i class="fas fa-calendar-check"></i>
            </div>
            <div class="stat-number"><?= count($izinler) ?></div>
            <div class="stat-label">Toplam İzin</div>
        </div>
        <div class="stat-card">
            <div class="stat-icon">
                <i class="fas fa-hourglass-half"></i>
            </div>
            <div class="stat-number">
                <?php
                $bekleyen_izinler = array_filter($izinler, function($izin) {
                    return $izin['onay'] === 'beklemede';
                });
                echo count($bekleyen_izinler);
                ?>
            </div>
            <div class="stat-label">Bekleyen İzin</div>
        </div>
        <div class="stat-card">
            <div class="stat-icon">
                <i class="fas fa-check-circle"></i>
            </div>
            <div class="stat-number">
                <?php
                $onaylanan_izinler = array_filter($izinler, function($izin) {
                    return $izin['onay'] === 'onaylandi';
                });
                echo count($onaylanan_izinler);
                ?>
            </div>
            <div class="stat-label">Onaylanan İzin</div>
        </div>
    </div>

    <div class="content-container">
        <div class="card">
            <div class="card-header">
                <i class="fas fa-play-circle me-2"></i>
                Mesai Kontrolü
            </div>
            <div class="card-body">
                <?php if (!$son_mesai || $son_mesai['bitis']): ?>
                    <p class="text-muted mb-3">Şu anda mesai yapmıyorsunuz.</p>
                    <form method="post">
                        <button type="submit" name="baslat" class="btn btn-success">
                            <i class="fas fa-play"></i>
                            Mesai Başlat
                        </button>
                    </form>
                <?php else: ?>
                    <div class="alert alert-info">
                        <i class="fas fa-clock me-2"></i>
                        <strong>Mesai devam ediyor!</strong><br>
                        Başlangıç: <?= date('d.m.Y H:i', strtotime($son_mesai['baslangic'])) ?>
                    </div>
                    <form method="post">
                        <button type="submit" name="bitir" class="btn btn-danger">
                            <i class="fas fa-stop"></i>
                            Mesai Bitir
                        </button>
                    </form>
                <?php endif; ?>
            </div>
        </div>
    </div>

    <div class="content-container">
        <div class="card">
            <div class="card-header">
                <i class="fas fa-calendar-plus me-2"></i>
                İzin Talebi
            </div>
            <div class="card-body">
                <form method="post" enctype="multipart/form-data">
                    <div class="row">
                        <div class="col-md-6 mb-3">
                            <label class="form-label">
                                <i class="fas fa-calendar me-2"></i>
                                Başlangıç Tarihi
                            </label>
                            <input type="date" name="izin_baslangic" class="form-control" required>
                        </div>
                        <div class="col-md-6 mb-3">
                            <label class="form-label">
                                <i class="fas fa-calendar me-2"></i>
                                Bitiş Tarihi
                            </label>
                            <input type="date" name="izin_bitis" class="form-control" required>
                        </div>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">
                            <i class="fas fa-comment me-2"></i>
                            İzin Sebebi
                        </label>
                        <textarea name="izin_sebep" class="form-control" rows="3" required></textarea>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">
                            <i class="fas fa-file me-2"></i>
                            Rapor (Opsiyonel)
                        </label>
                        <input type="file" name="izin_rapor" class="form-control">
                    </div>
                    <button type="submit" name="izin_iste" class="btn btn-primary">
                        <i class="fas fa-paper-plane"></i>
                        İzin Talebi Gönder
                    </button>
                </form>
            </div>
        </div>
    </div>

    <div class="content-container">
        <div class="card">
            <div class="card-header">
                <i class="fas fa-history me-2"></i>
                Mesai Geçmişi
            </div>
            <div class="card-body">
                <div class="table-responsive">
                    <table class="table table-hover">
                        <thead>
                            <tr>
                                <th><i class="fas fa-calendar me-2"></i>Başlangıç</th>
                                <th><i class="fas fa-calendar me-2"></i>Bitiş</th>
                                <th><i class="fas fa-clock me-2"></i>Süre</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($mesailer as $mesai): ?>
                                <tr>
                                    <td><?= date('d.m.Y H:i', strtotime($mesai['baslangic'])) ?></td>
                                    <td>
                                        <?php if ($mesai['bitis']): ?>
                                            <?= date('d.m.Y H:i', strtotime($mesai['bitis'])) ?>
                                        <?php else: ?>
                                            <span class="badge badge-beklemede">Devam Ediyor</span>
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <?php if ($mesai['bitis']): ?>
                                            <?php
                                            $baslangic = new DateTime($mesai['baslangic']);
                                            $bitis = new DateTime($mesai['bitis']);
                                            $fark = $baslangic->diff($bitis);
                                            echo $fark->format('%h saat %i dakika');
                                            ?>
                                        <?php else: ?>
                                            <span class="text-muted">-</span>
                                        <?php endif; ?>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                            <?php if (empty($mesailer)): ?>
                                <tr>
                                    <td colspan="3" class="text-center text-muted py-4">
                                        <i class="fas fa-history fa-3x mb-3"></i>
                                        <br>Mesai geçmişi bulunmuyor.
                                    </td>
                                </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>

    <div class="content-container">
        <div class="card">
            <div class="card-header">
                <i class="fas fa-calendar-check me-2"></i>
                İzin Geçmişi
            </div>
            <div class="card-body">
                <div class="table-responsive">
                    <table class="table table-hover">
                        <thead>
                            <tr>
                                <th><i class="fas fa-calendar me-2"></i>Başlangıç</th>
                                <th><i class="fas fa-calendar me-2"></i>Bitiş</th>
                                <th><i class="fas fa-comment me-2"></i>Sebep</th>
                                <th><i class="fas fa-info-circle me-2"></i>Durum</th>
                                <th><i class="fas fa-file me-2"></i>Rapor</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($izinler as $izin): ?>
                                <tr>
                                    <td><?= date('d.m.Y', strtotime($izin['baslangic'])) ?></td>
                                    <td><?= date('d.m.Y', strtotime($izin['bitis'])) ?></td>
                                    <td><?= htmlspecialchars($izin['sebep']) ?></td>
                                    <td>
                                        <?php
                                        $durum_class = '';
                                        $durum_icon = '';
                                        switch($izin['onay']) {
                                            case 'beklemede':
                                                $durum_class = 'badge-beklemede';
                                                $durum_icon = 'fas fa-clock';
                                                break;
                                            case 'onaylandi':
                                                $durum_class = 'badge-onaylandi';
                                                $durum_icon = 'fas fa-check';
                                                break;
                                            case 'reddedildi':
                                                $durum_class = 'badge-reddedildi';
                                                $durum_icon = 'fas fa-times';
                                                break;
                                        }
                                        ?>
                                        <span class="badge <?= $durum_class ?>">
                                            <i class="<?= $durum_icon ?> me-1"></i>
                                            <?= ucfirst($izin['onay']) ?>
                                        </span>
                                    </td>
                                    <td>
                                        <?php if ($izin['rapor_yolu']): ?>
                                            <a href="<?= $izin['rapor_yolu'] ?>" class="btn btn-sm btn-primary" target="_blank">
                                                <i class="fas fa-download me-1"></i>
                                                İndir
                                            </a>
                                        <?php else: ?>
                                            <span class="text-muted">-</span>
                                        <?php endif; ?>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                            <?php if (empty($izinler)): ?>
                                <tr>
                                    <td colspan="5" class="text-center text-muted py-4">
                                        <i class="fas fa-calendar-times fa-3x mb-3"></i>
                                        <br>İzin geçmişi bulunmuyor.
                                    </td>
                                </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.6/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
