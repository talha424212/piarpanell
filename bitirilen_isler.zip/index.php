<?php 
header('Location: panel.php');
?>