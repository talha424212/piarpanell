<?php
session_start();
if (!isset($_SESSION['kullanici'])) { header("Location: giris.php"); exit; }
require_once 'baglan.php';
$kullanici = $_SESSION['kullanici'];
?>
<!doctype html>
<html lang="tr">
<head>
  <meta charset="UTF-8" />
  <title>İş Takvimi - Piar Panel</title>
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.6/dist/css/bootstrap.min.css" rel="stylesheet" />
  <link href="https://cdn.jsdelivr.net/npm/fullcalendar@6.1.10/main.min.css" rel="stylesheet" />
  <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css" rel="stylesheet" />
  <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">
<style>
    :root {
        --primary-gradient: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
        --glass-bg: rgba(255, 255, 255, 0.1);
        --glass-border: rgba(255, 255, 255, 0.25);
        --text-light: #f8f9fa;
        --text-muted: #ced4da;
    }
    body { 
        background: var(--primary-gradient); 
        min-height: 100vh; 
        font-family: 'Inter', sans-serif; 
    }
    .main-content { margin-left: 280px; padding: 2rem; }
    @media (max-width: 992px) { .main-content { margin-left: 0; } }

    .page-header {
        background: var(--glass-bg); backdrop-filter:blur(15px); border:1px solid var(--glass-border); 
        border-radius: 20px; padding: 2rem; margin-bottom: 2rem;
    }
    .page-title { color: var(--text-light); text-shadow: 0 2px 4px rgba(0,0,0,0.3); font-weight: 700;}

    #calendar-container {
        background: var(--glass-bg); backdrop-filter: blur(15px); border-radius: 20px; padding: 25px;
        box-shadow: 0 10px 40px rgba(0,0,0,0.2); border: 1px solid var(--glass-border);
    }
    
    /* --- Genel Takvim Stilleri --- */
    .fc { 
        --fc-border-color: var(--glass-border); 
        --fc-page-bg-color: transparent;
        --fc-neutral-bg-color: rgba(0,0,0,0.1);
        --fc-list-event-hover-bg-color: rgba(255,255,255,0.1);
        color: var(--text-light);
    }
    .fc .fc-toolbar-title { color: var(--text-light); font-weight: 600; }
    .fc .fc-col-header-cell-cushion { color: var(--text-muted); text-decoration: none; font-weight: 500; }
    
    /* Okunabilirlik ve Bugün Vurgusu */
    .fc .fc-daygrid-day-number { 
        color: var(--text-light); font-weight: 500; text-shadow: 0 1px 1px rgba(0,0,0,0.4); 
        text-decoration: none; padding: 4px; 
    }
    .fc .fc-day-today { background-color: rgba(255, 255, 255, 0.2) !important; }
    .fc .fc-day-today .fc-daygrid-day-number { 
        font-weight: 700; background-color: #667eea; border-radius: 50%; 
        width: 28px; height: 28px; display: inline-flex; justify-content: center; align-items: center; 
    }
    
    /* Buton Stilleri */
    .fc .fc-button { 
        background-image: linear-gradient(135deg, rgba(102,126,234,0.7) 0%, rgba(118,75,162,0.7) 100%); 
        border: 1px solid var(--glass-border); text-shadow: none; transition: all .3s; 
    }
    .fc .fc-button-primary:hover, .fc .fc-button-primary:active, .fc .fc-button-primary:focus {
        background-image: linear-gradient(135deg, #667eea 0%, #764ba2 100%); 
        border-color: #fff; box-shadow: 0 0 10px rgba(102, 126, 234, 0.4);
    }

    /* Etkinlik Rengi ve Yazısı */
    .fc-event, .fc-event-main {
        border: none !important; 
        padding: 5px 8px; 
        cursor: pointer; 
        background-color: #4834d4 !important;
        color: white !important;
        font-weight: 500;
        white-space: nowrap;      /* Metnin tek satırda kalmasını zorla */
        overflow: hidden;         /* Taşan metni gizle */
        text-overflow: ellipsis;  /* Taşan metnin sonuna '...' ekle */
    }

    /* ====== TAŞMA SORUNU İÇİN KESİN ÇÖZÜM BÖLÜMÜ ====== */

    /* Her bir "gün" kutusunun iç çerçevesini Flexbox yapısına geçiriyoruz. */
    .fc-daygrid-day-frame {
        display: flex;
        flex-direction: column; /* İçeriği dikey olarak sırala: (1. Gün Numarası, 2. Etkinlik Alanı) */
        min-height: 100%;       /* Hücrenin tamamını kapla */
    }

    /* Gün numarasını (örn: 23, 24) içeren üst bölüm */
    .fc-daygrid-day-top {
        flex-shrink: 0; /* Bu alanın küçülmesini engelle */
    }

    /* Etkinliklerin bulunduğu ana alan */
    .fc-daygrid-day-events {
        flex-grow: 1;           /* Bu alanın dikeyde kalan tüm boşluğu kaplamasını sağla */
        min-height: 0;          /* Bu, iç içe geçmiş flex yapılarda taşmayı önleyen kritik bir kuraldır */
        position: relative;     /* İçindeki absolut pozisyonlu öğeler için referans noktası olur */
        overflow: hidden;       /* HER ŞEYE RAĞMEN BİR TAŞMA OLURSA, ONU KES VE GİZLE! */
    }
    
    /* Etkinlik çubuklarını saran dış kapsayıcı */
    .fc-daygrid-event-harness {
        width: 100%;             /* Kapsayıcının genişliği hücreyi aşmasın */
        box-sizing: border-box;  /* padding ve border genişliğe dahil edilsin */
        padding-right: 4px;      /* Sağ kenardan taşmayı önlemek için küçük bir garanti boşluk */
    }
    
    /* Modal ve diğer stiller (değişiklik yok) */
    .modal-content { background: #2d3436; border: 1px solid rgba(255,255,255,0.2); color: white; border-radius: 15px; }
    .modal-header, .modal-footer { border-color: rgba(255,255,255,0.1); }
    .modal-title { font-weight: 600; }
    .form-control, .form-select { background-color: rgba(0,0,0,0.2); border-color: rgba(255,255,255,0.2); color: white; }
    .form-control:focus, .form-select:focus { background-color: rgba(0,0,0,0.3); color: white; box-shadow: none; border-color:#667eea; }
    .form-select option { background-color: #2d3436; color: white;}
    .btn-close { filter: invert(1); }
</style>
</head>
<body>
    <?php include 'parcalar/sidebar.php'; ?>
    <?php include 'parcalar/navbar.php'; ?>
    
    <div class="main-content"><div class="container-fluid">
        <div class="page-header"><h1 class="page-title"><i class="fa-solid fa-calendar-days me-3"></i> İş Takvimi</h1></div>
        <div id="calendar-container"><div id="calendar"></div></div>
    </div></div>
    
    <!-- === DETAYLI MODAL FORMU === -->
    <div class="modal fade" id="etkinlikModal" tabindex="-1"><div class="modal-dialog modal-dialog-centered modal-lg">
        <form id="etkinlikForm"><div class="modal-content">
            <div class="modal-header"><h5 class="modal-title"><i class="fas fa-plus-circle me-2"></i>Etkinlik/İş Detayları</h5><button type="button" class="btn-close" data-bs-dismiss="modal"></button></div>
            <div class="modal-body">
              <input type="hidden" name="id" id="etkinlikId">
              <div class="row">
                <div class="col-md-8 mb-3"><label class="form-label">Başlık</label><input type="text" name="baslik" id="baslik" class="form-control" required></div>
                <div class="col-md-4 mb-3"><label class="form-label">Öncelik</label><select name="oncelik" id="oncelik" class="form-select"><option value="Düşük">Düşük</option><option value="Orta" selected>Orta</option><option value="Yüksek">Yüksek</option></select></div>
              </div>
              <div class="mb-3"><label class="form-label">Atanan Kişiler</label><select name="kullanici_id[]" id="kullanici_id" class="form-select" multiple required><?php $users = $db->query("SELECT id, isim, soyisim FROM kullanicilar ORDER BY isim")->fetchAll(PDO::FETCH_ASSOC); foreach ($users as $user) { echo "<option value='{$user['id']}'>" . htmlspecialchars($user['isim'] . ' ' . $user['soyisim']) . "</option>"; } ?></select></div>
              <div class="row">
                <div class="col-md-6 mb-3"><label class="form-label">Başlangıç Tarihi ve Saati</label><input type="datetime-local" name="baslangic" id="baslangic" class="form-control" required></div>
                <div class="col-md-6 mb-3"><label class="form-label">Bitiş Tarihi (Sadece Bilgi Amaçlı)</label><input type="date" name="bitis" id="bitis" class="form-control"></div>
              </div>
              <div class="mb-3"><label class="form-label">Açıklama</label><textarea name="aciklama" id="aciklama" class="form-control" rows="3"></textarea></div>
            </div>
            <div class="modal-footer justify-content-between">
              <div><button type="button" class="btn btn-danger" id="silButonu"><i class="fas fa-trash"></i> Sil</button></div>
              <div><button type="button" class="btn btn-secondary" data-bs-dismiss="modal">İptal</button><button type="submit" class="btn btn-primary">Kaydet</button></div>
            </div>
        </div></form>
    </div></div>
    
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.6/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/fullcalendar@6.1.10/index.global.min.js"></script>
    <script>
    document.addEventListener('DOMContentLoaded', function () {
      const calendarEl = document.getElementById('calendar');
      const etkinlikModal = new bootstrap.Modal(document.getElementById('etkinlikModal'));
      // ... Diğer JS elementleri
      
      const calendar = new FullCalendar.Calendar(calendarEl, {
        locale: 'tr',
        buttonText: { today: 'Bugün', month: 'Ay', week: 'Hafta', list: 'Liste' },
        initialView: 'dayGridMonth',
        headerToolbar: { left: 'prev,next today', center: 'title', right: 'dayGridMonth,timeGridWeek' },
        selectable: true, 
        editable: true, 
        events: 'takvim_veri.php',
        
        // Bu ayar, etkinliklerin bitiş gününü takvimde göstermez, tek güne sığdırır.
        displayEventEnd: false, 

        dateClick: function (info) {
          etkinlikForm.reset();
          document.getElementById('etkinlikId').value = '';
          document.getElementById('baslangic').value = info.dateStr + 'T09:00';
          silButonu.style.display = 'none';
          etkinlikModal.show();
        },
        eventClick: function (info) {
          const props = info.event.extendedProps;
          document.getElementById('etkinlikId').value = info.event.id;
          document.getElementById('baslik').value = info.event.title;
          document.getElementById('baslangic').value = info.event.startStr ? info.event.startStr.substring(0, 16) : '';
          
          // `bitis` alanı artık datetime-local değil, date.
          const bitisDate = info.event.extendedProps.bitis_db || '';
          document.getElementById('bitis').value = bitisDate ? bitisDate.substring(0, 10) : '';

          document.getElementById('aciklama').value = props.aciklama || '';
          document.getElementById('oncelik').value = props.oncelik || 'Orta';
          
          const selectedUserIds = (props.kullanici_id || []).map(id => String(id));
          const selectElement = document.getElementById('kullanici_id');
          Array.from(selectElement.options).forEach(option => {
             option.selected = selectedUserIds.includes(option.value);
          });
          
          silButonu.style.display = 'inline-block';
          etkinlikModal.show();
        },
        eventDrop: function(info) {
          const formData = new FormData();
          formData.append('id', info.event.id);
          formData.append('baslangic', info.event.startStr ? info.event.startStr.substring(0,16) : null);
          formData.append('is_drop_update', '1');
            
          fetch('etkinlik_ekle.php', { method: 'POST', body: formData })
           .then(res => res.json()).then(data => { 
              if(!data.ok) { info.revert(); alert('Hata: ' + data.error); }
           });
        }
      });
      calendar.render();
      
      // Submit ve Silme işlemleri için JavaScript (öncekiyle aynı)
    });
    </script>
</body>
</html>