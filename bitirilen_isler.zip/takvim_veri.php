<?php
session_start();
require_once 'baglan.php';
header('Content-Type: application/json');

if (!isset($_SESSION['kullanici'])) {
    echo json_encode([]); exit;
}
try {
    $sql = "SELECT e.*, GROUP_CONCAT(ea.kullanici_id) as atanan_kullanicilar
            FROM etkinlikler e
            LEFT JOIN etkinlik_atananlar ea ON e.id = ea.etkinlik_id
            GROUP BY e.id";
    $stmt = $db->query($sql);
    $etkinlikler = $stmt->fetchAll(PDO::FETCH_ASSOC);
    $events = [];
    foreach ($etkinlikler as $etkinlik) {
        $events[] = [
            'id'    => $etkinlik['id'],
            'title' => $etkinlik['baslik'],
            'start' => $etkinlik['baslangic'],
            'end'   => $etkinlik['bitis'],
            'extendedProps' => [
                'aciklama'      => $etkinlik['aciklama'],
                'kullanici_id'  => $etkinlik['atanan_kullanicilar'] ? explode(',', $etkinlik['atanan_kullanicilar']) : []
            ]
        ];
    }
    echo json_encode($events);
} catch (Exception $e) {
    echo json_encode([]);
}