<?php
session_start();
if (!isset($_SESSION['kullanici'])) {
    header("Location: giris.php");
    exit;
}

require_once 'baglan.php';

$kullanici_id = $_SESSION['kullanici']['id'];

// is_id parametresi kontrolü
if (!isset($_GET['is_id']) || !is_numeric($_GET['is_id'])) {
    echo "Geçersiz iş ID'si.";
    exit;
}

$is_id = (int)$_GET['is_id'];

// İşin gerçekten kullanıcıya ait olup olmadığını kontrol et (patron hariç)
$stmt_check = $db->prepare("
    SELECT * FROM isler 
    WHERE id = ? AND (
        calisan_id = ? OR 
        EXISTS (
            SELECT 1 FROM kullanicilar WHERE id = ? AND rutbe = 'patron'
        )
    )
");
$stmt_check->execute([$is_id, $kullanici_id, $kullanici_id]);
$is_kayit = $stmt_check->fetch(PDO::FETCH_ASSOC);

if (!$is_kayit) {
    echo "Bu işe erişim yetkiniz yok.";
    exit;
}

// İş geçmişi verilerini çek
$stmt = $db->prepare("SELECT * FROM is_gecmis WHERE is_id = ? ORDER BY tarih DESC");
$stmt->execute([$is_id]);
$gecmisler = $stmt->fetchAll(PDO::FETCH_ASSOC);

?>

<!doctype html>
<html lang="tr">
<head>
  <meta charset="UTF-8" />
  <title>İş Geçmişi - <?= htmlspecialchars($is_kayit['baslik']) ?></title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.6/dist/css/bootstrap.min.css" rel="stylesheet" />
</head>
<body>
<?php include 'parcalar/sidebar.php'; ?>
<?php include 'parcalar/navbar.php'; ?>

<div class="container mt-4" style="margin-left:250px;">
  <h3>İş Geçmişi: <?= htmlspecialchars($is_kayit['baslik']) ?></h3>

  <?php if (count($gecmisler) === 0): ?>
    <div class="alert alert-info">Bu işe ait herhangi bir geçmiş kaydı bulunamadı.</div>
  <?php else: ?>
    <table class="table table-bordered">
      <thead>
        <tr>
          <th>Durum</th>
          <th>Tarih</th>
        </tr>
      </thead>
      <tbody>
        <?php foreach ($gecmisler as $g): ?>
        <tr>
          <td><?= htmlspecialchars($g['durum']) ?></td>
          <td><?= htmlspecialchars($g['tarih']) ?></td>
        </tr>
        <?php endforeach; ?>
      </tbody>
    </table>
  <?php endif; ?>

  <a href="islerim.php" class="btn btn-secondary mt-3">Geri Dön</a>
</div>

</body>
</html>
