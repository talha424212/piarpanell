<?php
require_once 'baglan.php';

echo "<h2>Database Structure Check</h2>";

// Check kullanicilar table structure
$sql = "DESCRIBE kullanicilar";
$result = $db->query($sql);

echo "<h3>kullanicilar table structure:</h3>";
echo "<table border='1'>";
echo "<tr><th>Field</th><th>Type</th><th>Null</th><th>Key</th><th>Default</th><th>Extra</th></tr>";

while ($row = $result->fetch(PDO::FETCH_ASSOC)) {
    echo "<tr>";
    echo "<td>" . $row['Field'] . "</td>";
    echo "<td>" . $row['Type'] . "</td>";
    echo "<td>" . $row['Null'] . "</td>";
    echo "<td>" . $row['Key'] . "</td>";
    echo "<td>" . $row['Default'] . "</td>";
    echo "<td>" . $row['Extra'] . "</td>";
    echo "</tr>";
}
echo "</table>";

// Check sample data
echo "<h3>Sample data from kullanicilar:</h3>";
$sql = "SELECT * FROM kullanicilar LIMIT 3";
$result = $db->query($sql);

echo "<table border='1'>";
if ($result->rowCount() > 0) {
    $first = true;
    while ($row = $result->fetch(PDO::FETCH_ASSOC)) {
        if ($first) {
            echo "<tr>";
            foreach ($row as $key => $value) {
                echo "<th>" . $key . "</th>";
            }
            echo "</tr>";
            $first = false;
        }
        echo "<tr>";
        foreach ($row as $value) {
            echo "<td>" . ($value ?? 'NULL') . "</td>";
        }
        echo "</tr>";
    }
}
echo "</table>";

// Check if izinler table exists
echo "<h3>Checking izinler table:</h3>";
$sql = "SHOW TABLES LIKE 'izinler'";
$result = $db->query($sql);

if ($result->rowCount() > 0) {
    echo "izinler table exists<br>";
    
    $sql = "DESCRIBE izinler";
    $result = $db->query($sql);
    
    echo "<table border='1'>";
    echo "<tr><th>Field</th><th>Type</th><th>Null</th><th>Key</th><th>Default</th><th>Extra</th></tr>";
    
    while ($row = $result->fetch(PDO::FETCH_ASSOC)) {
        echo "<tr>";
        echo "<td>" . $row['Field'] . "</td>";
        echo "<td>" . $row['Type'] . "</td>";
        echo "<td>" . $row['Null'] . "</td>";
        echo "<td>" . $row['Key'] . "</td>";
        echo "<td>" . $row['Default'] . "</td>";
        echo "<td>" . $row['Extra'] . "</td>";
        echo "</tr>";
    }
    echo "</table>";
} else {
    echo "izinler table does not exist<br>";
}

// Check if isler table exists
echo "<h3>Checking isler table:</h3>";
$sql = "SHOW TABLES LIKE 'isler'";
$result = $db->query($sql);

if ($result->rowCount() > 0) {
    echo "isler table exists<br>";
    
    $sql = "DESCRIBE isler";
    $result = $db->query($sql);
    
    echo "<table border='1'>";
    echo "<tr><th>Field</th><th>Type</th><th>Null</th><th>Key</th><th>Default</th><th>Extra</th></tr>";
    
    while ($row = $result->fetch(PDO::FETCH_ASSOC)) {
        echo "<tr>";
        echo "<td>" . $row['Field'] . "</td>";
        echo "<td>" . $row['Type'] . "</td>";
        echo "<td>" . $row['Null'] . "</td>";
        echo "<td>" . $row['Key'] . "</td>";
        echo "<td>" . $row['Default'] . "</td>";
        echo "<td>" . $row['Extra'] . "</td>";
        echo "</tr>";
    }
    echo "</table>";
} else {
    echo "isler table does not exist<br>";
}
?> 