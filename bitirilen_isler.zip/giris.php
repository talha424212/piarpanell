<?php




session_start();
include 'baglan.php';

$hata = '';

// Giriş işlemi
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = $_POST['mail'] ?? '';
    $sifre = $_POST['sifre'] ?? '';

    if (!empty($email) && !empty($sifre)) {
        $query = $db->prepare("SELECT * FROM kullanicilar WHERE mail = ?");
        $query->execute([$email]);
        $kullanici = $query->fetch(PDO::FETCH_ASSOC);

        if ($kullanici && $kullanici['sifre'] === $sifre) {
            $_SESSION['kullanici'] = [
                'id' => $kullanici['id'],
                'email' => $kullanici['mail'],
                'rutbe' => $kullanici['rutbe']
            ];
            $_SESSION['giris_basarili'] = true; // 🔔 Toast tetikleyici
            header("Location: panel.php");
            exit;
        } else {
            $hata = "Hatalı email veya şifre!";
        }
    } else {
        $hata = "Tüm alanları doldurun.";
    }
}
?>

<!doctype html>
<html lang="tr">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <title>Giriş Ekranı - Bootstrap 5</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.6/dist/css/bootstrap.min.css" rel="stylesheet" />
  <style>
    body {
      background: linear-gradient(135deg, #6a11cb 0%, #2575fc 100%);
      height: 100vh;
      display: flex;
      justify-content: center;
      align-items: center;
    }
    .login-card {
      background: #fff;
      border-radius: 1rem;
      box-shadow: 0 0 15px rgba(0, 0, 0, 0.2);
      padding: 2rem;
      width: 100%;
      max-width: 400px;
    }
    .form-control:focus {
      box-shadow: 0 0 0 0.25rem rgba(37, 117, 252, 0.5);
      border-color: #2575fc;
    }
    .btn-primary {
      background-color: #2575fc;
      border-color: #2575fc;
    }
    .btn-primary:hover {
      background-color: #1a54c2;
      border-color: #1a54c2;
    }

    /* Toast container */
    .toast-container {
      position: fixed;
      top: 1rem;
      right: 1rem;
      z-index: 9999;
    }
  </style>
</head>
<body>

  <div class="login-card">
    <h3 class="mb-4 text-center text-primary">Piar Ofis Hesabınız İle Giriş Yapın</h3>

    <?php if ($hata): ?>
      <div class="alert alert-danger"><?= htmlspecialchars($hata) ?></div>
    <?php endif; ?>

    <form method="POST">
      <div class="mb-3">
        <label for="username" class="form-label">Email</label>
        <input type="email" class="form-control" id="username" name="mail" placeholder="Email adresinizi girin" required />
      </div>
      <div class="mb-3">
        <label for="password" class="form-label">Şifre</label>
        <input type="password" class="form-control" id="password" name="sifre" placeholder="Şifrenizi girin" required />
      </div>
      <div class="mb-3 form-check">
        <input type="checkbox" class="form-check-input" id="rememberMe" />
        <label class="form-check-label" for="rememberMe">Beni Hatırla</label>
      </div>
      <hr />
      <div class="d-flex justify-content-between align-items-center mb-3">
        <button type="submit" class="btn btn-primary px-4">Giriş Yap</button>
      </div>
    </form>
  </div>

  <!-- Toast (Giriş Başarılı) -->
  <?php if (isset($_SESSION['giris_basarili'])): ?>
    <div class="toast-container">
      <div class="toast align-items-center text-bg-success border-0 show" role="alert">
        <div class="d-flex">
          <div class="toast-body">
            ✅ Başarıyla giriş yaptınız!
          </div>
          <button type="button" class="btn-close btn-close-white me-2 m-auto" data-bs-dismiss="toast" aria-label="Kapat"></button>
        </div>
      </div>
    </div>
    <?php unset($_SESSION['giris_basarili']); ?>
  <?php endif; ?>

  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.6/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
