<?php
session_start();
if (!isset($_SESSION['kullanici'])) {
    echo json_encode([]);
    exit;
}

require_once 'baglan.php'; // Burada $db PDO bağlantısı var

$kullanici = $_SESSION['kullanici'];
$calisan_id = $kullanici['id'];

// Sadece okunmamış işleri getir
$sql = "SELECT id, baslik, baslama_tarihi FROM isler WHERE calisan_id = ? AND islerim_goruldu = 0 ORDER BY id DESC";
$stmt = $db->prepare($sql);
$stmt->execute([$calisan_id]);
$islerimler = $stmt->fetchAll(PDO::FETCH_ASSOC);

echo json_encode($islerimler);
