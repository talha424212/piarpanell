<?php
session_start();
header('Content-Type: application/json');

require_once 'baglan.php'; // $db burada tanımlı olacak

if (!isset($_SESSION['kullanici'])) {
    echo json_encode([
        'adet' => 0,
        'islerimler' => [],
        'hata' => 'Oturum bulunamadı'
    ]);
    exit;
}

$calisan_id = $_SESSION['kullanici']['id'];

try {
    // Yeni islerim sayısını al
    $stmt = $db->prepare("SELECT COUNT(*) FROM isler WHERE calisan_id = ? AND islerim_goruldu = 0");
    $stmt->execute([$calisan_id]);
    $adet = (int)$stmt->fetchColumn();

    // Son 10 islerimi al
    $stmt2 = $db->prepare("SELECT baslik FROM isler WHERE calisan_id = ? AND islerim_goruldu = 0 ORDER BY id DESC LIMIT 10");
    $stmt2->execute([$calisan_id]);
    $islerimler = $stmt2->fetchAll(PDO::FETCH_COLUMN);

    echo json_encode([
        'adet' => $adet,
        'islerimler' => $islerimler
    ]);
} catch (PDOException $e) {
    echo json_encode([
        'adet' => 0,
        'islerimler' => [],
        'hata' => $e->getMessage()
    ]);
}
