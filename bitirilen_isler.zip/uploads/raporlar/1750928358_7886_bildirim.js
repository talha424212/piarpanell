setInterval(() => {
    fetch("islerimleri-cek.php")
        .then(res => {
            if (!res.ok) throw new Error(`HTTP error ${res.status}`);
            return res.json();
        })
        .then(data => {
            if (data.sesli) {
                const audio = new Audio('ses/islerim.mp3');
                audio.play();
            }

            const badge = document.getElementById("islerim-badge");
            if (badge && data.adet > 0) {
                badge.style.display = "inline-block";
                badge.textContent = data.adet;
            } else if (badge) {
                badge.style.display = "none";
            }
        })
        .catch(err => console.error('Fetch error:', err));
}, 5000);
