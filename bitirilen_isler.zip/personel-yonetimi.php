<?php
session_start();
if (!isset($_SESSION['kullanici'])) {
    header("Location: giris.php");
    exit;
}

// Sadece 'patron' rolündeki kullanıcılar bu sayfayı görebilir.
if ($_SESSION['kullanici']['rutbe'] !== 'patron') {
    // Yetkisi olmayanlar için bir hata sayfası göstermek daha iyidir.
    die("Bu sayfaya erişim yetkiniz bulunmamaktadır."); 
}

require_once 'baglan.php';

$hata = '';
// Düzenleme sırasında bir hata oluşursa, hangi modal'ın açık kalması gerektiğini bilmek için.
$hata_olusan_id = null; 

$db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

// ============= İŞLEMLER BÖLÜMÜ =============

// --- Silme İşlemi ---
if (isset($_GET['sil_id'])) {
    $sil_id = (int)$_GET['sil_id'];
    $stmt = $db->prepare("DELETE FROM kullanicilar WHERE id = ?");
    $stmt->execute([$sil_id]);
    header("Location: personel_yonetimi.php?mesaj=silindi"); // Temiz URL için yönlendirme
    exit;
}

// --- Güncelleme İşlemi ---
if (isset($_POST['guncelle'])) {
    $id = (int)$_POST['id'];
    $isim = trim($_POST['isim']);
    $soyisim = trim($_POST['soyisim']);
    $mail = trim($_POST['mail']);
    $numara = trim($_POST['numara']);
    $rutbe = $_POST['rutbe'];

    // E-posta adresinin başka bir kullanıcı tarafından kullanılıp kullanılmadığını kontrol et
    $kontrol_stmt = $db->prepare("SELECT COUNT(*) FROM kullanicilar WHERE mail = ? AND id != ?");
    $kontrol_stmt->execute([$mail, $id]);
    
    if ($kontrol_stmt->fetchColumn() > 0) {
        $hata = "Bu e-posta adresi zaten başka bir kullanıcı tarafından kullanılıyor!";
        $hata_olusan_id = $id; // Hata durumunda hangi düzenleme modalının açık kalacağını belirt
    } else {
        // Şifre alanı boş değilse şifreyi güncelle
        if (!empty($_POST['sifre'])) {
            $sifre = password_hash($_POST['sifre'], PASSWORD_DEFAULT);
            $update_stmt = $db->prepare("UPDATE kullanicilar SET isim=?, soyisim=?, mail=?, numara=?, rutbe=?, sifre=? WHERE id=?");
            $update_stmt->execute([$isim, $soyisim, $mail, $numara, $rutbe, $sifre, $id]);
        } else { // Şifre boşsa, diğer alanları güncelle
            $update_stmt = $db->prepare("UPDATE kullanicilar SET isim=?, soyisim=?, mail=?, numara=?, rutbe=? WHERE id=?");
            $update_stmt->execute([$isim, $soyisim, $mail, $numara, $rutbe, $id]);
        }
        header("Location: personel-yonetimi.php");
        exit;
    }
}

// --- Yeni Kullanıcı Ekleme ---
if (isset($_POST['yeni_ekle'])) {
    $isim = trim($_POST['isim']);
    $soyisim = trim($_POST['soyisim']);
    $mail = trim($_POST['mail']);
    $numara = trim($_POST['numara']);
    $rutbe = $_POST['rutbe'];
    $sifre_plain = $_POST['sifre'];

    if(empty($sifre_plain)) {
        $hata = "Yeni kullanıcı için şifre alanı zorunludur.";
        $hata_olusan_id = 'yeni'; // Yeni ekleme modal'ını açık tut
    } else {
        $sifre = password_hash($sifre_plain, PASSWORD_DEFAULT);
        
        $kontrol_stmt = $db->prepare("SELECT COUNT(*) FROM kullanicilar WHERE mail = ?");
        $kontrol_stmt->execute([$mail]);

        if ($kontrol_stmt->fetchColumn() > 0) {
            $hata = "Bu e-posta adresi zaten kayıtlı!";
            $hata_olusan_id = 'yeni'; // Yeni ekleme modal'ını açık tut
        } else {
            $insert_stmt = $db->prepare("INSERT INTO kullanicilar (isim, soyisim, mail, sifre, numara, rutbe) VALUES (?, ?, ?, ?, ?, ?)");
            $insert_stmt->execute([$isim, $soyisim, $mail, $sifre, $numara, $rutbe]);
            header("Location: personel_yonetimi.php?mesaj=eklendi");
            exit;
        }
    }
}

// ============= VERİ ÇEKME BÖLÜMÜ =============
$kullanicilar = $db->query("SELECT * FROM kullanicilar ORDER BY id ASC")->fetchAll(PDO::FETCH_ASSOC);

// İstatistikler
$toplam_kullanici = count($kullanicilar);
$stats = array_count_values(array_column($kullanicilar, 'rutbe'));
$patron_sayisi = $stats['patron'] ?? 0;
$calisan_sayisi = $stats['calisan'] ?? 0;
$cirak_sayisi = $stats['cirak'] ?? 0;
$misafir_sayisi = $stats['misafir'] ?? 0;

// URL'den gelen mesajları yakala
$mesaj_text = '';
if(isset($_GET['mesaj'])) {
    switch($_GET['mesaj']) {
        case 'eklendi': $mesaj_text = "Yeni personel başarıyla eklendi."; break;
        case 'guncellendi': $mesaj_text = "Personel bilgileri başarıyla güncellendi."; break;
        case 'silindi': $mesaj_text = "Personel başarıyla silindi."; break;
    }
}

?>

<!DOCTYPE html>
<html lang="tr">
<head>
    <!-- ... head içeriğiniz... Hiçbir değişiklik yok. ... -->
    <meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1.0"><title>Personel Yönetimi - Piar Panel</title><link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet"><link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.6/dist/css/bootstrap.min.css" rel="stylesheet">
    <style> /* Sizin orijinal temanız... Hiçbir değişiklik yok. ... */ *{margin:0;padding:0;box-sizing:border-box}body{background:linear-gradient(135deg,#667eea 0%,#764ba2 50%,#f093fb 100%);min-height:100vh;font-family:'Segoe UI',Tahoma,Geneva,Verdana,sans-serif;overflow-x:hidden}.main-content{margin-left:280px;padding:100px 2rem 2rem;transition:all .4s cubic-bezier(.175,.885,.32,1.275)}.main-content.sidebar-collapsed{margin-left:80px}.page-header{background:rgba(255,255,255,.1);backdrop-filter:blur(20px);border-radius:20px;padding:2rem;margin-bottom:2rem;border:1px solid rgba(255,255,255,.2);box-shadow:0 8px 32px rgba(0,0,0,.1)}.page-title{color:#fff;font-size:2.5rem;font-weight:800;margin-bottom:.5rem;text-shadow:0 2px 4px rgba(0,0,0,.3)}.page-subtitle{color:rgba(255,255,255,.8);font-size:1.1rem;font-weight:400}.stats-grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(250px,1fr));gap:1.5rem;margin-bottom:2rem}.stat-card{background:rgba(255,255,255,.1);backdrop-filter:blur(20px);border-radius:20px;padding:2rem;border:1px solid rgba(255,255,255,.2);box-shadow:0 8px 32px rgba(0,0,0,.1);transition:all .3s cubic-bezier(.175,.885,.32,1.275);position:relative;overflow:hidden}.stat-card::before{content:'';position:absolute;top:0;left:-100%;width:100%;height:100%;background:linear-gradient(90deg,transparent,rgba(255,255,255,.1),transparent);transition:left .5s ease}.stat-card:hover::before{left:100%}.stat-card:hover{transform:translateY(-10px) scale(1.02);box-shadow:0 20px 40px rgba(0,0,0,.2)}.stat-icon{width:60px;height:60px;border-radius:15px;display:flex;align-items:center;justify-content:center;font-size:1.5rem;color:#fff;margin-bottom:1rem;box-shadow:0 8px 25px rgba(0,0,0,.2)}.stat-number{font-size:2.5rem;font-weight:800;color:#fff;margin-bottom:.5rem;text-shadow:0 2px 4px rgba(0,0,0,.3)}.stat-label{color:rgba(255,255,255,.8);font-size:1rem;font-weight:500}.content-card{background:rgba(255,255,255,.1);backdrop-filter:blur(20px);border-radius:20px;padding:2rem;border:1px solid rgba(255,255,255,.2);box-shadow:0 8px 32px rgba(0,0,0,.1);margin-bottom:2rem}.card-header{display:flex;justify-content:space-between;align-items:center;margin-bottom:2rem;flex-wrap:wrap;gap:1rem}.card-title{color:#fff;font-size:1.8rem;font-weight:700;margin:0}.btn-modern{background:linear-gradient(135deg,#667eea 0%,#764ba2 100%);border:none;color:#fff;padding:.75rem 1.5rem;border-radius:15px;font-weight:600;text-decoration:none;display:inline-flex;align-items:center;gap:.5rem;transition:all .3s cubic-bezier(.175,.885,.32,1.275);box-shadow:0 8px 25px rgba(102,126,234,.3)}.btn-modern:hover{transform:translateY(-3px) scale(1.05);box-shadow:0 15px 35px rgba(102,126,234,.4);color:#fff;text-decoration:none}.btn-success-modern{background:linear-gradient(135deg,#56ab2f 0%,#a8e6cf 100%);box-shadow:0 8px 25px rgba(86,171,47,.3)}.btn-success-modern:hover{box-shadow:0 15px 35px rgba(86,171,47,.4)}.btn-danger-modern{background:linear-gradient(135deg,#ff416c 0%,#ff4b2b 100%);box-shadow:0 8px 25px rgba(255,65,108,.3)}.btn-danger-modern:hover{box-shadow:0 15px 35px rgba(255,65,108,.4)}.btn-warning-modern{background:linear-gradient(135deg,#f7971e 0%,#ffd200 100%);box-shadow:0 8px 25px rgba(247,151,30,.3)}.btn-warning-modern:hover{box-shadow:0 15px 35px rgba(247,151,30,.4)}.table-modern{background:0 0;border-radius:20px;overflow:hidden;box-shadow:0 8px 32px rgba(0,0,0,.08);border-collapse:collapse}.table-modern th{background:rgba(255,255,255,.13);color:#fff;font-weight:700;border:none;padding:18px 16px;font-size:1.05rem;letter-spacing:.5px;text-align:left}.table-modern td{color:#fff;border:none;border-top:1px solid rgba(255,255,255,.1);padding:16px;vertical-align:middle;font-size:1rem;background:rgba(255,255,255,.07);transition:background .2s}.table-modern tbody tr:first-child td{border-top:none}.table-modern tbody tr:hover td{background:rgba(102,126,234,.18)}.status-badge{padding:6px 14px;border-radius:16px;font-size:.95rem;font-weight:600;letter-spacing:.5px;display:inline-block;text-shadow:0 1px 2px #0002}.status-patron{background:linear-gradient(90deg,#667eea,#764ba2);color:#fff}.status-calisan{background:linear-gradient(90deg,#4facfe,#00f2fe);color:#fff}.status-cirak{background:linear-gradient(90deg,#43e97b,#38f9d7);color:#fff}.status-misafir{background:linear-gradient(90deg,#fa709a,#fee140);color:#fff}.table-modern .btn-modern.btn-sm{padding:6px 10px;font-size:.95rem;border-radius:10px;margin:0 2px}.table-modern a{color:#fff;text-decoration:none;transition:all .3s ease}.table-modern a:hover{color:#a8baff;text-decoration:none}.modal-modern .modal-content{background:rgba(25,28,44,.5);backdrop-filter:blur(20px);border:1px solid rgba(255,255,255,.2);border-radius:20px;box-shadow:0 20px 60px rgba(0,0,0,.3)}.modal-modern .modal-header{border-bottom:1px solid rgba(255,255,255,.1);color:#fff}.modal-modern .modal-body{color:rgba(255,255,255,.9)}.modal-modern .form-control,.modal-modern .form-select{background:rgba(255,255,255,.1);border:1px solid rgba(255,255,255,.2);color:#fff;border-radius:10px}.modal-modern .form-control option,.modal-modern .form-select option{color:#000;background:#fff}.modal-modern .form-control:focus,.modal-modern .form-select:focus{background:rgba(255,255,255,.15);border-color:rgba(255,255,255,.4);box-shadow:0 0 0 3px rgba(255,255,255,.1);color:#fff}.modal-modern .form-control::placeholder{color:rgba(255,255,255,.6)}.alert-danger-modern{background:rgba(255,65,108,.2);border-color:rgba(255,65,108,.3);border-radius:15px;color:#fff;padding:1rem 1.5rem;margin-bottom:2rem;border:1px solid}.alert-success-modern{background:rgba(86,171,47,.2);border-color:rgba(86,171,47,.3);border-radius:15px;color:#fff;padding:1rem 1.5rem;margin-bottom:2rem;border:1px solid} </style>
</head>
<body>
    <?php include 'parcalar/sidebar.php'; ?>
    <?php include 'parcalar/navbar.php'; ?>
    <div class="main-content" id="mainContent">
        <div class="page-header">
            <h1 class="page-title"><i class="fas fa-users-cog me-3"></i> Personel Yönetimi</h1>
            <p class="page-subtitle">Şirket personelini yönetin ve takip edin</p>
        </div>
        
        <?php if ($hata): // Sunucu taraflı bir hata varsa (mail tekrarı gibi) ?>
            <div class="alert alert-danger-modern"><i class="fas fa-exclamation-triangle me-2"></i><?= htmlspecialchars($hata) ?></div>
        <?php elseif ($mesaj_text): // Başarılı işlem mesajı varsa (GET'ten gelen) ?>
            <div class="alert alert-success-modern"><i class="fas fa-check-circle me-2"></i><?= htmlspecialchars($mesaj_text) ?></div>
        <?php endif; ?>

        <div class="stats-grid"><!-- ... istatistik kartları olduğu gibi kalacak ... --></div>

        <div class="content-card">
            <div class="card-header">
                <h2 class="card-title"><i class="fas fa-list me-2"></i>Personel Listesi</h2>
                <button class="btn btn-modern btn-success-modern" data-bs-toggle="modal" data-bs-target="#yeniKullaniciModal"><i class="fas fa-plus"></i>Yeni Personel Ekle</button>
            </div>
            <div class="table-responsive">
                <table class="table table-modern align-middle">
                    <!-- ... thead kısmı olduğu gibi kalacak ... -->
                    <tbody>
                        <?php foreach ($kullanicilar as $kullanici_dongu): // 'kullanici' değişkeniyle çakışmaması için adı değiştirildi ?>
                        <tr>
                            <td><strong><?= $kullanici_dongu['id'] ?></strong></td>
                            <td><?= htmlspecialchars($kullanici_dongu['isim'] . ' ' . $kullanici_dongu['soyisim']) ?></td>
                            <td><a href="mailto:<?= htmlspecialchars($kullanici_dongu['mail']) ?>"><?= htmlspecialchars($kullanici_dongu['mail']) ?></a></td>
                            <td><?= htmlspecialchars($kullanici_dongu['numara'] ?: '-') ?></td>
                            <td><span class="status-badge status-<?= htmlspecialchars($kullanici_dongu['rutbe']) ?>"><?= ucfirst(htmlspecialchars($kullanici_dongu['rutbe'])) ?></span></td>
                            <td class="text-center">
                                <button class="btn btn-modern btn-sm" data-bs-toggle="modal" data-bs-target="#duzenleModal<?= $kullanici_dongu['id'] ?>"><i class="fas fa-edit"></i></button>
                                <a href="personel_yonetimi.php?sil_id=<?= $kullanici_dongu['id'] ?>" onclick="return confirm('Bu personeli silmek istediğinize emin misiniz?')" class="btn btn-modern btn-danger-modern btn-sm"><i class="fas fa-trash"></i></a>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

    <!-- Modallar Döngünün Dışında Tanımlanmalı -->
    <?php foreach ($kullanicilar as $kullanici_dongu): ?>
    <!-- Düzenleme Modal -->
    <div class="modal fade modal-modern" id="duzenleModal<?= $kullanici_dongu['id'] ?>" tabindex="-1">
        <div class="modal-dialog modal-lg">
            <form method="POST" action="">
                <input type="hidden" name="id" value="<?= $kullanici_dongu['id'] ?>">
                <div class="modal-content">
                    <div class="modal-header"><h5 class="modal-title">Personel Düzenle</h5><button type="button" class="btn-close" data-bs-dismiss="modal"></button></div>
                    <div class="modal-body">
                         <div class="row">
                            <div class="col-md-6 mb-3"><label class="form-label">İsim</label><input type="text" name="isim" class="form-control" value="<?= htmlspecialchars($kullanici_dongu['isim']) ?>" required></div>
                            <div class="col-md-6 mb-3"><label class="form-label">Soyisim</label><input type="text" name="soyisim" class="form-control" value="<?= htmlspecialchars($kullanici_dongu['soyisim']) ?>" required></div>
                            <div class="col-md-6 mb-3"><label class="form-label">E-posta</label><input type="email" name="mail" class="form-control" value="<?= htmlspecialchars($kullanici_dongu['mail']) ?>" required></div>
                            <div class="col-md-6 mb-3"><label class="form-label">Telefon</label><input type="text" name="numara" class="form-control" value="<?= htmlspecialchars($kullanici_dongu['numara']) ?>"></div>
                            <div class="col-md-6 mb-3"><label class="form-label">Rütbe</label><select name="rutbe" class="form-select" required><option value="patron" <?= $kullanici_dongu['rutbe'] === 'patron' ? 'selected' : '' ?>>Patron</option><option value="calisan" <?= $kullanici_dongu['rutbe'] === 'calisan' ? 'selected' : '' ?>>Çalışan</option></select></div>
                            <div class="col-md-6 mb-3"><label class="form-label">Yeni Şifre (Değişmeyecekse boş bırakın)</label><input type="password" name="sifre" class="form-control"></div>
                        </div>
                    </div>
                    <div class="modal-footer"><button type="button" class="btn btn-secondary" data-bs-dismiss="modal">İptal</button><button type="submit" name="guncelle" class="btn btn-primary">Güncelle</button></div>
                </div>
            </form>
        </div>
    </div>
    <?php endforeach; ?>

    <!-- Yeni Kullanıcı Ekle Modal -->
    <div class="modal fade modal-modern" id="yeniKullaniciModal" tabindex="-1">
         <div class="modal-dialog modal-lg">
            <form method="POST" action="personel_yonetimi.php">
                <div class="modal-content">
                    <div class="modal-header"><h5 class="modal-title">Yeni Personel Ekle</h5><button type="button" class="btn-close" data-bs-dismiss="modal"></button></div>
                    <div class="modal-body"><!-- ... form içeriği olduğu gibi kalacak ... --></div>
                    <div class="modal-footer"><button type="button" class="btn btn-secondary" data-bs-dismiss="modal">İptal</button><button type="submit" name="yeni_ekle" class="btn btn-success">Ekle</button></div>
                </div>
            </form>
        </div>
    </div>
    
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.6/dist/js/bootstrap.bundle.min.js"></script>
    <script>
    document.addEventListener('DOMContentLoaded', function() {
        <?php if (!empty($hata) && !empty($hata_olusan_id)): ?>
        // Hata varsa, ilgili modal'ı JavaScript ile tekrar aç.
        var modalIdToOpen = '<?= ($hata_olusan_id === "yeni") ? "yeniKullaniciModal" : "duzenleModal{$hata_olusan_id}" ?>';
        var errorModal = new bootstrap.Modal(document.getElementById(modalIdToOpen));
        errorModal.show();
        <?php endif; ?>
    });
    </script>
</body>
</html>