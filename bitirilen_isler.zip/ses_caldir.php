<?php
session_start();
require_once 'baglan.php';

if (!isset($_SESSION['kullanici']) || $_SESSION['kullanici']['rutbe'] !== 'patron') {
    http_response_code(403);
    echo "Yetkisiz erişim.";
    exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['id'])) {
    $hedef_id = (int)$_POST['id'];

    try {
        $stmt = $db->prepare("INSERT INTO islerimler (kullanici_id, mesaj, sesli, olusturma_tarihi) VALUES (?, ?, ?, NOW())");
        $stmt->execute([$hedef_id, 'Yöneticiden uyarı sesi', 1]);

        echo "Ses çaldırıldı.";
    } catch (PDOException $e) {
        http_response_code(500);
        echo "Veritabanı hatası: " . $e->getMessage();
    }
} else {
    http_response_code(400);
    echo "Geçersiz istek.";
}
