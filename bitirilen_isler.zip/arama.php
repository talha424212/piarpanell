<?php
// arama.php
if (session_status() === PHP_SESSION_NONE) { session_start(); }

// Basit XSS önlemi
$q = isset($_GET['q']) ? trim($_GET['q']) : '';

?>

<!DOCTYPE html>
<html lang="tr">
<head>
<meta charset="UTF-8" />
<meta name="viewport" content="width=device-width, initial-scale=1" />
<title>Arama Sonuçları - <?= htmlspecialchars($q) ?></title>
<style>
  body { font-family: Arial, sans-serif; background:#121212; color:#eee; padding: 2rem; }
  a { color: #6c63ff; text-decoration: none; }
  a:hover { text-decoration: underline; }
  .result { margin-bottom: 1rem; padding: 1rem; background: #222; border-radius: 8px; }
</style>
</head>
<body>

<h1>Site İçinde Arama</h1>

<form action="arama.php" method="GET" autocomplete="off">
  <input type="search" name="q" value="<?= htmlspecialchars($q) ?>" placeholder="Arama yapın..." style="width: 300px; padding: 0.5rem; border-radius: 8px; border: none;"/>
  <button type="submit" style="padding: 0.5rem 1rem; border-radius: 8px; border:none; background:#6c63ff; color:white; cursor:pointer;">Ara</button>
</form>

<hr style="margin: 2rem 0; border-color:#444;" />

<?php if ($q === ''): ?>
  <p>Lütfen arama yapmak için yukarıdaki kutucuğa bir şeyler yazın.</p>
<?php else: ?>
  <h2>Arama Sonuçları: "<?= htmlspecialchars($q) ?>"</h2>

  <?php
  // Burada gerçek veritabanı araması yapabilirsin, şimdilik demo sonuçlar:

  // Örnek sabit veri (sayfa, başlık, açıklama)
  $site_icerigi = [
    ['url' => 'index.php', 'baslik' => 'Anasayfa', 'aciklama' => 'Site ana sayfası ve genel bilgiler.'],
    ['url' => 'hakkimizda.php', 'baslik' => 'Hakkımızda', 'aciklama' => 'Bizimle ilgili detaylı bilgi.'],
    ['url' => 'iletisim.php', 'baslik' => 'İletişim', 'aciklama' => 'Bize nasıl ulaşabilirsiniz.'],
    ['url' => 'blog.php', 'baslik' => 'Blog', 'aciklama' => 'Güncel yazılar ve haberler.'],
    ['url' => 'profil.php', 'baslik' => 'Profiliniz', 'aciklama' => 'Kullanıcı profilinizin yönetimi.'],
  ];

  // Basit anahtar kelime araması (büyük/küçük harf duyarsız)
  $aranan = mb_strtolower($q);
  $sonuclar = [];

  foreach ($site_icerigi as $icerik) {
    if (
      mb_stripos($icerik['baslik'], $q) !== false ||
      mb_stripos($icerik['aciklama'], $q) !== false
    ) {
      $sonuclar[] = $icerik;
    }
  }

  if (count($sonuclar) === 0) {
    echo '<p>Aramanız için sonuç bulunamadı.</p>';
  } else {
    foreach ($sonuclar as $sonuc) {
      echo '<div class="result">';
      echo '<a href="' . htmlspecialchars($sonuc['url']) . '"><h3>' . htmlspecialchars($sonuc['baslik']) . '</h3></a>';
      echo '<p>' . htmlspecialchars($sonuc['aciklama']) . '</p>';
      echo '</div>';
    }
  }
  ?>

<?php endif; ?>

</body>
</html>
