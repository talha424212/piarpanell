<?php
require_once 'baglan.php';

$etkinlikId = $_POST['etkinlikId'] ?? null;
$baslik = $_POST['baslik'] ?? '';
$aciklama = $_POST['aciklama'] ?? '';
$tarih = $_POST['tarih'] ?? '';
$saat_baslangic = $_POST['saat_baslangic'] ?? '';
$saat_bitis = $_POST['saat_bitis'] ?? '';
$kullanicilar = $_POST['kullanicilar'] ?? [];

if (!$baslik || !$tarih || !$saat_baslangic || !$saat_bitis || empty($kullanicilar)) {
    echo json_encode(['success' => false, 'message' => 'Lütfen tüm zorunlu alanları doldurun.']);
    exit;
}

try {
    if ($etkinlikId) {
        // Güncelle
        $stmt = $db->prepare("UPDATE etkinlikler SET baslik=?, aciklama=?, tarih=?, saat_baslangic=?, saat_bitis=? WHERE id=?");
        $stmt->execute([$baslik, $aciklama, $tarih, $saat_baslangic, $saat_bitis, $etkinlikId]);

        $db->prepare("DELETE FROM etkinlik_kullanici WHERE etkinlik_id=?")->execute([$etkinlikId]);

        foreach ($kullanicilar as $kullanici_id) {
            $db->prepare("INSERT INTO etkinlik_kullanici (etkinlik_id, kullanici_id) VALUES (?, ?)")->execute([$etkinlikId, $kullanici_id]);
        }
    } else {
        // Yeni ekle
        $stmt = $db->prepare("INSERT INTO etkinlikler (baslik, aciklama, tarih, saat_baslangic, saat_bitis) VALUES (?, ?, ?, ?, ?)");
        $stmt->execute([$baslik, $aciklama, $tarih, $saat_baslangic, $saat_bitis]);
        $yeniId = $db->lastInsertId();

        foreach ($kullanicilar as $kullanici_id) {
            $db->prepare("INSERT INTO etkinlik_kullanici (etkinlik_id, kullanici_id) VALUES (?, ?)")->execute([$yeniId, $kullanici_id]);
        }
    }

    echo json_encode(['success' => true]);
} catch (PDOException $e) {
    echo json_encode(['success' => false, 'message' => 'Veritabanı hatası: ' . $e->getMessage()]);
}
