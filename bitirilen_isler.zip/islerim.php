<?php
session_start();
require_once 'baglan.php';

if (!isset($_SESSION['kullanici'])) {
    header("Location: giris.php");
    exit;
}
$kullanici = $_SESSION['kullanici'];

// VERİ ÇEKME
$stats_stmt = $db->prepare("SELECT COUNT(*) as toplam_is, SUM(CASE WHEN durum = 'bitirildi' THEN 1 ELSE 0 END) as tamamlanan_is, SUM(CASE WHEN durum = 'baslandi' THEN 1 ELSE 0 END) as devam_eden_is, SUM(CASE WHEN durum = 'verildi' THEN 1 ELSE 0 END) as bekleyen_is, SUM(CASE WHEN durum = 'durduruldu' THEN 1 ELSE 0 END) as durdurulan_is, SUM(CASE WHEN durum = 'iptal' THEN 1 ELSE 0 END) as iptal_edilen_is FROM islerim WHERE calisan_id = ?");
$stats_stmt->execute([$kullanici['id']]);
$stats = $stats_stmt->fetch(PDO::FETCH_ASSOC);

$isler_stmt = $db->prepare("SELECT * FROM islerim WHERE calisan_id = ? ORDER BY atama_tarihi DESC");
$isler_stmt->execute([$kullanici['id']]);
$isler_listesi = $isler_stmt->fetchAll(PDO::FETCH_ASSOC);

// Dosyaları çekme
$dosyalar_stmt = $db->prepare("SELECT * FROM bitmis_isler");
$dosyalar_stmt->execute();
$dosyalar_listesi = $dosyalar_stmt->fetchAll(PDO::FETCH_ASSOC);
$dosyalar_gruplu = [];
foreach ($dosyalar_listesi as $dosya) {
    $dosyalar_gruplu[$dosya['is_id']][] = $dosya;
}

// İşleri gruplama
$is_gruplari = ['verildi' => [], 'baslandi' => [], 'bitirildi' => [], 'durduruldu' => [], 'iptal' => []];
foreach ($isler_listesi as $is) {
    if (array_key_exists($is['durum'], $is_gruplari)) {
        $is_gruplari[$is['durum']][] = $is;
    }
}

function render_task_card($is, $dosyalar = []) {
    $is_geciken = ($is['bitis_tarihi'] && strtotime($is['bitis_tarihi']) < time() && !in_array($is['durum'], ['bitirildi', 'iptal']));
    echo "<div class='task-card " . ($is_geciken ? 'urgent' : '') . "' data-search='" . strtolower(htmlspecialchars($is['baslik'] . ' ' . $is['aciklama'])) . "'>
        <div class='task-header'>
            <h3 class='task-title'>" . htmlspecialchars($is['baslik']) . "</h3>
            <span class='task-status " . $is['durum'] . "'>" . ucfirst($is['durum']) . "</span>
        </div>
        <p class='task-description'>" . htmlspecialchars($is['aciklama']) . "</p>";

    if ($is['durum'] === 'bitirildi' && !empty($is['tamamlama_notu'])) {
        echo "<div class='alert alert-info mt-3' role='alert'>" . nl2br(htmlspecialchars($is['tamamlama_notu'])) . "</div>";
    }

    echo "<div class='task-actions'>";
    
    // BUTONLAR GERİ GELDİ
    if ($is['durum']==='verildi') echo "<button class='task-btn primary' onclick='updateTaskStatus(".$is['id'].", \"baslandi\")'><i class='fas fa-play'></i> Başlat</button>";
    elseif ($is['durum']==='baslandi') echo "<button class='task-btn success' data-bs-toggle='modal' data-bs-target='#completeTaskModal' data-task-id='".$is['id']."'> <i class='fas fa-check'></i> Tamamla</button><button class='task-btn warning' onclick='updateTaskStatus(".$is['id'].", \"durduruldu\")'><i class='fas fa-pause'></i> Durdur</button>";
    elseif ($is['durum']==='durduruldu') echo "<button class='task-btn primary' onclick='updateTaskStatus(".$is['id'].", \"baslandi\")'><i class='fas fa-play'></i> Devam Et</button>";
    
    if ($is['durum'] === 'bitirildi') {
        if (!empty($dosyalar)) {
            if(count($dosyalar) == 1) {
                echo "<a href='".htmlspecialchars(end($dosyalar)['dosya_yolu'])."' target='_blank' class='task-btn success'><i class='fas fa-eye'></i> Yüklenen Dosya</a>";
            } else {
                echo '<div class="dropdown">
                        <button class="task-btn success dropdown-toggle" type="button" data-bs-toggle="dropdown" aria-expanded="false"><i class="fas fa-eye"></i> Yüklenen Dosyalar</button>
                        <ul class="dropdown-menu dropdown-menu-dark">';
                foreach($dosyalar as $dosya) { echo "<li><a class='dropdown-item' href='".htmlspecialchars($dosya['dosya_yolu'])."' target='_blank'>".htmlspecialchars($dosya['dosya_adi'])."</a></li>"; }
                echo '</ul></div>';
            }
        }
        echo "<button class='task-btn warning' data-bs-toggle='modal' data-bs-target='#completeTaskModal' data-task-id='".$is['id']."'><i class='fas fa-plus'></i> Not/Yeni Dosya Ekle</button>";
    }

    if (!in_array($is['durum'], ['bitirildi', 'iptal'])) echo "<button class='task-btn danger' onclick='updateTaskStatus(".$is['id'].", \"iptal\")'><i class='fas fa-times'></i> İptal Et</button>";
    echo "<a href='is_gecmis.php?id=".$is['id']."' class='task-btn primary'><i class='fas fa-history'></i> Geçmiş</a>";
    echo "</div></div>";
}
function render_empty_state($title) { echo "<div class='empty-state text-center p-5'><i class='fas fa-inbox fa-3x mb-3 opacity-50'></i><h4>$title</h4><p class='opacity-75'>Bu sekmede gösterilecek bir iş bulunmuyor.</p></div>";}
?>
<!doctype html>
<html lang="tr">
<head>
    <meta charset="UTF-8" />
    <title>İşlerim - Piar Panel</title>
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.6/dist/css/bootstrap.min.css" rel="stylesheet" />
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet" />
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&display=swap" rel="stylesheet" />
    <style>
    /* ORİJİNAL TASARIMINIZA DOKUNULMADAN GEREKLİ MİNİK DÜZENLEMELER YAPILMIŞ CSS */
    :root { --primary-gradient: linear-gradient(135deg, #667eea 0%, #764ba2 100%); }
    * {font-family: 'Inter', sans-serif;}
    body { background: var(--primary-gradient); min-height: 100vh; color: white; }
    .main-content { margin-left: 280px; padding: 2rem; }
    .page-header { background: rgba(255, 255, 255, 0.1); backdrop-filter: blur(10px); border: 1px solid rgba(255, 255, 255, 0.2); border-radius: 20px; padding: 2rem; margin-bottom: 2rem; }
    .page-title { font-weight: 800; font-size: 2.5rem; }
    .stats-grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(180px, 1fr)); gap: 1.5rem; margin-bottom: 2rem; }
    .stat-card { background: rgba(255, 255, 255, 0.1); border-radius: 20px; padding: 1.5rem; text-align: center; }
    .stat-icon { font-size: 2.5rem; margin-bottom: 1rem; }
    .stat-number { font-size: 2rem; font-weight: 700; }
    .task-tabs .nav-link { color: rgba(255,255,255,0.7); font-weight: 600; border:0; background: transparent !important;}
    .task-tabs .nav-link.active { color: white; border-bottom: 2px solid white; border-radius: 0; }
    .task-tabs .badge { background-color: rgba(255,255,255,0.2); }
    .tab-content { padding-top: 1.5rem; }
    .task-card { background: rgba(255, 255, 255, 0.08); border-radius: 15px; padding: 1.5rem; margin-bottom: 1.5rem; border: 1px solid rgba(255,255,255,0.1); }
    .task-header { display: flex; justify-content: space-between; align-items: flex-start; margin-bottom: 1rem; }
    .task-title { font-weight: 600; font-size:1.3rem; }
    .task-status { padding: .4rem .8rem; border-radius: 20px; font-weight: 600; font-size: .8rem; }
    .task-status.verildi { background: #ffc107; color: #333; }
    .task-status.baslandi { background: #0dcaf0; color: #333; }
    .task-status.durduruldu { background: #6c757d; color: white; }
    .task-status.bitirildi { background: #198754; color: white; }
    .task-status.iptal { background: #dc3545; color: white; }
    .task-actions { display: flex; gap: .75rem; flex-wrap: wrap; margin-top: 1.5rem; }
    .task-btn { padding: .6rem 1.2rem; border: none; border-radius: 10px; font-weight: 600; text-decoration: none; display: inline-flex; align-items: center; gap: .5rem; color: white !important; transition: all .2s; }
    .task-btn:hover { transform: translateY(-2px); filter: brightness(1.1); }
    .task-btn.primary { background: #6c5ce7; }
    .task-btn.success { background: #00b894; }
    .task-btn.warning { background: #fdcb6e; color: #333 !important; }
    .task-btn.danger { background: #d63031; }
    .modal-content { background: #2d3436; border: 1px solid rgba(255,255,255,0.2); color: white; }
    .modal-header, .modal-footer { border-color: rgba(255,255,255,0.1); }
    .form-control { background-color: rgba(0,0,0,0.2); border-color: rgba(255,255,255,0.2); color:white; }
    .form-control:focus { background-color: rgba(0,0,0,0.3); color:white; box-shadow:none; }
    .btn-close { filter: invert(1); }
    @media (max-width: 992px) { .main-content { margin-left: 0; } }
    </style>
</head>
<body>
    <?php include 'parcalar/sidebar.php'; ?>
    <?php include 'parcalar/navbar.php'; ?>
    <div class="main-content">
        <div class="container-fluid">
            <div class="page-header"><h1 class="page-title"><i class="fas fa-tasks me-3"></i>İşlerim</h1></div>
            <div class="stats-grid">
                <div class="stat-card"> <div class="stat-number"><?= (int)($stats['toplam_is'] ?? 0) ?></div> <div>Toplam İş</div> </div>
                <div class="stat-card"> <div class="stat-number"><?= (int)($stats['tamamlanan_is'] ?? 0) ?></div> <div>Tamamlanan</div> </div>
                <div class="stat-card"> <div class="stat-number"><?= (int)($stats['devam_eden_is'] ?? 0) ?></div> <div>Devam Eden</div> </div>
                <div class="stat-card"> <div class="stat-number"><?= (int)($stats['durdurulan_is'] ?? 0) ?></div> <div>Durdurulan</div> </div>
                <div class="stat-card"> <div class="stat-number"><?= (int)($stats['iptal_edilen_is'] ?? 0) ?></div> <div>İptal Edilen</div> </div>
            </div>

            <ul class="nav nav-tabs task-tabs mb-3" role="tablist">
                 <li class="nav-item" role="presentation"><button class="nav-link active" data-bs-toggle="pill" data-bs-target="#tab-verildi">Bekleyen <span class="badge rounded-pill ms-2"><?= count($is_gruplari['verildi']) ?></span></button></li>
                 <li class="nav-item" role="presentation"><button class="nav-link" data-bs-toggle="pill" data-bs-target="#tab-baslandi">Devam Eden <span class="badge rounded-pill ms-2"><?= count($is_gruplari['baslandi']) ?></span></button></li>
                 <li class="nav-item" role="presentation"><button class="nav-link" data-bs-toggle="pill" data-bs-target="#tab-bitirildi">Tamamlanan <span class="badge rounded-pill ms-2"><?= count($is_gruplari['bitirildi']) ?></span></button></li>
                 <li class="nav-item" role="presentation"><button class="nav-link" data-bs-toggle="pill" data-bs-target="#tab-durduruldu">Durdurulan <span class="badge rounded-pill ms-2"><?= count($is_gruplari['durduruldu']) ?></span></button></li>
                 <li class="nav-item" role="presentation"><button class="nav-link" data-bs-toggle="pill" data-bs-target="#tab-iptal">İptal Edilen <span class="badge rounded-pill ms-2"><?= count($is_gruplari['iptal']) ?></span></button></li>
            </ul>
        
            <div class="tab-content">
                <div class="tab-pane fade show active" id="tab-verildi"><?php if(empty($is_gruplari['verildi'])) render_empty_state('Bekleyen İş Yok'); else foreach($is_gruplari['verildi'] as $is) render_task_card($is); ?></div>
                <div class="tab-pane fade" id="tab-baslandi"><?php if(empty($is_gruplari['baslandi'])) render_empty_state('Devam Eden İş Yok'); else foreach($is_gruplari['baslandi'] as $is) render_task_card($is); ?></div>
                <div class="tab-pane fade" id="tab-bitirildi"><?php if(empty($is_gruplari['bitirildi'])) render_empty_state('Tamamlanmış İş Yok'); else foreach($is_gruplari['bitirildi'] as $is) render_task_card($is, $dosyalar_gruplu[$is['id']] ?? []); ?></div>
                <div class="tab-pane fade" id="tab-durduruldu"><?php if(empty($is_gruplari['durduruldu'])) render_empty_state('Durdurulan İş Yok'); else foreach($is_gruplari['durduruldu'] as $is) render_task_card($is); ?></div>
                <div class="tab-pane fade" id="tab-iptal"><?php if(empty($is_gruplari['iptal'])) render_empty_state('İptal Edilmiş İş Yok'); else foreach($is_gruplari['iptal'] as $is) render_task_card($is); ?></div>
            </div>
        </div>
    </div>
    
    <div class="modal fade" id="completeTaskModal" tabindex="-1">
        <div class="modal-dialog modal-dialog-centered"><div class="modal-content"><form id="completeTaskForm">
            <div class="modal-header"><h5 class="modal-title">Görevi Tamamla / Güncelle</h5><button type="button" class="btn-close" data-bs-dismiss="modal"></button></div>
            <div class="modal-body">
                <input type="hidden" name="task_id" id="modal_task_id"><input type="hidden" name="new_status" value="bitirildi">
                <div class="mb-3"><label class="form-label">Not</label><textarea class="form-control" name="tamamlama_notu" rows="3"></textarea></div>
                <div class="mb-3"><label class="form-label">Yeni Dosya Ekle</label><input class="form-control" type="file" name="teslim_dosyasi"></div>
            </div>
            <div class="modal-footer"><button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Vazgeç</button><button type="button" class="btn btn-primary" id="submitCompleteTaskBtn">Kaydet</button></div>
        </form></div></div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.6/dist/js/bootstrap.bundle.min.js"></script>
    <script> /* JS KODU DEĞİŞMEDİ */ document.addEventListener('DOMContentLoaded', () => { const modal = document.getElementById('completeTaskModal'); const submitBtn = document.getElementById('submitCompleteTaskBtn'); modal.addEventListener('show.bs.modal', e => { modal.querySelector('#modal_task_id').value = e.relatedTarget.dataset.taskId; }); submitBtn.addEventListener('click', () => { const formData = new FormData(document.getElementById('completeTaskForm')); submitBtn.disabled = true; submitBtn.innerHTML = '<span class="spinner-border spinner-border-sm"></span> Kaydediliyor...'; fetch('update_task_status.php', { method: 'POST', body: formData }).then(res => res.json()).then(data => { if (data.ok) location.reload(); else alert('Hata: ' + data.error); }).catch(() => alert('Sunucu hatası!')).finally(() => { submitBtn.disabled = false; submitBtn.textContent = 'Kaydet'; }); }); }); function updateTaskStatus(id, newStatus) { if (newStatus === 'iptal' && !confirm('Bu işi iptal etmek istediğinizden emin misiniz?')) return; const formData = new FormData(); formData.append('task_id', id); formData.append('new_status', newStatus); fetch('update_task_status.php', { method: 'POST', body: formData }).then(res => res.json()).then(data => { if (data.ok) location.reload(); else alert('Hata: ' + data.error); }).catch(() => alert('Sunucu hatası!')); } </script>
</body>
</html>