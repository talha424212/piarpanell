<?php
session_start();
if (!isset($_SESSION['kullanici'])) {
  header("Location: giris.php");
  exit;
}
require_once 'baglan.php';
$kullanici = $_SESSION['kullanici'];

// Kullanıcı verilerini güvenli hale getir
$kullanici_isim = $kullanici['isim'] ?? $kullanici['mail'] ?? 'Kullanıcı';
$kullanici_rutbe = $kullanici['rutbe'] ?? 'kullanıcı';

// İstatistikleri çek
$stats = $db->query("SELECT 
  COUNT(*) as toplam_is,
  SUM(CASE WHEN durum = 'bitirildi' THEN 1 ELSE 0 END) as tamamlanan_is,
  SUM(CASE WHEN durum = 'baslandi' THEN 1 ELSE 0 END) as devam_eden_is,
  SUM(CASE WHEN durum = 'verildi' THEN 1 ELSE 0 END) as bekleyen_is
FROM islerim")->fetch(PDO::FETCH_ASSOC);

$kullanici_sayisi = $db->query("SELECT COUNT(*) as sayi FROM kullanicilar")->fetch(PDO::FETCH_ASSOC)['sayi'];
$bugun_mesai = $db->query("SELECT COUNT(*) as sayi FROM mesailer WHERE DATE(baslangic) = CURDATE()")->fetch(PDO::FETCH_ASSOC)['sayi'];

// Son işler
$son_isler = $db->query("SELECT i.*, k.isim as calisan_isim, k.soyisim as calisan_soyisim 
                         FROM islerim i 
                         LEFT JOIN kullanicilar k ON i.calisan_id = k.id 
                         ORDER BY i.atama_tarihi DESC 
                         LIMIT 5")->fetchAll(PDO::FETCH_ASSOC);

// Aktif mesailer
$aktif_mesailer = $db->query("SELECT m.*, k.isim, k.soyisim 
                              FROM mesailer m 
                              LEFT JOIN kullanicilar k ON m.calisan_id = k.id 
                              WHERE m.bitis IS NULL 
                              ORDER BY m.baslangic DESC")->fetchAll(PDO::FETCH_ASSOC);
?>
<!doctype html>
<html lang="tr">
<head>
  <meta charset="UTF-8" />
  <title>Dashboard - Piar Panel</title>
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.6/dist/css/bootstrap.min.css" rel="stylesheet" />
  <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet" />
  <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&display=swap" rel="stylesheet" />
  <style>
  .main-content {
  margin-left: 280px;
  padding: 0; /* Tüm paddingi kaldır */
  min-height: 100vh;
  transition: all 0.4s ease;
}

    * { font-family: 'Inter', sans-serif; }
    body { background: linear-gradient(135deg, #667eea 0%, #764ba2 50%, #f093fb 100%); min-height: 100vh; position: relative; overflow-x: hidden; }
    .main-content { margin-left: 280px; padding: 40px 2rem 2rem; min-height: 100vh; transition: all 0.4s ease; }
    .page-header { background: rgba(255, 255, 255, 0.1); backdrop-filter: blur(20px); border-radius: 20px; padding: 2rem; margin-bottom: 2rem; border: 1px solid rgba(255, 255, 255, 0.2); box-shadow: 0 8px 32px rgba(0, 0, 0, 0.1); }
    .page-title { color: white; font-weight: 800; font-size: 2.5rem; margin: 0; display: flex; align-items: center; gap: 1rem; }
    .page-subtitle { color: rgba(255, 255, 255, 0.9); font-weight: 400; margin-top: 0.5rem; font-size: 1.1rem; }
    .stats-grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(280px, 1fr)); gap: 1.5rem; margin-bottom: 2rem; }
    .stat-card { background: rgba(255, 255, 255, 0.1); backdrop-filter: blur(20px); border-radius: 20px; padding: 2rem; border: 1px solid rgba(255, 255, 255, 0.2); box-shadow: 0 8px 32px rgba(0, 0, 0, 0.1); color: white; cursor: pointer; }
    .stat-card.premium { background: linear-gradient(135deg, rgba(255, 215, 0, 0.2), rgba(255, 165, 0, 0.2)); border: 2px solid rgba(255, 215, 0, 0.5); }
    .stat-icon { font-size: 3rem; margin-bottom: 1rem; opacity: 0.9; }
    .stat-number { font-size: 2.5rem; font-weight: 800; margin-bottom: 0.5rem; background: linear-gradient(45deg, #fff, #f0f0f0); -webkit-background-clip: text; -webkit-text-fill-color: transparent; background-clip: text; }
    .stat-label { font-size: 1rem; opacity: 0.9; font-weight: 600; text-transform: uppercase; letter-spacing: 1px; }
    .stat-change { font-size: 0.9rem; margin-top: 0.5rem; padding: 0.25rem 0.75rem; border-radius: 15px; display: inline-block; }
    .stat-change.positive { background: rgba(40, 167, 69, 0.2); color: #28a745; border: 1px solid rgba(40, 167, 69, 0.3); }
    .stat-change.negative { background: rgba(220, 53, 69, 0.2); color: #dc3545; border: 1px solid rgba(220, 53, 69, 0.3); }
    .content-grid { display: grid; grid-template-columns: 2fr 1fr; gap: 2rem; margin-bottom: 2rem; }
    .content-card { background: rgba(255, 255, 255, 0.1); backdrop-filter: blur(20px); border-radius: 20px; padding: 2rem; border: 1px solid rgba(255, 255, 255, 0.2); box-shadow: 0 8px 32px rgba(0, 0, 0, 0.1); }
    .card-header { display: flex; justify-content: space-between; align-items: center; margin-bottom: 1.5rem; padding-bottom: 1rem; border-bottom: 1px solid rgba(255, 255, 255, 0.1); }
    .card-title { color: white; font-size: 1.5rem; font-weight: 700; margin: 0; display: flex; align-items: center; gap: 0.5rem; }
    .card-action { background: rgba(255, 255, 255, 0.1); border: 1px solid rgba(255, 255, 255, 0.2); color: white; padding: 0.5rem 1rem; border-radius: 10px; text-decoration: none; font-size: 0.9rem; }
    .task-item { display: flex; align-items: center; gap: 1rem; padding: 1rem; background: rgba(255, 255, 255, 0.05); border-radius: 15px; margin-bottom: 1rem; border: 1px solid transparent; }
    .task-icon { width: 40px; height: 40px; background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); border-radius: 10px; display: flex; align-items: center; justify-content: center; color: white; font-size: 1rem; flex-shrink: 0; }
    .task-content { flex: 1; }
    .task-title { color: white; font-weight: 600; font-size: 1rem; margin-bottom: 0.25rem; }
    .task-meta { color: rgba(255, 255, 255, 0.7); font-size: 0.8rem; display: flex; align-items: center; gap: 1rem; }
    .task-status { padding: 0.25rem 0.75rem; border-radius: 15px; font-size: 0.7rem; font-weight: 600; text-transform: uppercase; letter-spacing: 1px; }
    .status-verildi { background: rgba(255, 193, 7, 0.2); color: #ffc107; border: 1px solid rgba(255, 193, 7, 0.3); }
    .status-baslandi { background: rgba(0, 123, 255, 0.2); color: #007bff; border: 1px solid rgba(0, 123, 255, 0.3); }
    .status-bitirildi { background: rgba(40, 167, 69, 0.2); color: #28a745; border: 1px solid rgba(40, 167, 69, 0.3); }
    .mesai-item { display: flex; align-items: center; gap: 1rem; padding: 1rem; background: rgba(255, 255, 255, 0.05); border-radius: 15px; margin-bottom: 1rem; }
    .mesai-avatar { width: 40px; height: 40px; background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); border-radius: 50%; display: flex; align-items: center; justify-content: center; color: white; font-weight: bold; font-size: 0.9rem; flex-shrink: 0; }
    .mesai-content { flex: 1; }
    .mesai-name { color: white; font-weight: 600; font-size: 0.9rem; margin-bottom: 0.25rem; }
    .mesai-time { color: rgba(255, 255, 255, 0.7); font-size: 0.8rem; }
    .mesai-status { width: 12px; height: 12px; background: #28a745; border-radius: 50%; animation: pulse 2s infinite; }
    @keyframes pulse { 0% { opacity: 1; } 50% { opacity: 0.5; } 100% { opacity: 1; } }
    @media (max-width: 768px) { .main-content { margin-left: 0; padding: 40px 1rem 1rem; } .content-grid { grid-template-columns: 1fr; } .stats-grid { grid-template-columns: 1fr; } .page-title { font-size: 2rem; } }
  </style>
</head>
<body>

  
  <?php include 'parcalar/sidebar.php'; ?>
  <?php include 'parcalar/navbar.php'; ?>

  <div class="main-content" id="mainContent">
    <div class="page-header">
      <h1 class="page-title">
        <i class="fas fa-tachometer-alt"></i>
        Dashboard
      </h1>
      <p class="page-subtitle">
        Hoş geldiniz, <?= htmlspecialchars($kullanici_isim) ?>! Bugün nasılsınız?
      </p>
    </div>

    <div class="stats-grid">
      <div class="stat-card" onclick="window.location.href='islerim.php'">
        <div class="stat-icon">
          <i class="fas fa-tasks"></i>
        </div>
        <div class="stat-number"><?= $stats['toplam_is'] ?? 0 ?></div>
        <div class="stat-label">Toplam İş</div>
        <div class="stat-change positive">
          <i class="fas fa-arrow-up"></i> +12% bu hafta
        </div>
      </div>

      <div class="stat-card" onclick="window.location.href='islerim.php'">
        <div class="stat-icon">
          <i class="fas fa-check-circle"></i>
        </div>
        <div class="stat-number"><?= $stats['tamamlanan_is'] ?? 0 ?></div>
        <div class="stat-label">Tamamlanan</div>
        <div class="stat-change positive">
          <i class="fas fa-arrow-up"></i> +8% bu ay
        </div>
      </div>

      <div class="stat-card" onclick="window.location.href='islerim.php'">
        <div class="stat-icon">
          <i class="fas fa-clock"></i>
        </div>
        <div class="stat-number"><?= $stats['devam_eden_is'] ?? 0 ?></div>
        <div class="stat-label">Devam Eden</div>
        <div class="stat-change negative">
          <i class="fas fa-arrow-down"></i> -3% bu hafta
        </div>
      </div>

      <div class="stat-card premium" onclick="window.location.href='mesai.php'">
        <div class="stat-icon">
          <i class="fas fa-users"></i>
        </div>
        <div class="stat-number"><?= $kullanici_sayisi ?></div>
        <div class="stat-label">Aktif Personel</div>
        <div class="stat-change positive">
          <i class="fas fa-arrow-up"></i> +5% bu ay
        </div>
      </div>
    </div>

    <div class="content-grid">
      <div class="content-card">
        <div class="card-header">
          <h3 class="card-title">
            <i class="fas fa-list"></i>
            Son İşler
          </h3>
          <a href="islerim.php" class="card-action">
            Tümünü Gör <i class="fas fa-arrow-right"></i>
          </a>
        </div>
        
        <?php if (empty($son_isler)): ?>
          <div class="empty-state">
            <i class="fas fa-inbox"></i>
            <p>Henüz iş atanmamış</p>
          </div>
        <?php else: ?>
          <?php foreach ($son_isler as $is): ?>
            <div class="task-item">
              <div class="task-icon">
                <i class="fas fa-briefcase"></i>
              </div>
              <div class="task-content">
                <div class="task-title"><?= htmlspecialchars($is['baslik']) ?></div>
                <div class="task-meta">
                  <span><i class="fas fa-user"></i> <?= htmlspecialchars($is['calisan_isim'] ?? 'Atanmamış') ?></span>
                  <span><i class="fas fa-calendar"></i> <?= date('d.m.Y', strtotime($is['atama_tarihi'])) ?></span>
                </div>
              </div>
              <span class="task-status status-<?= $is['durum'] ?>"><?= ucfirst($is['durum']) ?></span>
            </div>
          <?php endforeach; ?>
        <?php endif; ?>
      </div>

      <div class="content-card">
        <div class="card-header">
          <h3 class="card-title">
            <i class="fas fa-clock"></i>
            Aktif Mesailer
          </h3>
          <a href="mesai.php" class="card-action">
            Tümünü Gör <i class="fas fa-arrow-right"></i>
          </a>
        </div>
        
        <?php if (empty($aktif_mesailer)): ?>
          <div class="empty-state">
            <i class="fas fa-clock"></i>
            <p>Aktif mesai yok</p>
          </div>
        <?php else: ?>
          <?php foreach ($aktif_mesailer as $mesai): ?>
            <div class="mesai-item">
              <div class="mesai-avatar">
                <?= strtoupper(substr($mesai['isim'] ?? 'U', 0, 1)) ?>
              </div>
              <div class="mesai-content">
                <div class="mesai-name"><?= htmlspecialchars($mesai['isim'] ?? 'Bilinmeyen') ?> <?= htmlspecialchars($mesai['soyisim'] ?? '') ?></div>
                <div class="mesai-time">
                  <i class="fas fa-play"></i> 
                  <?= date('H:i', strtotime($mesai['baslangic'])) ?> - Devam ediyor
                </div>
              </div>
              <div class="mesai-status"></div>
            </div>
          <?php endforeach; ?>
        <?php endif; ?>
      </div>
    </div>
  </div>

  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.6/dist/js/bootstrap.bundle.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/gsap/3.12.2/gsap.min.js"></script>
  
  <script>
    // Floating particles
    function createParticles() {
      const particlesContainer = document.getElementById('particles');
      const particleCount = 50;
      
      for (let i = 0; i < particleCount; i++) {
        const particle = document.createElement('div');
        particle.className = 'particle';
        particle.style.width = Math.random() * 10 + 5 + 'px';
        particle.style.height = particle.style.width;
        particle.style.left = Math.random() * 100 + '%';
        particle.style.top = Math.random() * 100 + '%';
        particle.style.animationDelay = Math.random() * 6 + 's';
        particle.style.animationDuration = (Math.random() * 3 + 3) + 's';
        particlesContainer.appendChild(particle);
      }
    }

    // GSAP Animations
    function initAnimations() {
      gsap.from('.page-header', {
        duration: 1,
        y: -50,
        opacity: 0,
        ease: 'power3.out'
      });

      gsap.from('.stat-card', {
        duration: 0.8,
        y: 50,
        opacity: 0,
        ease: 'power3.out',
        
      });

      gsap.from('.content-card', {
        duration: 1,
        y: 50,
        opacity: 0,
        ease: 'power3.out',
      });

      gsap.from('.task-item, .mesai-item', {
        duration: 0.6,
        x: -50,
        opacity: 0,
        ease: 'power3.out',
      });
    }

    // Sidebar toggle functionality
    function toggleSidebar() {
      const mainContent = document.getElementById('mainContent');
      const sidebar = document.querySelector('.sidebar');
      
      if (sidebar.classList.contains('collapsed')) {
        sidebar.classList.remove('collapsed');
        mainContent.classList.remove('sidebar-collapsed');
        localStorage.setItem('sidebarCollapsed', 'false');
      } else {
        sidebar.classList.add('collapsed');
        mainContent.classList.add('sidebar-collapsed');
        localStorage.setItem('sidebarCollapsed', 'true');
      }
    }

    // Initialize
    document.addEventListener('DOMContentLoaded', function() {
      createParticles();
      initAnimations();
      
      // Check sidebar state
      const sidebarCollapsed = localStorage.getItem('sidebarCollapsed') === 'true';
      if (sidebarCollapsed) {
        document.querySelector('.sidebar').classList.add('collapsed');
        document.getElementById('mainContent').classList.add('sidebar-collapsed');
      }
      
      // Live stats updates
      setInterval(() => {
        // Simulate live updates
        const statNumbers = document.querySelectorAll('.stat-number');
        statNumbers.forEach(stat => {
          const currentValue = parseInt(stat.textContent);
          const newValue = currentValue + Math.floor(Math.random() * 3) - 1;
          if (newValue >= 0) {
            gsap.to(stat, {
              textContent: newValue,
              duration: 0.5,
              ease: 'power2.out'
            });
          }
        });
      }, 30000); // Update every 30 seconds
    });

    // Add click effects
    document.querySelectorAll('.stat-card').forEach(card => {
      card.addEventListener('click', function() {
        gsap.to(this, {
          scale: 0.95,
          duration: 0.1,
          ease: 'power2.out',
          onComplete: () => {
            gsap.to(this, {
              scale: 1,
              duration: 0.1,
              ease: 'power2.out'
            });
          }
        });
      });
    });
  </script>
</body>
</html> 