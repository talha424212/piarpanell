<?php
ini_set('display_errors', 1);
error_reporting(E_ALL);
session_start();
require_once 'baglan.php';

// PHPMailer'ı dahil et
require_once __DIR__ . '/PHPMailer/src/Exception.php';
require_once __DIR__ . '/PHPMailer/src/PHPMailer.php';
require_once __DIR__ . '/PHPMailer/src/SMTP.php';
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

header('Content-Type: application/json');
if (!isset($_SESSION['kullanici']) || $_SESSION['kullanici']['rutbe'] !== 'patron') {
    echo json_encode(['ok' => false, 'error' => 'Yetkisiz erişim.']); exit;
}

$db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
$response = ['ok' => false];
$patron_id = $_SESSION['kullanici']['id'];

try {
    $action = $_POST['action'] ?? null;
    $id = $_POST['id'] ?? null;

    if ($action === 'sil' && $id) {
        $db->beginTransaction();
        $db->prepare("DELETE FROM etkinlikler WHERE id = ?")->execute([$id]);
        $db->prepare("DELETE FROM etkinlik_atananlar WHERE etkinlik_id = ?")->execute([$id]);
        $db->commit();
        $response['ok'] = true;
    } 
    elseif ($_SERVER['REQUEST_METHOD'] === 'POST') {
        $is_drop_update = isset($_POST['is_drop_update']);
        $baslangic = $_POST['baslangic'] ?? null;
        $db->beginTransaction();

        if ($is_drop_update && $id) {
            // Sürükle-bırakta sadece başlangıç tarihini güncelle, bitiş hep NULL olsun
            $db->prepare("UPDATE etkinlikler SET baslangic=?, bitis=NULL WHERE id=?")->execute([$baslangic, $id]);
        } else {
            $baslik = trim($_POST['baslik'] ?? '');
            $kullanici_idler = $_POST['kullanici_id'] ?? [];
            $aciklama = trim($_POST['aciklama'] ?? '');
            $oncelik = $_POST['oncelik'] ?? 'Orta';
            $bitis_tarihi_db = !empty($_POST['bitis']) ? $_POST['bitis'] : null; // Bu sadece DB'de tutulacak

            if (empty($baslik) || empty($baslangic) || empty($kullanici_idler)) {
                 throw new Exception("Başlık, başlangıç zamanı ve kullanıcı seçimi zorunludur.");
            }

            if ($id) { // Güncelleme
                // bitis=NULL takvimde tek gün görünmesini sağlar
                $sql = "UPDATE etkinlikler SET baslik=?, aciklama=?, baslangic=?, bitis=NULL, bildirim_goruldu=0 WHERE id=?";
                $db->prepare($sql)->execute([$baslik, $aciklama, $baslangic, null, $id]);
                $db->prepare("DELETE FROM etkinlik_atananlar WHERE etkinlik_id = ?")->execute([$id]);
            } else { // Ekleme
                $sql = "INSERT INTO etkinlikler (baslik, aciklama, baslangic, bitis, bildirim_goruldu) VALUES (?, ?, ?, NULL, 0)";
                $db->prepare($sql)->execute([$baslik, $aciklama, $baslangic]);
                $id = $db->lastInsertId();
            }
            
            $atanan_stmt = $db->prepare("INSERT INTO etkinlik_atananlar (etkinlik_id, kullanici_id) VALUES (?, ?)");
            $is_ekle_stmt = $db->prepare("INSERT INTO islerim (calisan_id, patron_id, baslik, aciklama, durum, atama_tarihi, baslama_tarihi, bitis_tarihi, oncelik, bildirim_goruldu) VALUES (?, ?, ?, ?, 'verildi', NOW(), ?, ?, ?, 0)");
            
            $baslama_tarihi_date = date('Y-m-d', strtotime($baslangic));
            $bitis_tarihi_date = $bitis_tarihi_db ? date('Y-m-d', strtotime($bitis_tarihi_db)) : null;

            foreach ($kullanici_idler as $k_id) {
                $atanan_stmt->execute([$id, $k_id]);
                if (empty($_POST['id'])) { // SADECE YENİ ETKİNLİK İSE İŞ OLUŞTUR
                    $is_ekle_stmt->execute([$k_id, $patron_id, $baslik, $aciklama, $baslama_tarihi_date, $bitis_tarihi_date, $oncelik]);
                }
            }
        }
        $db->commit();
        $response['ok'] = true;
    }
} catch (Exception $e) {
    if ($db->inTransaction()) { $db->rollBack(); }
    $response['error'] = $e->getMessage();
}
echo json_encode($response);