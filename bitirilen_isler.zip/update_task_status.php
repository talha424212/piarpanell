<?php
session_start();
header('Content-Type: application/json');
ini_set('display_errors', 0); ini_set('log_errors', 1); error_reporting(E_ALL);
require_once 'baglan.php'; 

$response = ['ok' => false, 'error' => 'Bilinmeyen bir hata oluştu.'];

try {
    if (!isset($_SESSION['kullanici']['id'])) throw new Exception('Oturum bulunamadı.');
    $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    $taskId = $_POST['task_id'] ?? null;
    $newStatus = $_POST['new_status'] ?? null;
    if (!$taskId || !$newStatus) throw new Exception('Eksik parametreler.');
    
    $kullanici_id = $_SESSION['kullanici']['id'];

    if ($newStatus === 'bitirildi') {
        $tamamlamaNotu = $_POST['tamamlama_notu'] ?? '';
        // İşin durumunu ve notunu ana tabloda güncelle
        $stmt_is = $db->prepare("UPDATE islerim SET durum = ?, tamamlama_notu = ? WHERE id = ? AND calisan_id = ?");
        $stmt_is->execute([$newStatus, $tamamlamaNotu, $taskId, $kullanici_id]);

        // EĞER YENİ BİR DOSYA YÜKLENDİYSE, 'bitmis_isler' TABLOSUNA YENİ BİR KAYIT GİR
        if (isset($_FILES['teslim_dosyasi']) && $_FILES['teslim_dosyasi']['error'] === UPLOAD_ERR_OK) {
            $uploadDir = 'bitirilen_isler/';
            if (!is_dir($uploadDir)) mkdir($uploadDir, 0755, true);
            if (!is_writable($uploadDir)) throw new Exception("'$uploadDir' klasörü yazılabilir değil.");
            
            $originalName = basename($_FILES['teslim_dosyasi']['name']);
            $fileExtension = pathinfo($originalName, PATHINFO_EXTENSION);
            $uniqueFilename = "is_{$taskId}_" . time() . "." . $fileExtension;
            $targetPath = $uploadDir . $uniqueFilename;

            if (move_uploaded_file($_FILES['teslim_dosyasi']['tmp_name'], $targetPath)) {
                // Her yeni dosya yüklemesinde 'bitmis_isler' tablosuna YENİ bir satır ekle
                $stmt_file = $db->prepare("INSERT INTO bitmis_isler (is_id, dosya_adi, dosya_yolu, yukleme_tarihi) VALUES (?, ?, ?, NOW())");
                $stmt_file->execute([$taskId, $originalName, $targetPath]);
            } else {
                throw new Exception('Yeni dosya sunucuya taşınamadı.');
            }
        }
    } else { // Diğer durum güncellemeleri
        $stmt_is = $db->prepare("UPDATE islerim SET durum = ? WHERE id = ? AND calisan_id = ?");
        $stmt_is->execute([$newStatus, $taskId, $kullanici_id]);
    }
    $response['ok'] = true;
    unset($response['error']);
} catch (Exception $e) {
    $response['error'] = 'Sunucu Hatası: ' . $e->getMessage();
}

echo json_encode($response, JSON_UNESCAPED_UNICODE);