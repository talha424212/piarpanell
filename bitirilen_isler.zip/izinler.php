<?php
session_start();
require_once 'baglan.php'; // Veritabanı bağlantısı

// =============================================================================
// 1. PHP Mantık Bölümü
// =============================================================================

// Kullanıcı girişi ve yetki kontrolü
if (!isset($_SESSION['kullanici'])) {
    header('Location: giris.php');
    exit;
}

$kullanici = $_SESSION['kullanici'];
$kullanici_id = $kullanici['id'] ?? null;
// Bu sayfanın sadece patron tarafından yönetileceği varsayılarak kural eklendi.
// Eğer normal çalışan da kendi izinlerini yönetecekse bu 'if' bloğu değiştirilmeli.
if ($_SESSION['kullanici']['rutbe'] !== 'patron') {
    die("Bu sayfaya erişim yetkiniz yok."); 
}

// Hata ve mesaj değişkenleri
$mesaj = "";
$mesaj_tip = "";
$db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

// İŞLEM: Yeni İzin Talebi Ekleme (Modal formundan gelecek)
if (isset($_POST['izin_ekle'])) {
    // Bu kısım şu anki yapıda sadece kullanıcı tarafından eklenebiliyor,
    // Yönetici paneli için buraya bir mantık eklenebilir. Şimdilik pasif bırakıyorum
    // çünkü sayfa şu an bir yönetici paneli gibi kurgulanmış.
}

// İŞLEM: Yönetici Onay/Red İşlemi
if (isset($_GET['action'], $_GET['izin_id'])) {
    $action = $_GET['action'];
    $izin_id = (int)$_GET['izin_id'];
    $yeni_durum = '';

    if ($action === 'onayla') $yeni_durum = 'onaylandi';
    if ($action === 'reddet') $yeni_durum = 'reddedildi';
    
    if (!empty($yeni_durum)) {
        $stmt = $db->prepare("UPDATE izinler SET onay = ? WHERE id = ?");
        $stmt->execute([$yeni_durum, $izin_id]);
        header("Location: izinler.php"); // Sayfayı yenileyerek URL'i temizle
        exit;
    }
}

// İŞLEM: İzin Silme
if (isset($_GET['sil_id'])) {
    $sil_id = (int)$_GET['sil_id'];
    // Silme işlemini sadece yönetici yapabilir
    $stmt = $db->prepare("DELETE FROM izinler WHERE id = ?");
    $stmt->execute([$sil_id]);
    header("Location: izinler.php"); // Sayfayı yenile
    exit;
}


// =============================================================================
// 2. Sayfa Verilerini Çekme
// =============================================================================

// Tüm çalışanların izinlerini çek (yönetici olduğu için)
$sql = "SELECT izinler.*, kullanicilar.isim, kullanicilar.soyisim 
    FROM izinler 
    JOIN kullanicilar ON izinler.calisan_id = kullanicilar.id 
    ORDER BY izinler.baslangic DESC";
$stmt = $db->prepare($sql);
$stmt->execute();
$izinler = $stmt->fetchAll(PDO::FETCH_ASSOC);

// İstatistikleri tüm izinlere göre hesapla
$bekleyen_izin = 0;
$onaylanan_izin = 0;
$reddedilen_izin = 0;

foreach($izinler as $izin) {
    if ($izin['onay'] == 'beklemede') $bekleyen_izin++;
    if ($izin['onay'] == 'onaylandi') $onaylanan_izin++;
    if ($izin['onay'] == 'reddedildi') $reddedilen_izin++;
}
$toplam_izin = count($izinler);

// Modal içinde kullanılacak çalışan listesi
$calisanlar = $db->query("SELECT id, isim, soyisim FROM kullanicilar ORDER BY isim")->fetchAll(PDO::FETCH_ASSOC);

?>
<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>İzin Yönetimi - Yönetici Paneli</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.6/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
    <style>
        :root {
            --primary-gradient: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            --glass-bg: rgba(255, 255, 255, 0.1);
            --glass-border: rgba(255, 255, 255, 0.2);
            --sidebar-width: 280px; 
            --sidebar-width-collapsed: 80px;
            --navbar-height: 80px;
        }
        body { background: var(--primary-gradient); font-family: 'Segoe UI', sans-serif; overflow-x: hidden; color:white;}
        
        /* Yerleşim Düzenlemeleri */
        .main-content {
            padding: 2rem;
            padding-top: calc(var(--navbar-height) + 2rem);
            margin-left: var(--sidebar-width);
            transition: margin-left 0.4s;
            min-height: 100vh;
        }
        body.sidebar-collapsed .main-content { margin-left: var(--sidebar-width-collapsed); }
        @media (max-width: 992px) {
            .main-content { margin-left: 0 !important; }
        }
        
        /* Diğer Tüm Stiller (Kısaltılmıştır) */
        .page-header, .content-container, .stat-card { background: var(--glass-bg); backdrop-filter: blur(20px); border: 1px solid var(--glass-border); border-radius: 20px; padding: 30px; margin-bottom: 30px; box-shadow: 0 8px 32px rgba(0,0,0,0.1); }
        .page-title { font-size: 2.5rem; font-weight: 700; }
        .stats-container { display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 20px; margin-bottom: 30px; }
        .stat-card { text-align: center; }
        .stat-number { font-size: 2rem; font-weight: 700; }
        .section-title { font-size: 1.5rem; font-weight: 600; }
        .table-modern { width: 100%; border-collapse: separate; border-spacing: 0; }
        .table-modern thead th { background-color: rgba(255,255,255,0.1); padding: 1rem; text-align: left; border-bottom: 1px solid var(--glass-border); }
        .table-modern tbody td { padding: 1rem; vertical-align: middle; border-bottom: 1px solid rgba(255, 255, 255, 0.1); }
        .table-modern tbody tr:hover td { background-color: rgba(255,255,255,0.05); }
        .table-modern tbody tr:last-child td { border-bottom: none; }
        .status-badge { padding: .4em .8em; border-radius: 20px; font-size: 0.8em; font-weight: 700; text-transform: uppercase; }
        .status-onaylandi { background-color: #198754; color: white; } .status-reddedildi { background-color: #dc3545; color: white; } .status-beklemede { background-color: #ffc107; color: #212529; }
        .modal-content { background: var(--glass-bg); backdrop-filter: blur(20px); border: 1px solid var(--glass-border); border-radius: 20px; }
        .modal-header, .modal-footer { border-color: var(--glass-border); }
        .form-control, .form-select { background: var(--glass-bg); border: 1px solid var(--glass-border); color: white; border-radius: 15px; }
        .form-control:focus, .form-select:focus { background: rgba(255,255,255,0.15); color: white; box-shadow: none; }
        .btn-close { filter: invert(1); }
        .form-select option { background-color:#2d3436; }
    </style>
</head>
<body>
    <?php include 'parcalar/sidebar.php'; ?>
    <?php include 'parcalar/navbar.php'; ?>
    
    <div class="main-content">
        <div class="page-header">
            <h1 class="page-title"><i class="fas fa-calendar-alt me-3"></i>İzin Yönetimi (Yönetici)</h1>
        </div>
        
        <?php if (!empty($mesaj)): ?>
        <div class="alert alert-success alert-dismissible fade show" role="alert">
            <?= htmlspecialchars($mesaj) ?>
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
        <?php endif; ?>

        <div class="stats-container">
            <div class="stat-card"> <div class="stat-number"><?= $bekleyen_izin ?></div> <div class="stat-label">Beklemede</div> </div>
            <div class="stat-card"> <div class="stat-number"><?= $onaylanan_izin ?></div> <div class="stat-label">Onaylanan</div> </div>
            <div class="stat-card"> <div class="stat-number"><?= $reddedilen_izin ?></div> <div class="stat-label">Reddedilen</div> </div>
            <div class="stat-card"> <div class="stat-number"><?= $toplam_izin ?></div> <div class="stat-label">Toplam Talep</div> </div>
        </div>

        <div class="content-container">
            <h2 class="section-title"><i class="fas fa-list"></i> Gelen İzin Talepleri</h2>
            <div class="table-responsive">
                <table class="table-modern">
                    <thead><tr><th>Çalışan</th><th>Başlangıç</th><th>Bitiş</th><th>Sebep</th><th>Durum</th><th>İşlem</th></tr></thead>
                    <tbody>
                    <?php if (empty($izinler)): ?>
                        <tr><td colspan="6" class="text-center py-4">Gösterilecek izin talebi bulunmuyor.</td></tr>
                    <?php else: ?>
                        <?php foreach ($izinler as $izin): ?>
                        <tr>
                            <td><?= htmlspecialchars($izin['isim'] . ' ' . $izin['soyisim']) ?></td>
                            <td><?= date('d.m.Y H:i', strtotime($izin['baslangic'])) ?></td>
                            <td><?= date('d.m.Y H:i', strtotime($izin['bitis'])) ?></td>
                            <td><?= htmlspecialchars($izin['sebep']) ?></td>
                            <td><span class="status-badge status-<?= $izin['onay'] ?>"><?= ucfirst($izin['onay']) ?></span></td>
                            <td>
                                <?php if ($izin['onay'] == 'beklemede'): ?>
                                <a href="?action=onayla&izin_id=<?= $izin['id'] ?>" class="btn btn-success btn-sm"><i class="fas fa-check"></i></a>
                                <a href="?action=reddet&izin_id=<?= $izin['id'] ?>" class="btn btn-warning btn-sm"><i class="fas fa-times"></i></a>
                                <?php endif; ?>
                                <a href="?sil_id=<?= $izin['id'] ?>" class="btn btn-danger btn-sm" onclick="return confirm('Bu izin talebini kalıcı olarak silmek istediğinizden emin misiniz?')"><i class="fas fa-trash"></i></a>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
    
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.6/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>