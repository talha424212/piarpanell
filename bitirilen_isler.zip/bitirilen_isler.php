<?php
session_start();
require_once 'baglan.php'; // Veritabanı bağlantısı

// =============================================================================
// PHP KODU - HİÇBİR DEĞİŞİKLİK YAPILMADI
// =============================================================================

if (!isset($_SESSION['kullanici']) || $_SESSION['kullanici']['rutbe'] !== 'patron') {
    die("Bu sayfaya erişim yetkiniz yok.");
}
$db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
$sql = "SELECT islerim.id as is_id, islerim.baslik, islerim.bitis_tarihi, kullanicilar.isim, kullanicilar.soyisim FROM islerim JOIN kullanicilar ON islerim.calisan_id = kullanicilar.id WHERE islerim.durum = 'bitirildi' ORDER BY islerim.bitis_tarihi DESC";
$stmt = $db->query($sql);
$biten_isler = $stmt->fetchAll(PDO::FETCH_ASSOC);
$dosyalar_sql = "SELECT is_id, dosya_adi, dosya_yolu, yukleme_tarihi FROM bitmis_isler";
$dosyalar_stmt = $db->query($dosyalar_sql);
$tum_dosyalar = $dosyalar_stmt->fetchAll(PDO::FETCH_ASSOC);
$dosyalar_gruplu = [];
foreach ($tum_dosyalar as $dosya) {
    $dosyalar_gruplu[$dosya['is_id']][] = $dosya;
}
?>
<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Yapılan İşler - Piar Panel</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.6/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
    <style>
        :root {
            --primary-gradient: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            --glass-bg: rgba(255, 255, 255, 0.1);
            --glass-border: rgba(255, 255, 255, 0.2);
            --text-light: #f8f9fa;
            --sidebar-width: 280px; /* Kenar çubuğu genişliği */
            --sidebar-width-collapsed: 80px; /* Daraltılmış kenar çubuğu genişliği */
            --navbar-height: 80px; /* Navbar yüksekliği */
        }
        body { background: var(--primary-gradient); font-family: 'Segoe UI', sans-serif; overflow-x: hidden;}
        
        /* ===== YENİ EKLENEN YERLEŞİM DÜZENLEMELERİ ===== */
        .main-content {
            padding: 2rem;
            padding-top: calc(var(--navbar-height) + 2rem); /* Üstte navbar kadar boşluk bırak */
            margin-left: var(--sidebar-width); /* Solda sidebar kadar boşluk bırak */
            transition: margin-left 0.4s cubic-bezier(0.175, 0.885, 0.32, 1.275);
            min-height: 100vh;
        }
        /* Sidebar daraltıldığında ana içeriğin sola kaymasını sağlar */
        body.sidebar-collapsed .main-content {
            margin-left: var(--sidebar-width-collapsed);
        }
        /* Mobil ve tabletler için sol boşluğu sıfırla */
        @media (max-width: 992px) {
            .main-content {
                margin-left: 0 !important;
            }
        }
        /* ================================================= */

        .page-header, .content-card {
            background: var(--glass-bg); backdrop-filter: blur(20px); border: 1px solid var(--glass-border);
            border-radius: 20px; padding: 30px; margin-bottom: 30px; box-shadow: 0 8px 32px rgba(0, 0, 0, 0.1); color: var(--text-light);
        }
        .page-title { font-size: 2.5rem; font-weight: 700; }
        .section-title { font-weight: 600; margin-bottom: 20px; }
        
        /* Kart Yapısı (Değişiklik Yok) */
        .job-card { background-color: rgba(255,255,255,0.08); border-left: 5px solid #4facfe; padding: 20px; border-radius: 15px; margin-bottom: 20px; transition: all 0.3s ease; }
        .job-card:hover { transform: translateY(-5px); box-shadow: 0 15px 40px rgba(0,0,0,0.2); background-color: rgba(255,255,255,0.12); }
        .job-title { font-size: 1.4rem; font-weight: 600; margin-bottom: 10px; }
        .job-meta { font-size: 0.9rem; opacity: 0.8; margin-bottom: 15px; }
        .file-list .file-item { display: flex; align-items: center; background-color: rgba(0,0,0,0.1); padding: 10px 15px; border-radius: 10px; margin-bottom: 8px; }
        .file-list .file-item-icon { font-size: 1.5rem; margin-right: 15px; color: #4facfe; }
        .file-list .download-btn { color: #4facfe; text-decoration: none; font-weight: 600; font-size: 1.2rem; transition: transform 0.2s; }
        .filter-input { background: var(--glass-bg); border: 1px solid var(--glass-border); color: white; border-radius: 15px; padding: 12px 15px; }
        .filter-input::placeholder { color: rgba(255,255,255,0.6); }
    </style>
</head>
<body>
    <!-- SİDEBAR VE NAVBAR DAHİL EDİLDİĞİNDE YAPI BÖYLE OLMALI -->
    <?php include 'parcalar/sidebar.php'; ?>
    <?php include 'parcalar/navbar.php'; ?>
    
    <div class="main-content">
        <!-- Sayfa içeriği bu div'in içinde kalacak -->
        <div class="page-header">
            <h1 class="page-title"><i class="fas fa-check-double me-3"></i> Yapılan İşler</h1>
            <p>Tamamlanmış tüm görevlerin ve teslim edilen dosyaların listesi.</p>
        </div>

        <div class="content-card">
            <div class="row mb-4">
                <div class="col-md-6"><h4 class="section-title">İş Listesi</h4></div>
                <div class="col-md-6">
                     <input type="text" id="jobFilterInput" class="form-control filter-input" placeholder="Çalışan adı veya iş başlığına göre filtrele...">
                </div>
            </div>
           
            <div id="jobListContainer">
                <?php if (empty($biten_isler)): ?>
                    <div class="text-center p-5"><h4>Henüz tamamlanmış bir iş bulunmuyor.</h4></div>
                <?php else: ?>
                    <?php foreach ($biten_isler as $is): ?>
                        <div class="job-card" data-filter-text="<?= strtolower(htmlspecialchars($is['isim'] . ' ' . $is['soyisim'] . ' ' . $is['baslik'])) ?>">
                            <h3 class="job-title"><?= htmlspecialchars($is['baslik']) ?></h3>
                            <div class="job-meta">
                                <span class="me-3"><i class="fas fa-user me-2"></i><strong>Çalışan:</strong> <?= htmlspecialchars($is['isim'] . ' ' . $is['soyisim']) ?></span>
                                <span><i class="fas fa-calendar-check me-2"></i><strong>Tarih:</strong> <?= date('d.m.Y', strtotime($is['bitis_tarihi'])) ?></span>
                            </div>
                            <div class="job-description"><p><?= nl2br(htmlspecialchars($is['aciklama'])) ?></p></div>
                            <?php if (!empty($is['tamamlama_notu'])): ?>
                                <div class="job-notes mb-3">
                                    <strong>Çalışanın Notu:</strong>
                                    <blockquote class="mt-1" style="background-color: rgba(0,0,0,0.1); padding:10px; border-radius:5px; font-style:italic;">
                                        <?= htmlspecialchars($is['tamamlama_notu']) ?>
                                    </blockquote>
                                </div>
                            <?php endif; ?>
                            <?php if (isset($dosyalar_gruplu[$is['is_id']])): ?>
                                <h5 class="section-title mt-4" style="font-size: 1rem;"><i class="fas fa-paperclip"></i> Yüklenen Dosyalar</h5>
                                <div class="file-list">
                                    <?php foreach ($dosyalar_gruplu[$is['is_id']] as $dosya): ?>
                                        <div class="file-item">
                                            <i class="fas fa-file-alt file-item-icon"></i>
                                            <div class="flex-grow-1">
                                                <div class="fw-bold"><?= htmlspecialchars($dosya['dosya_adi']) ?></div>
                                                <div class="small opacity-75"><?= date('d.m.Y H:i', strtotime($dosya['yukleme_tarihi'])) ?></div>
                                            </div>
                                            <a href="<?= htmlspecialchars($dosya['dosya_yolu']) ?>" target="_blank" class="download-btn" title="İndir"><i class="fas fa-download"></i></a>
                                        </div>
                                    <?php endforeach; ?>
                                </div>
                            <?php endif; ?>
                        </div>
                    <?php endforeach; ?>
                <?php endif; ?>
            </div>
        </div>
    </div>
    
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.6/dist/js/bootstrap.bundle.min.js"></script>
    <script>
    document.addEventListener('DOMContentLoaded', () => {
        // Filtreleme (Arama) fonksiyonu
        const filterInput = document.getElementById('jobFilterInput');
        if(filterInput) {
            filterInput.addEventListener('input', function() {
                const filterText = this.value.toLowerCase().trim();
                document.querySelectorAll('.job-card').forEach(card => {
                    const cardText = card.getAttribute('data-filter-text');
                    card.style.display = cardText.includes(filterText) ? '' : 'none';
                });
            });
        }
        
        // Bu fonksiyon, kenar çubuğunuzu açıp kapatan butona eklenmelidir.
        // Eğer sidebar'ınızda toggle fonksiyonu varsa, bu kodu oraya entegre edin.
        function handleSidebarToggle() {
             document.body.classList.toggle('sidebar-collapsed');
        }
    });
    </script>
</body>
</html>