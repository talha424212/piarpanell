<?php
require_once 'baglan.php';

if (!isset($_GET['id'])) {
    http_response_code(400);
    echo json_encode(['error' => 'Eksik parametre']);
    exit;
}

$id = (int)$_GET['id'];

$sql = "SELECT e.*, GROUP_CONCAT(ek.kullanici_id) AS kullanici_ids
        FROM etkinlikler e
        LEFT JOIN etkinlik_kullanici ek ON e.id = ek.etkinlik_id
        WHERE e.id = ? GROUP BY e.id";
$stmt = $db->prepare($sql);
$stmt->execute([$id]);
$etkinlik = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$etkinlik) {
    http_response_code(404);
    echo json_encode(['error' => 'Etkinlik bulunamadı']);
    exit;
}

echo json_encode([
    'id' => $etkinlik['id'],
    'baslik' => $etkinlik['baslik'],
    'aciklama' => $etkinlik['aciklama'],
    'tarih' => $etkinlik['tarih'],
    'saat_baslangic' => $etkinlik['saat_baslangic'],
    'saat_bitis' => $etkinlik['saat_bitis'],
    'kullanicilar' => $etkinlik['kullanici_ids'] ? array_map('intval', explode(',', $etkinlik['kullanici_ids'])) : []
]);
