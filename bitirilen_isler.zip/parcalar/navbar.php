<?php
if (session_status() === PHP_SESSION_NONE) session_start();
if (!isset($_SESSION['kullanici'])) {
    header("Location: giris.php");
    exit;
}
$kullanici = $_SESSION['kullanici'];
$kullanici_isim = $kullanici['isim'] ?? 'Kullanıcı';
$kullanici_rutbe = $kullanici['rutbe'] ?? 'kullanıcı';
?>

<!-- Sizin verdiğiniz CSS, hiç değiştirilmedi -->
<style>
.navbar{
    margin: 0;
    padding: 0;
    
    
}

.navbar { position: fixed; top: 0; left: 280px; right: 0; height: 80px; background: rgba(255,255,255,0.1); backdrop-filter: blur(20px); border-bottom: 1px solid rgba(255,255,255,0.2); z-index: 999; padding: 0 2rem; display: flex; align-items: center; justify-content: space-between; gap: 1rem; font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; transition: all 0.4s; }
.navbar.sidebar-collapsed { left: 80px; }
.welcome-message { color: white; font-weight: 600; font-size: 1.1rem; flex-grow: 1; user-select: none; text-shadow: 0 2px 4px rgba(0,0,0,0.3); }
.search-container { position: relative; flex-shrink: 0; max-width: 350px; width: 100%; }
.search-input { width: 100%; padding: 0.75rem 1rem 0.75rem 3rem; border-radius: 25px; border: 1px solid rgba(255,255,255,0.3); background: rgba(255,255,255,0.1); color: white; font-size: 1rem; outline: none; transition: background 0.3s ease, border-color 0.3s ease; backdrop-filter: blur(10px); }
.search-input::placeholder { color: rgba(255,255,255,0.6); }
.search-input:focus { background: rgba(255,255,255,0.15); border-color: rgba(255,255,255,0.5); box-shadow: 0 0 6px rgba(255,255,255,0.3); }
.search-icon { position: absolute; left: 1rem; top: 50%; transform: translateY(-50%); color: rgba(255,255,255,0.6); font-size: 1.1rem; pointer-events: none; }
.navbar-right { display: flex; align-items: center; gap: 1rem; }
.navbar-item { position: relative; width: 45px; height: 45px; border-radius: 12px; background: rgba(255,255,255,0.1); border: 1px solid rgba(255,255,255,0.2); color: white; cursor: pointer; display: flex; justify-content: center; align-items: center; transition: background 0.3s ease, transform 0.3s ease; user-select: none; }
.navbar-item:hover { background: rgba(255,255,255,0.2); transform: translateY(-2px) scale(1.05); box-shadow: 0 8px 20px rgba(0,0,0,0.2); }
.navbar-item i { font-size: 1.2rem; }
.notification-badge { position: absolute; top: -6px; right: -6px; background: #dc3545; color: white; border-radius: 50%; padding: 2px 7px; font-size: 0.7rem; font-weight: 700; animation: pulse 2s infinite; box-shadow: 0 0 8px #dc3545aa; }
@keyframes pulse { 0%, 100% { transform: scale(1); } 50% { transform: scale(1.2); } }
.notification-dropdown { position: absolute; top: 120%; right: 0; background: rgba(0,0,0,0.85); color: white; border-radius: 12px; padding: 10px; min-width: 320px; max-height: 320px; overflow-y: auto; opacity: 0; visibility: hidden; transform: translateY(-10px); transition: all 0.3s; box-shadow: 0 8px 30px rgba(0,0,0,0.6); z-index: 1500; user-select: none; }
.notification-dropdown.show { opacity: 1; visibility: visible; transform: translateY(0); }
.notification-item { padding: 8px 10px; border-bottom: 1px solid #444; font-size: 0.9rem; user-select: text; text-decoration:none; display: block; color:white;}
.notification-item:hover { background: rgba(255,255,255,0.1); color:white;}
.notification-item:last-child { border-bottom: none; }
.notification-item.unread { background: #3344aa33; font-weight: 600; }
.notification-time { font-size: 0.75rem; color: #bbb; margin-top: 4px; user-select: none; }
.notification-clear { font-size: 0.8rem; color: #bbb; cursor: pointer; text-align: right; margin-bottom: 8px; user-select: none; padding: 0 10px; }
.notification-clear:hover { color: white; }
.user-menu { display: flex; align-items: center; gap: 0.75rem; background: rgba(255,255,255,0.1); border: 1px solid rgba(255,255,255,0.2); border-radius: 20px; padding: 0.5rem 1rem; cursor: pointer; transition: all 0.3s; backdrop-filter: blur(10px); user-select: none; position: relative; }
.user-menu:hover { background: rgba(255,255,255,0.2); transform: translateY(-2px); box-shadow: 0 8px 25px rgba(0,0,0,0.2); }
.user-avatar { background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); width: 32px; height: 32px; border-radius: 50%; color: white; font-weight: 700; font-size: 1rem; display: flex; align-items: center; justify-content: center; box-shadow: 0 4px 15px rgba(102,126,234,0.3); user-select: none; flex-shrink: 0; }
.user-infos { display: flex; flex-direction: column; gap: 0.15rem; max-width: 140px; overflow: hidden; white-space: nowrap; text-overflow: ellipsis; user-select: text; }
.user-name { font-weight: 600; font-size: 0.9rem; color: white; user-select: text; }
.user-role { font-size: 0.75rem; color: rgba(255,255,255,0.7); text-transform: capitalize; user-select: none; }
.dropdown-menu { position: absolute; top: 120%; right: 0; background: rgba(0,0,0,0.85); border-radius: 12px; padding: 8px 0; min-width: 200px; box-shadow: 0 10px 30px rgba(0,0,0,0.7); opacity: 0; visibility: hidden; transform: translateY(-10px); transition: all 0.3s; z-index: 1500; user-select: none; }
.dropdown-menu.show { opacity: 1; visibility: visible; transform: translateY(0); }
.dropdown-item { display: flex; align-items: center; gap: 10px; padding: 10px 16px; color: white; font-size: 0.9rem; cursor: pointer; transition: background 0.3s ease; text-decoration: none; user-select: none; }
.dropdown-item:hover { background: rgba(255,255,255,0.15); text-decoration: none; }
@media (max-width: 768px) { .navbar { left: 0 !important; padding: 0 1rem; } .welcome-message, .search-container { display: none; } }
</style>

<!-- Sizin verdiğiniz HTML, hiç değiştirilmedi -->
<nav class="navbar" id="navbar">
  <div class="welcome-message"><i class="fas fa-sun"></i> Hoş geldiniz, <?= htmlspecialchars($kullanici_isim) ?>!</div>
  <div class="search-container"><i class="fas fa-search search-icon"></i><input type="text" class="search-input" placeholder="Ara... (Ctrl+K)" id="searchInput" autocomplete="off"></div>
  <div class="navbar-right">
    <div class="navbar-item" id="notificationButton" title="Bildirimler">
      <i class="fas fa-bell"></i>
      <span class="notification-badge" id="notificationCount" style="display:none;"></span>
      <div class="notification-dropdown" id="notificationDropdown">
        <div class="notification-clear" id="clearNotificationsBtn">Tümünü Temizle</div>
        <div id="notificationList"> <div class="notification-item">Bildirim yok.</div> </div>
      </div>
    </div>
    <a href="#" class="navbar-item" title="Ayarlar"><i class="fas fa-cog"></i></a>
    <div class="user-menu" id="userMenu"><div class="user-avatar"><?= strtoupper(substr($kullanici_isim,0,1)) ?></div><div class="user-infos"><div class="user-name"><?= htmlspecialchars($kullanici_isim) ?></div><div class="user-role"><?= ucfirst($kullanici_rutbe) ?></div></div><i class="fas fa-chevron-down" style="font-size: 0.8rem;"></i>
      <div class="dropdown-menu" id="userDropdown"><a href="profil.php" class="dropdown-item"><i class="fas fa-user"></i> Profil</a><a href="sifre_degistir.php" class="dropdown-item"><i class="fas fa-key"></i> Şifre Değiştir</a><div style="border-top:1px solid #555; margin: 4px 0;"></div><a href="cikis.php" class="dropdown-item"><i class="fas fa-sign-out-alt"></i> Çıkış Yap</a></div>
    </div>
  </div>
</nav>

<!-- SES DOSYASI İÇİN ELEMENT -->
<audio id="notificationSound" src="ses/bildirim.mp3" preload="auto"></audio>

<!-- TAMAMEN YENİLENMİŞ VE ÇALIŞAN JAVASCRIPT -->
<script>
document.addEventListener('DOMContentLoaded', function () {
    const notificationButton = document.getElementById('notificationButton');
    const notificationDropdown = document.getElementById('notificationDropdown');
    const userMenu = document.getElementById('userMenu');
    const userDropdown = document.getElementById('userDropdown');

    const notificationList = document.getElementById('notificationList');
    const notificationCountBadge = document.getElementById('notificationCount');
    const clearBtn = document.getElementById('clearNotificationsBtn');
    const notificationSound = document.getElementById('notificationSound');

    let lastNotificationCount = 0; // Son bilinen bildirim sayısını sakla
    let firstLoad = true; // Sayfa ilk yüklendiğinde ses çalmasını engelle

    // Bildirimleri getiren ve arayüzü güncelleyen fonksiyon
    function fetchNotifications() {
        fetch('bildirim_veri.php')
            .then(res => res.ok ? res.json() : Promise.reject('Sunucu hatası'))
            .then(data => {
                if (data.ok) {
                    const bildirimler = data.bildirimler;
                    const count = bildirimler.length;
                    notificationCountBadge.textContent = count;
                    
                    if (count > 0) {
                        notificationCountBadge.style.display = 'block';
                        notificationList.innerHTML = '';
                        bildirimler.forEach(b => {
                            const link = document.createElement('a');
                            link.href = 'is_takvimi.php'; // Bildirime tıklayınca takvime gitsin
                            link.className = 'notification-item unread';
                            link.innerHTML = `
                                ${b.baslik}
                                <div class="notification-time">${new Date(b.baslangic).toLocaleString('tr-TR')}</div>
                            `;
                            notificationList.appendChild(link);
                        });
                        
                        // Sadece yeni bir bildirim geldiğinde (sayfa ilk yüklendiğinde değil) ses çal
                        if (count > lastNotificationCount && !firstLoad) {
                           notificationSound.play().catch(e => {});
                        }
                    } else {
                        notificationCountBadge.style.display = 'none';
                        notificationList.innerHTML = '<div class="notification-item">Yeni bildirim yok.</div>';
                    }
                    lastNotificationCount = count; // Sayıyı güncelle
                    firstLoad = false; // İlk yükleme bitti
                }
            }).catch(err => console.error("Bildirimler alınamadı:", err));
    }
    
    // Bildirimleri temizle butonu
    clearBtn.addEventListener('click', (e) => {
        e.stopPropagation();
        fetch('bildirim_temizle.php', { method: 'POST' })
            .then(res => res.json())
            .then(data => {
                if (data.ok) { fetchNotifications(); }
            });
    });

    // Dropdown açma/kapatma mantığı
    notificationButton.addEventListener('click', (e) => {
        e.stopPropagation();
        userDropdown.classList.remove('show');
        notificationDropdown.classList.toggle('show');
    });

    userMenu.addEventListener('click', (e) => {
        e.stopPropagation();
        notificationDropdown.classList.remove('show');
        userDropdown.classList.toggle('show');
    });

    document.addEventListener('click', () => {
        notificationDropdown.classList.remove('show');
        userDropdown.classList.remove('show');
    });

    // Başlangıç ve periyodik kontrol
    fetchNotifications();
    setInterval(fetchNotifications, 15000); // 15 saniyede bir kontrol et
});
</script>