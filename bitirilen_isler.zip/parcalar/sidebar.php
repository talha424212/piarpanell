<?php
if (!isset($_SESSION['kullanici'])) {
  header("Location: giris.php");
  exit;
}
$kullanici = $_SESSION['kullanici'];

// Kullanıcı verilerini güvenli hale getir
$kullanici_isim = $kullanici['isim'] ?? $kullanici['mail'] ?? 'Kullanıcı';
$kullanici_rutbe = $kullanici['rutbe'] ?? 'kullanıcı';
?>

<style>
/* ===== SIDEBAR CONTAINER ===== */
.sidebar {
  position: fixed;
  top: 0;
  left: 0;
  height: 100vh;
  width: 280px;
  background: rgba(255, 255, 255, 0.1);
  backdrop-filter: blur(20px);
  border-right: 1px solid rgba(255, 255, 255, 0.2);
  z-index: 1000;
  transition: all 0.4s cubic-bezier(0.175, 0.885, 0.32, 1.275);
  overflow-y: auto;
  overflow-x: hidden;
  display: flex;
  flex-direction: column;
  scrollbar-width: thin;
  scrollbar-color: #667eea rgba(255, 255, 255, 0.03);
}

.sidebar.collapsed {
  width: 80px;
}

/* ===== SIDEBAR HEADER ===== */
.sidebar-header {
  padding: 2rem 1.5rem 1rem;
  border-bottom: 1px solid rgba(255, 255, 255, 0.1);
  position: relative;
  flex-shrink: 0;
}

.sidebar.collapsed .sidebar-header {
  padding: 2rem 1rem 1rem;
}

.logo-container {
  display: flex;
  align-items: center;
  gap: 1rem;
  transition: all 0.3s ease;
}

.sidebar.collapsed .logo-container {
  justify-content: center;
}

.logo-icon {
  width: 50px;
  height: 50px;
  background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
  border-radius: 15px;
  display: flex;
  align-items: center;
  justify-content: center;
  color: white;
  font-size: 1.5rem;
  font-weight: bold;
  box-shadow: 0 8px 25px rgba(102, 126, 234, 0.3);
  transition: all 0.3s ease;
  flex-shrink: 0;
}

.logo-icon:hover {
  transform: scale(1.1) rotate(5deg);
  box-shadow: 0 12px 35px rgba(102, 126, 234, 0.4);
}

.logo-text {
  color: white;
  font-size: 1.5rem;
  font-weight: 800;
  text-shadow: 0 2px 4px rgba(0, 0, 0, 0.3);
  transition: all 0.3s ease;
  opacity: 1;
  transform: translateX(0);
  white-space: nowrap;
}

.sidebar.collapsed .logo-text {
  opacity: 0;
  transform: translateX(-20px);
  width: 0;
  overflow: hidden;
}

.toggle-btn {
  position: absolute;
  top: 1.5rem;
  right: 1rem;
  background: rgba(255, 255, 255, 0.1);
  border: 1px solid rgba(255, 255, 255, 0.2);
  color: white;
  width: 35px;
  height: 35px;
  border-radius: 10px;
  display: flex;
  align-items: center;
  justify-content: center;
  cursor: pointer;
  transition: all 0.3s ease;
  backdrop-filter: blur(10px);
  flex-shrink: 0;
}

.toggle-btn:hover {
  background: rgba(255, 255, 255, 0.2);
  transform: scale(1.1);
  box-shadow: 0 5px 15px rgba(0, 0, 0, 0.2);
}

.sidebar.collapsed .toggle-btn {
  right: 0.5rem;
}

/* ===== SIDEBAR NAVIGATION ===== */
.sidebar-nav {
  padding: 1rem 0;
  flex: 1;
  overflow-y: auto;
  overflow-x: hidden;
  scrollbar-width: thin;
  scrollbar-color: #667eea rgba(255, 255, 255, 0.03);
}

.nav-section {
  margin-bottom: 1rem;
}

.nav-section-title {
  color: rgba(255, 255, 255, 0.7);
  font-size: 0.8rem;
  font-weight: 600;
  text-transform: uppercase;
  letter-spacing: 1px;
  padding: 0 1.5rem 0.5rem;
  margin-bottom: 0.5rem;
  transition: all 0.3s ease;
  opacity: 1;
  transform: translateX(0);
  white-space: nowrap;
}

.sidebar.collapsed .nav-section-title {
  opacity: 0;
  transform: translateX(-20px);
  width: 0;
  overflow: hidden;
}

.nav-item {
  position: relative;
  margin: 0.25rem 0;
  animation: slideIn 0.3s ease forwards;
}

.nav-item:nth-child(1) { animation-delay: 0.1s; }
.nav-item:nth-child(2) { animation-delay: 0.2s; }
.nav-item:nth-child(3) { animation-delay: 0.3s; }
.nav-item:nth-child(4) { animation-delay: 0.4s; }
.nav-item:nth-child(5) { animation-delay: 0.5s; }
.nav-item:nth-child(6) { animation-delay: 0.6s; }
.nav-item:nth-child(7) { animation-delay: 0.7s; }
.nav-item:nth-child(8) { animation-delay: 0.8s; }

.nav-link {
  display: flex;
  align-items: center;
  gap: 1rem;
  padding: 1rem 1.5rem;
  color: rgba(255, 255, 255, 0.8);
  text-decoration: none;
  border-radius: 0 25px 25px 0;
  margin-right: 1rem;
  transition: all 0.3s cubic-bezier(0.175, 0.885, 0.32, 1.275);
  position: relative;
  overflow: hidden;
  white-space: nowrap;
}

.sidebar.collapsed .nav-link {
  padding: 1rem;
  margin-right: 0.5rem;
  justify-content: center;
}

.nav-link::before {
  content: '';
  position: absolute;
  top: 0;
  left: -100%;
  width: 100%;
  height: 100%;
  background: linear-gradient(90deg, transparent, rgba(255,255,255,0.1), transparent);
  transition: left 0.5s ease;
}

.nav-link:hover::before {
  left: 100%;
}

.nav-link:hover {
  color: white;
  background: rgba(255, 255, 255, 0.1);
  transform: translateX(10px);
  box-shadow: 0 5px 15px rgba(0, 0, 0, 0.1);
}

.nav-link.active {
  background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
  color: white;
  box-shadow: 0 8px 25px rgba(102, 126, 234, 0.3);
  transform: translateX(10px);
}

.nav-icon {
  width: 20px;
  height: 20px;
  display: flex;
  align-items: center;
  justify-content: center;
  font-size: 1.1rem;
  transition: all 0.3s ease;
  flex-shrink: 0;
}

.nav-text {
  transition: all 0.3s ease;
  opacity: 1;
  transform: translateX(0);
}

.sidebar.collapsed .nav-text {
  opacity: 0;
  transform: translateX(-20px);
  width: 0;
  overflow: hidden;
}

.nav-badge {
  background: rgba(255, 255, 255, 0.2);
  color: white;
  border-radius: 10px;
  padding: 0.25rem 0.5rem;
  font-size: 0.7rem;
  font-weight: 600;
  margin-left: auto;
  transition: all 0.3s ease;
}

.sidebar.collapsed .nav-badge {
  opacity: 0;
  transform: translateX(-20px);
  width: 0;
  overflow: hidden;
}

/* ===== SIDEBAR FOOTER ===== */
.sidebar-footer {
  padding: 1rem 1.5rem;
  border-top: 1px solid rgba(255, 255, 255, 0.1);
  flex-shrink: 0;
  transition: all 0.3s ease;
}

.sidebar.collapsed .sidebar-footer {
  padding: 1rem;
}

.user-info {
  display: flex;
  align-items: center;
  gap: 1rem;
  padding: 1rem;
  background: rgba(255, 255, 255, 0.05);
  border-radius: 15px;
  transition: all 0.3s ease;
}

.sidebar.collapsed .user-info {
  justify-content: center;
  padding: 1rem 0.5rem;
}

.user-avatar {
  width: 40px;
  height: 40px;
  background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
  border-radius: 50%;
  display: flex;
  align-items: center;
  justify-content: center;
  color: white;
  font-weight: bold;
  font-size: 1rem;
  box-shadow: 0 4px 15px rgba(102, 126, 234, 0.3);
  transition: all 0.3s ease;
  flex-shrink: 0;
}

.user-details {
  flex: 1;
  transition: all 0.3s ease;
  opacity: 1;
  transform: translateX(0);
}

.sidebar.collapsed .user-details {
  opacity: 0;
  transform: translateX(-20px);
  width: 0;
  overflow: hidden;
}

.user-name {
  color: white;
  font-weight: 600;
  font-size: 0.9rem;
  margin-bottom: 0.25rem;
  white-space: nowrap;
}

.user-role {
  color: rgba(255, 255, 255, 0.7);
  font-size: 0.8rem;
  text-transform: capitalize;
  white-space: nowrap;
}

.logout-btn {
  display: flex;
  align-items: center;
  gap: 0.5rem;
  padding: 0.75rem 1rem;
  background: rgba(255, 65, 108, 0.2);
  border: 1px solid rgba(255, 65, 108, 0.3);
  color: white;
  text-decoration: none;
  border-radius: 12px;
  margin-top: 1rem;
  transition: all 0.3s ease;
  backdrop-filter: blur(10px);
  white-space: nowrap;
}

.logout-btn:hover {
  background: rgba(255, 65, 108, 0.3);
  transform: translateY(-2px);
  box-shadow: 0 8px 25px rgba(255, 65, 108, 0.3);
  color: white;
  text-decoration: none;
}

.sidebar.collapsed .logout-btn {
  justify-content: center;
  padding: 0.75rem;
}

.sidebar.collapsed .logout-btn span {
  opacity: 0;
  transform: translateX(-20px);
  width: 0;
  overflow: hidden;
}

/* ===== SCROLLBAR STYLES ===== */
.sidebar::-webkit-scrollbar,
.sidebar-nav::-webkit-scrollbar {
  width: 8px;
}

.sidebar::-webkit-scrollbar-track,
.sidebar-nav::-webkit-scrollbar-track {
  background: rgba(255, 255, 255, 0.03);
  border-radius: 15px;
  margin: 5px 0;
  box-shadow: inset 0 0 6px rgba(0, 0, 0, 0.1);
}

.sidebar::-webkit-scrollbar-thumb,
.sidebar-nav::-webkit-scrollbar-thumb {
  background: linear-gradient(135deg, #667eea 0%, #764ba2 50%, #667eea 100%);
  border-radius: 15px;
  border: 2px solid rgba(255, 255, 255, 0.1);
  box-shadow: 
    0 0 10px rgba(102, 126, 234, 0.3),
    inset 0 0 10px rgba(255, 255, 255, 0.1);
  transition: all 0.4s cubic-bezier(0.175, 0.885, 0.32, 1.275);
  position: relative;
}

.sidebar::-webkit-scrollbar-thumb::before,
.sidebar-nav::-webkit-scrollbar-thumb::before {
  content: '';
  position: absolute;
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  background: linear-gradient(45deg, transparent 30%, rgba(255, 255, 255, 0.2) 50%, transparent 70%);
  border-radius: 15px;
  animation: shimmer 2s infinite;
}

.sidebar::-webkit-scrollbar-thumb:hover,
.sidebar-nav::-webkit-scrollbar-thumb:hover {
  background: linear-gradient(135deg, #5a6fd8 0%, #6a4190 50%, #5a6fd8 100%);
  transform: scale(1.05);
  box-shadow: 
    0 0 20px rgba(102, 126, 234, 0.5),
    inset 0 0 15px rgba(255, 255, 255, 0.2);
  border-color: rgba(255, 255, 255, 0.2);
}

.sidebar::-webkit-scrollbar-thumb:active,
.sidebar-nav::-webkit-scrollbar-thumb:active {
  background: linear-gradient(135deg, #4a5fc8 0%, #5a3190 50%, #4a5fc8 100%);
  transform: scale(1.1);
  box-shadow: 
    0 0 25px rgba(102, 126, 234, 0.7),
    inset 0 0 20px rgba(255, 255, 255, 0.3);
}

.sidebar::-webkit-scrollbar-corner,
.sidebar-nav::-webkit-scrollbar-corner {
  background: transparent;
}

/* ===== ANIMATIONS ===== */
@keyframes shimmer {
  0% { transform: translateX(-100%); }
  100% { transform: translateX(100%); }
}

@keyframes slideIn {
  from {
    opacity: 0;
    transform: translateX(-20px);
  }
  to {
    opacity: 1;
    transform: translateX(0);
  }
}

/* ===== TOOLTIPS ===== */
.sidebar.collapsed .nav-link {
  position: relative;
}

.sidebar.collapsed .nav-link::after {
  content: attr(data-tooltip);
  position: absolute;
  left: 100%;
  top: 50%;
  transform: translateY(-50%);
  background: rgba(0, 0, 0, 0.8);
  color: white;
  padding: 0.5rem 0.75rem;
  border-radius: 8px;
  font-size: 0.8rem;
  white-space: nowrap;
  opacity: 0;
  pointer-events: none;
  transition: all 0.3s ease;
  margin-left: 10px;
  z-index: 1001;
}

.sidebar.collapsed .nav-link:hover::after {
  opacity: 1;
}

/* ===== MOBILE RESPONSIVENESS ===== */
@media (max-width: 768px) {
  .sidebar {
    transform: translateX(-100%);
    width: 280px;
  }
  
  .sidebar.mobile-open {
    transform: translateX(0);
  }
  
  .sidebar.collapsed {
    width: 280px;
  }
  
  .sidebar.collapsed .logo-text,
  .sidebar.collapsed .nav-text,
  .sidebar.collapsed .nav-section-title,
  .sidebar.collapsed .user-details,
  .sidebar.collapsed .logout-btn span {
    opacity: 1;
    transform: translateX(0);
    width: auto;
    overflow: visible;
  }
  
  .sidebar.collapsed .nav-link {
    padding: 1rem 1.5rem;
    margin-right: 1rem;
    justify-content: flex-start;
  }
  
  .sidebar.collapsed .toggle-btn {
    right: 1rem;
  }
  
  .sidebar.collapsed .sidebar-header {
    padding: 2rem 1.5rem 1rem;
  }
  
  .sidebar.collapsed .sidebar-footer {
    padding: 1rem 1.5rem;
  }
  
  .sidebar.collapsed .user-info {
    justify-content: flex-start;
    padding: 1rem;
  }
  
  .sidebar.collapsed .logout-btn {
    justify-content: flex-start;
    padding: 0.75rem 1rem;
  }
}
</style>

<div class="sidebar" id="sidebar">
  <div class="sidebar-header">
    <div class="logo-container">
      <div class="logo-icon">
        <i class="fas fa-cube"></i>
      </div>
      <div class="logo-text">Piar Panel</div>
    </div>
    <button class="toggle-btn" onclick="toggleSidebar()" title="Menüyü Daralt/Genişlet">
      <i class="fas fa-bars"></i>
    </button>
  </div>

  <nav class="sidebar-nav">
    <div class="nav-section">
      <div class="nav-section-title">Ana Menü</div>
      
      <div class="nav-item">
        <a href="panel.php" class="nav-link <?= basename($_SERVER['PHP_SELF']) == 'panel.php' ? 'active' : '' ?>" data-tooltip="Dashboard">
          <div class="nav-icon">
            <i class="fas fa-tachometer-alt"></i>
          </div>
          <span class="nav-text">Dashboard</span>
        </a>
      </div>

      <div class="nav-item">
        <a href="islerim.php" class="nav-link <?= basename($_SERVER['PHP_SELF']) == 'islerim.php' ? 'active' : '' ?>" data-tooltip="İşlerim">
          <div class="nav-icon">
            <i class="fas fa-tasks"></i>
          </div>
          <span class="nav-text">İşlerim</span>
          <span class="nav-badge"><?= $kullanici['rutbe'] === 'patron' ? 'Yönet' : 'Görüntüle' ?></span>
        </a>
      </div>

      <div class="nav-item">
        <a href="mesai.php" class="nav-link <?= basename($_SERVER['PHP_SELF']) == 'mesai.php' ? 'active' : '' ?>" data-tooltip="Mesai Takibi">
          <div class="nav-icon">
            <i class="fas fa-clock"></i>
          </div>
          <span class="nav-text">Mesai Takibi</span>
        </a>
      </div>
      
            <div class="nav-item">
        <a href="takvim.php" class="nav-link <?= basename($_SERVER['PHP_SELF']) == 'takvim.php' ? 'active' : '' ?>" data-tooltip="Mesai Takibi">
          <div class="nav-icon">
            <i class="fas fa-clock"></i>
          </div>
          <span class="nav-text">İş Takip Takvimi</span>
        </a>
      </div>

      <div class="nav-item">
        <a href="giris-cikis.php" class="nav-link <?= basename($_SERVER['PHP_SELF']) == 'giris-cikis.php' ? 'active' : '' ?>" data-tooltip="Giriş/Çıkış">
          <div class="nav-icon">
            <i class="fas fa-sign-in-alt"></i>
          </div>
          <span class="nav-text">Giriş/Çıkış</span>
        </a>
      </div>

     
    </div>

    <?php if ($kullanici['rutbe'] === 'patron'): ?>
    <div class="nav-section">
      <div class="nav-section-title">Yönetim</div>
      
      <div class="nav-item">
        <a href="personel-yonetimi.php" class="nav-link <?= basename($_SERVER['PHP_SELF']) == 'personel-yonetimi.php' ? 'active' : '' ?>" data-tooltip="Personel Yönetimi">
          <div class="nav-icon">
            <i class="fas fa-users-cog"></i>
          </div>
          <span class="nav-text">Personel Yönetimi</span>
        </a>
      </div>

      <div class="nav-item">
        <a href="is-atama.php" class="nav-link <?= basename($_SERVER['PHP_SELF']) == 'is-atama.php' ? 'active' : '' ?>" data-tooltip="İş Atama">
          <div class="nav-icon">
            <i class="fas fa-user-plus"></i>
          </div>
          <span class="nav-text">İş Atama</span>
        </a>
      </div>
       <div class="nav-item">
        <a href="izinler.php" class="nav-link <?= basename($_SERVER['PHP_SELF']) == 'izinler.php' ? 'active' : '' ?>" data-tooltip="İzin Yönetimi">
          <div class="nav-icon">
            <i class="fas fa-calendar-check"></i>
          </div>
          <span class="nav-text">İzin Yönetimi</span>
        </a>
      </div>
       <div class="nav-item">
        <a href="bitirilen_isler.php" class="nav-link <?= basename($_SERVER['PHP_SELF']) == 'bitirilen_isler.php' ? 'active' : '' ?>" data-tooltip="İzin Yönetimi">
          <div class="nav-icon">
            <i class="fas fa-calendar-check"></i>
          </div>
          <span class="nav-text">İş Yönetimi</span>
        </a>
      </div>
    </div>
    <?php endif; ?>

    <div class="nav-section">
      <div class="nav-section-title">Kişisel</div>
      
      <div class="nav-item">
        <a href="profil.php" class="nav-link <?= basename($_SERVER['PHP_SELF']) == 'profil.php' ? 'active' : '' ?>" data-tooltip="Profil">
          <div class="nav-icon">
            <i class="fas fa-user"></i>
          </div>
          <span class="nav-text">Profil</span>
        </a>
      </div>

      <div class="nav-item">
        <a href="sifre-degistir.php" class="nav-link <?= basename($_SERVER['PHP_SELF']) == 'sifre-degistir.php' ? 'active' : '' ?>" data-tooltip="Şifre Değiştir">
          <div class="nav-icon">
            <i class="fas fa-key"></i>
          </div>
          <span class="nav-text">Şifre Değiştir</span>
        </a>
      </div>

      <div class="nav-item">
        <a href="ayarlar.php" class="nav-link <?= basename($_SERVER['PHP_SELF']) == 'ayarlar.php' ? 'active' : '' ?>" data-tooltip="Ayarlar">
          <div class="nav-icon">
            <i class="fas fa-cog"></i>
          </div>
          <span class="nav-text">Ayarlar</span>
        </a>
      </div>
    </div>
  </nav>

  <div class="sidebar-footer">
    <div class="user-info">
      <div class="user-avatar">
        <?= strtoupper(substr($kullanici_isim, 0, 1)) ?>
      </div>
      <div class="user-details">
        <div class="user-name"><?= htmlspecialchars($kullanici_isim) ?></div>
        <div class="user-role"><?= ucfirst($kullanici_rutbe) ?></div>
      </div>
    </div>
    
    <a href="cikis.php" class="logout-btn">
      <i class="fas fa-sign-out-alt"></i>
      <span>Çıkış Yap</span>
    </a>
  </div>
</div>

<script>
// Sidebar toggle functionality
function toggleSidebar() {
  const sidebar = document.getElementById('sidebar');
  const mainContent = document.querySelector('.main-content');
  const navbar = document.getElementById('navbar');
  
  if (sidebar.classList.contains('collapsed')) {
    sidebar.classList.remove('collapsed');
    if (mainContent) {
      mainContent.classList.remove('sidebar-collapsed');
    }
    if (navbar) {
      navbar.classList.remove('sidebar-collapsed');
    }
    localStorage.setItem('sidebarCollapsed', 'false');
  } else {
    sidebar.classList.add('collapsed');
    if (mainContent) {
      mainContent.classList.add('sidebar-collapsed');
    }
    if (navbar) {
      navbar.classList.add('sidebar-collapsed');
    }
    localStorage.setItem('sidebarCollapsed', 'true');
  }
}

// Load sidebar state on page load
document.addEventListener('DOMContentLoaded', function() {
  const sidebarCollapsed = localStorage.getItem('sidebarCollapsed') === 'true';
  const sidebar = document.getElementById('sidebar');
  const mainContent = document.querySelector('.main-content');
  const navbar = document.getElementById('navbar');
  
  if (sidebarCollapsed) {
    sidebar.classList.add('collapsed');
    if (mainContent) {
      mainContent.classList.add('sidebar-collapsed');
    }
    if (navbar) {
      navbar.classList.add('sidebar-collapsed');
    }
  }
  
  // Mobile menu functionality
  const mobileMenuBtn = document.querySelector('.mobile-menu-btn');
  if (mobileMenuBtn) {
    mobileMenuBtn.addEventListener('click', function() {
      sidebar.classList.toggle('mobile-open');
    });
  }
  
  // Close mobile menu when clicking outside
  document.addEventListener('click', function(e) {
    if (window.innerWidth <= 768) {
      if (!sidebar.contains(e.target) && !mobileMenuBtn?.contains(e.target)) {
        sidebar.classList.remove('mobile-open');
      }
    }
  });
  
  // Touch gestures for mobile
  let touchStartX = 0;
  let touchEndX = 0;
  
  document.addEventListener('touchstart', function(e) {
    touchStartX = e.changedTouches[0].screenX;
  });
  
  document.addEventListener('touchend', function(e) {
    touchEndX = e.changedTouches[0].screenX;
    handleSwipe();
  });
  
  function handleSwipe() {
    const swipeThreshold = 50;
    const diff = touchStartX - touchEndX;
    
    if (Math.abs(diff) > swipeThreshold) {
      if (diff > 0 && touchStartX < 100) {
        // Swipe left from left edge - open sidebar
        sidebar.classList.add('mobile-open');
      } else if (diff < 0 && sidebar.classList.contains('mobile-open')) {
        // Swipe right - close sidebar
        sidebar.classList.remove('mobile-open');
      }
    }
  }
});

// Add hover effects for collapsed sidebar
document.addEventListener('DOMContentLoaded', function() {
  const sidebar = document.getElementById('sidebar');
  
  if (sidebar.classList.contains('collapsed')) {
    const navLinks = sidebar.querySelectorAll('.nav-link');
    
    navLinks.forEach(link => {
      const tooltip = link.getAttribute('data-tooltip');
      if (tooltip) {
        link.setAttribute('title', tooltip);
      }
    });
  }
});
</script>

