<?php
session_start();
if (!isset($_SESSION['kullanici'])) {
    header("Location: giris.php");
    exit;
}

// if ($_SESSION['kullanici']['rutbe'] !== 'patron') {
//     die("Bu sayfayı görüntüleme yetkiniz yok.");
// }

require_once 'baglan.php';

$stmt = $db->prepare("SELECT id, isim, soyisim FROM kullanicilar ORDER BY isim, soyisim");
$stmt->execute();
$kullanicilar = $stmt->fetchAll(PDO::FETCH_ASSOC);

$secili_kullanici_id = $_GET['kullanici_id'] ?? null;
$mesailer = [];

if ($secili_kullanici_id) {
    $stmt = $db->prepare("SELECT * FROM mesailer WHERE calisan_id = ? ORDER BY baslangic DESC");
    $stmt->execute([$secili_kullanici_id]);
    $mesailer = $stmt->fetchAll(PDO::FETCH_ASSOC);
}
?>

<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <title>Giriş/Çıkış Kayıtları - Piar Panel</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.6/dist/css/bootstrap.min.css" rel="stylesheet" />
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet" />
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap" rel="stylesheet" />
    <style>
        * {
            font-family: 'Inter', sans-serif;
        }
        
        body {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            min-height: 100vh;
            position: relative;
        }
        
        body::before {
            content: '';
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: url('data:image/svg+xml,<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 100 100"><defs><pattern id="grain" width="100" height="100" patternUnits="userSpaceOnUse"><circle cx="25" cy="25" r="1" fill="rgba(255,255,255,0.1)"/><circle cx="75" cy="75" r="1" fill="rgba(255,255,255,0.1)"/><circle cx="50" cy="10" r="0.5" fill="rgba(255,255,255,0.1)"/><circle cx="10" cy="60" r="0.5" fill="rgba(255,255,255,0.1)"/><circle cx="90" cy="40" r="0.5" fill="rgba(255,255,255,0.1)"/></pattern></defs><rect width="100" height="100" fill="url(%23grain)"/></svg>');
            pointer-events: none;
            z-index: -1;
        }
        
        .main-content {
            margin-left: 280px;
            padding: 2rem;
            min-height: 100vh;
        }
        
        .page-header {
            background: rgba(255, 255, 255, 0.1);
            backdrop-filter: blur(20px);
            border-radius: 20px;
            padding: 2rem;
            margin-bottom: 2rem;
            border: 1px solid rgba(255, 255, 255, 0.2);
            box-shadow: 0 8px 32px rgba(0, 0, 0, 0.1);
        }
        
        .page-title {
            color: white;
            font-weight: 700;
            font-size: 2.5rem;
            margin: 0;
            text-shadow: 0 2px 4px rgba(0, 0, 0, 0.3);
            display: flex;
            align-items: center;
            gap: 1rem;
        }
        
        .page-subtitle {
            color: rgba(255, 255, 255, 0.8);
            font-weight: 400;
            margin: 0.5rem 0 0 0;
            font-size: 1.1rem;
        }
        
        .content-container {
            background: rgba(255, 255, 255, 0.95);
            backdrop-filter: blur(20px);
            border-radius: 20px;
            padding: 2rem;
            box-shadow: 0 20px 40px rgba(0, 0, 0, 0.1);
            border: 1px solid rgba(255, 255, 255, 0.2);
            transition: transform 0.3s ease, box-shadow 0.3s ease;
            margin-bottom: 2rem;
        }
        
        .content-container:hover {
            transform: translateY(-5px);
            box-shadow: 0 25px 50px rgba(0, 0, 0, 0.15);
        }
        
        .form-control, .form-select {
            border-radius: 10px;
            border: 2px solid #e9ecef;
            padding: 0.75rem;
            transition: all 0.3s ease;
        }
        
        .form-control:focus, .form-select:focus {
            border-color: #667eea;
            box-shadow: 0 0 0 0.2rem rgba(102, 126, 234, 0.25);
        }
        
        .table {
            background: rgba(255, 255, 255, 0.9);
            border-radius: 15px;
            overflow: hidden;
            box-shadow: 0 5px 15px rgba(0, 0, 0, 0.1);
        }
        
        .table thead th {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            border: none;
            font-weight: 600;
            padding: 1rem;
        }
        
        .table tbody tr {
            transition: all 0.3s ease;
        }
        
        .table tbody tr:hover {
            background: rgba(102, 126, 234, 0.05);
            transform: scale(1.01);
        }
        
        .table td {
            padding: 1rem;
            border: none;
            border-bottom: 1px solid rgba(0, 0, 0, 0.05);
        }
        
        .badge {
            border-radius: 8px;
            font-weight: 500;
            padding: 0.5rem 0.75rem;
        }
        
        .badge-primary {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
        }
        
        .badge-success {
            background: linear-gradient(135deg, #28a745 0%, #20c997 100%);
            color: white;
        }
        
        .badge-warning {
            background: linear-gradient(135deg, #ffc107 0%, #fd7e14 100%);
            color: white;
        }
        
        .stats-cards {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 1.5rem;
            margin-bottom: 2rem;
        }
        
        .stat-card {
            background: rgba(255, 255, 255, 0.1);
            backdrop-filter: blur(20px);
            border-radius: 15px;
            padding: 1.5rem;
            border: 1px solid rgba(255, 255, 255, 0.2);
            box-shadow: 0 8px 32px rgba(0, 0, 0, 0.1);
            transition: all 0.3s ease;
            color: white;
            text-align: center;
        }
        
        .stat-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 15px 40px rgba(0, 0, 0, 0.2);
        }
        
        .stat-icon {
            font-size: 2rem;
            margin-bottom: 1rem;
            opacity: 0.9;
        }
        
        .stat-number {
            font-size: 1.8rem;
            font-weight: 700;
            margin-bottom: 0.5rem;
        }
        
        .stat-label {
            font-size: 0.9rem;
            opacity: 0.8;
            font-weight: 500;
        }
        
        @media (max-width: 768px) {
            .main-content {
                margin-left: 0;
                padding: 1rem;
            }
            
            .page-title {
                font-size: 2rem;
            }
            
            .stats-cards {
                grid-template-columns: 1fr;
            }
        }
    </style>
</head>
<body>

<?php include 'parcalar/sidebar.php'; ?>
<?php include 'parcalar/navbar.php'; ?>

<div class="main-content">
    <div class="page-header">
        <h1 class="page-title">
            <i class="fas fa-sign-in-alt"></i>
            Giriş/Çıkış Kayıtları
        </h1>
        <p class="page-subtitle">Çalışan mesai kayıtlarını görüntüleyin ve takip edin</p>
    </div>

    <div class="stats-cards">
        <div class="stat-card">
            <div class="stat-icon">
                <i class="fas fa-users"></i>
            </div>
            <div class="stat-number"><?= count($kullanicilar) ?></div>
            <div class="stat-label">Toplam Çalışan</div>
        </div>
        <div class="stat-card">
            <div class="stat-icon">
                <i class="fas fa-clock"></i>
            </div>
            <div class="stat-number"><?= count($mesailer) ?></div>
            <div class="stat-label">Toplam Mesai</div>
        </div>
        <div class="stat-card">
            <div class="stat-icon">
                <i class="fas fa-play-circle"></i>
            </div>
            <div class="stat-number">
                <?php
                $devam_eden = array_filter($mesailer, function($mesai) {
                    return !$mesai['bitis'];
                });
                echo count($devam_eden);
                ?>
            </div>
            <div class="stat-label">Devam Eden</div>
        </div>
        <div class="stat-card">
            <div class="stat-icon">
                <i class="fas fa-stop-circle"></i>
            </div>
            <div class="stat-number">
                <?php
                $biten = array_filter($mesailer, function($mesai) {
                    return $mesai['bitis'];
                });
                echo count($biten);
                ?>
            </div>
            <div class="stat-label">Tamamlanan</div>
        </div>
    </div>

    <div class="content-container">
        <form method="GET" action="">
            <div class="mb-3">
                <label for="kullanici_id" class="form-label">
                    <i class="fas fa-user me-2"></i>
                    Çalışan Seçin:
                </label>
                <select name="kullanici_id" id="kullanici_id" class="form-select form-select-lg" onchange="this.form.submit()">
                    <option value="">-- Seçiniz --</option>
                    <?php foreach ($kullanicilar as $kullanici): ?>
                        <option value="<?= $kullanici['id'] ?>" <?= ($kullanici['id'] == $secili_kullanici_id) ? 'selected' : '' ?>>
                            <?= htmlspecialchars($kullanici['isim'] . ' ' . $kullanici['soyisim']) ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>
        </form>
    </div>

    <?php if ($secili_kullanici_id): ?>
        <div class="content-container">
            <h4 class="mb-3">
                <i class="fas fa-history me-2"></i>
                Mesai Kayıtları
            </h4>
            
            <?php if (count($mesailer) > 0): ?>
                <div class="table-responsive">
                    <table class="table table-hover">
                        <thead>
                            <tr>
                                <th><i class="fas fa-hashtag me-2"></i>#</th>
                                <th><i class="fas fa-calendar me-2"></i>Başlangıç</th>
                                <th><i class="fas fa-calendar me-2"></i>Bitiş</th>
                                <th><i class="fas fa-clock me-2"></i>Toplam Süre</th>
                                <th><i class="fas fa-info-circle me-2"></i>Durum</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($mesailer as $index => $mesai): ?>
                                <tr>
                                    <td><strong><?= $index + 1 ?></strong></td>
                                    <td>
                                        <i class="fas fa-sign-in-alt me-1 text-success"></i>
                                        <?= date('d.m.Y H:i', strtotime($mesai['baslangic'])) ?>
                                    </td>
                                    <td>
                                        <?php if ($mesai['bitis']): ?>
                                            <i class="fas fa-sign-out-alt me-1 text-danger"></i>
                                            <?= date('d.m.Y H:i', strtotime($mesai['bitis'])) ?>
                                        <?php else: ?>
                                            <span class="badge badge-warning">
                                                <i class="fas fa-clock me-1"></i>
                                                Devam Ediyor
                                            </span>
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <?php
                                        if ($mesai['bitis']) {
                                            $baslangic = new DateTime($mesai['baslangic']);
                                            $bitis = new DateTime($mesai['bitis']);
                                            $fark = $bitis->diff($baslangic);
                                            $saat = $fark->h + ($fark->days * 24) + $fark->i/60;
                                            echo '<strong>' . number_format($saat, 2) . '</strong> saat';
                                        } else {
                                            echo '<span class="text-muted">-</span>';
                                        }
                                        ?>
                                    </td>
                                    <td>
                                        <?php if ($mesai['bitis']): ?>
                                            <span class="badge badge-success">
                                                <i class="fas fa-check me-1"></i>
                                                Tamamlandı
                                            </span>
                                        <?php else: ?>
                                            <span class="badge badge-primary">
                                                <i class="fas fa-play me-1"></i>
                                                Aktif
                                            </span>
                                        <?php endif; ?>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            <?php else: ?>
                <div class="text-center text-muted py-5">
                    <i class="fas fa-inbox fa-3x mb-3"></i>
                    <br>
                    <h5>Mesai Kaydı Bulunamadı</h5>
                    <p>Bu kullanıcı için henüz mesai kaydı bulunmamaktadır.</p>
                </div>
            <?php endif; ?>
        </div>
    <?php else: ?>
        <div class="content-container">
            <div class="text-center text-muted py-5">
                <i class="fas fa-user-clock fa-3x mb-3"></i>
                <br>
                <h5>Çalışan Seçin</h5>
                <p>Mesai kayıtlarını görüntülemek için yukarıdan bir çalışan seçin.</p>
            </div>
        </div>
    <?php endif; ?>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.6/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
