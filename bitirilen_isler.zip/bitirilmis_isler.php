<?php
session_start();

if (!isset($_SESSION['kullanici'])) {
    header("Location: giris.php");
    exit;
}

$kullanici = $_SESSION['kullanici'];

// Sadece "patron" rutbesine izin ver
if ($kullanici['rutbe'] !== 'patron') {
    http_response_code(403);
    echo "Bu sayfaya erişim yetkiniz yok.";
    exit;
}

// Veritabanı bağlantısı (kendi ayarlarına göre)
include 'baglan.php';

// Bitirilmiş işleri çek (durum = bitirildi)
$sql = "SELECT i.id, i.baslik, i.aciklama, i.baslama_tarihi, i.bitis_tarihi,
        b.dosya_adi, b.dosya_yolu, b.yukleme_tarihi
        FROM isler i
        LEFT JOIN bitmis_isler b ON i.id = b.is_id
        WHERE i.durum = 'bitirildi'
        ORDER BY i.bitis_tarihi DESC";

$stmt = $db->query($sql);
$bitirilmis_isler = $stmt->fetchAll(PDO::FETCH_ASSOC);

?>

<!doctype html>
<html lang="tr">
<head>
    <meta charset="UTF-8" />
    <title>Bitirilmiş İşler - Yönetici Paneli</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.6/dist/css/bootstrap.min.css" rel="stylesheet" />
</head>
<body>
<?php include 'parcalar/sidebar.php'; ?>
<?php include 'parcalar/navbar.php'; ?>

<div class="container mt-4" style="margin-left:250px;">
    <h3>Bitirilmiş İşler ve Yüklenen Dosyalar</h3>

    <?php if (count($bitirilmis_isler) === 0): ?>
        <p>Henüz bitirilmiş iş yok.</p>
    <?php else: ?>
        <table class="table table-bordered">
            <thead>
                <tr>
                    <th>Başlık</th>
                    <th>Açıklama</th>
                    <th>Başlama Tarihi</th>
                    <th>Bitiş Tarihi</th>
                    <th>Dosya Adı</th>
                    <th>Yükleme Tarihi</th>
                    <th>Dosya</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($bitirilmis_isler as $is): ?>
                    <tr>
                        <td><?= htmlspecialchars($is['baslik']) ?></td>
                        <td><?= htmlspecialchars($is['aciklama']) ?></td>
                        <td><?= $is['baslama_tarihi'] ?? '-' ?></td>
                        <td><?= $is['bitis_tarihi'] ?? '-' ?></td>
                        <td><?= htmlspecialchars($is['dosya_adi'] ?? '-') ?></td>
                        <td><?= $is['yukleme_tarihi'] ?? '-' ?></td>
                        <td>
                            <?php if (!empty($is['dosya_yolu'])): ?>
                                <a href="<?= htmlspecialchars($is['dosya_yolu']) ?>" target="_blank" class="btn btn-sm btn-primary">İndir/Görüntüle</a>
                            <?php else: ?>
                                -
                            <?php endif; ?>
                        </td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    <?php endif; ?>
</div>

</body>
</html>
