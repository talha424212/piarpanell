<?php
session_start();
require_once 'baglan.php';

header('Content-Type: application/json');

if (!isset($_SESSION['kullanici'])) {
    echo json_encode(['success' => false, 'message' => 'Oturum yok']);
    exit;
}

$kullanici_id = $_SESSION['kullanici']['id'];

$stmt = $db->prepare("UPDATE islerimler SET okundu = 1 WHERE kullanici_id = ?");
$sonuc = $stmt->execute([$kullanici_id]);

echo json_encode(['success' => $sonuc]);
