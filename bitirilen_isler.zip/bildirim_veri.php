<?php
session_start();
require_once 'baglan.php';
header('Content-Type: application/json');

if (!isset($_SESSION['kullanici']['id'])) {
    echo json_encode(['ok' => false, 'error' => 'Giriş gerekli.']); exit;
}
$kullanici_id = $_SESSION['kullanici']['id'];
$bildirimler = [];

try {
    // 1. GÖRÜLMEMİŞ İŞLERİ 'islerim' TABLOSUNDAN ÇEK
    $isler_sql = "SELECT id, baslik, atama_tarihi FROM islerim WHERE calisan_id = ? AND bildirim_goruldu = 0";
    $isler_stmt = $db->prepare($isler_sql);
    $isler_stmt->execute([$kullanici_id]);
    while ($is = $isler_stmt->fetch(PDO::FETCH_ASSOC)) {
        $bildirimler[] = [
            'tip'     => 'is',
            'baslik'  => $is['baslik'],
            'zaman'   => $is['atama_tarihi'],
            'link'    => 'islerim.php'
        ];
    }

    // 2. GÖRÜLMEMİŞ ETKİNLİKLERİ ÇEK
    $etkinlik_sql = "
        SELECT e.id, e.baslik, e.baslangic FROM etkinlikler e
        JOIN etkinlik_atananlar ea ON e.id = ea.etkinlik_id
        WHERE ea.kullanici_id = ? AND e.bildirim_goruldu = 0
    ";
    $etkinlik_stmt = $db->prepare($etkinlik_sql);
    $etkinlik_stmt->execute([$kullanici_id]);
    while ($etkinlik = $etkinlik_stmt->fetch(PDO::FETCH_ASSOC)) {
         $bildirimler[] = [
            'tip'     => 'etkinlik',
            'baslik'  => $etkinlik['baslik'],
            'zaman'   => $etkinlik['baslangic'],
            'link'    => 'is_takvimi.php'
        ];
    }

    // Bildirimleri zamana göre yeniden sırala (en yeni en üstte)
    usort($bildirimler, function($a, $b) {
        return strtotime($b['zaman']) - strtotime($a['zaman']);
    });

    echo json_encode(['ok' => true, 'bildirimler' => $bildirimler]);

} catch (Exception $e) {
    echo json_encode(['ok' => false, 'error' => 'Veritabanı hatası.']);
}
?>