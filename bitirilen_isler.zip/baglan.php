<?php
$host = 'localhost'; // cPanel MySQL sunucu adı
$dbname = 'isyonetimi_piarofis'; 
$user = 'isyonetimi_site'; 
$pass = 'wit@2024';

try {
    $db = new PDO("mysql:host=$host;dbname=$dbname;charset=utf8", $user, $pass, [
        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION
    ]);
} catch (PDOException $e) {
    echo "Bağlantı hatası: " . $e->getMessage();
}
