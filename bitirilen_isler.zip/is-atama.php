<?php
session_start();
require_once 'baglan.php';

if (!isset($_SESSION['kullanici'])) {
  header('Location: giris.php');
  exit;
}
$kullanici = $_SESSION['kullanici'];
$kullanici_id = $kullanici['id'];
$kullanici_rutbe = $kullanici['rutbe'] ?? 'calisan';
$mesaj = "";

$db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['is_ekle'])) {
  if (in_array($kullanici_rutbe, ['patron'])) {

    $baslik = trim($_POST['baslik'] ?? '');
    $aciklama = trim($_POST['aciklama'] ?? '');
    $calisan_id_tek = $_POST['calisan_id'] ?? null;
    $oncelik = $_POST['oncelik'] ?? 'Orta';

    $baslangic_tarihi_str = $_POST['baslangic_tarihi'] ?? null;
    $bitis_tarihi_str = $_POST['bitis_tarihi'] ?? null;

    if (empty($baslik) || empty($calisan_id_tek) || empty($baslangic_tarihi_str) || empty($bitis_tarihi_str)) {
        $mesaj = "Başlık, atanacak kişi, başlangıç ve bitiş tarihi alanları zorunludur.";
    } elseif (strtotime($baslangic_tarihi_str) >= strtotime($bitis_tarihi_str)) {
        $mesaj = "Bitiş tarihi, başlangıç tarihinden sonra olmalıdır.";
    } else {
      try {
          $db->beginTransaction();

          $stmt_is = $db->prepare(
            "INSERT INTO islerim (baslik, aciklama, calisan_id, patron_id, oncelik, baslama_tarihi, bitis_tarihi, durum, atama_tarihi, bildirim_goruldu) 
             VALUES (?, ?, ?, ?, ?, ?, ?, 'verildi', NOW(), 0)"
          );
          $stmt_is->execute([$baslik, $aciklama, $calisan_id_tek, $kullanici_id, $oncelik, $baslangic_tarihi_str, $bitis_tarihi_str]);

          $etkinlik_baslangic = $baslangic_tarihi_str . ' 09:00:00';
          $etkinlik_bitis = $bitis_tarihi_str . ' 18:00:00';
          $etkinlik_aciklama = "İş Atama'dan oluşturuldu. Öncelik: {$oncelik}.";

          $stmt_etkinlik = $db->prepare("INSERT INTO etkinlikler (baslik, aciklama, baslangic, bitis, bildirim_goruldu) VALUES (?, ?, ?, ?, 0)");
          $stmt_etkinlik->execute([$baslik, $etkinlik_aciklama, $etkinlik_baslangic, $etkinlik_bitis]);
          $yeni_etkinlik_id = $db->lastInsertId();

          $stmt_atanan = $db->prepare("INSERT INTO etkinlik_atananlar (etkinlik_id, kullanici_id) VALUES (?, ?)");
          $stmt_atanan->execute([$yeni_etkinlik_id, $calisan_id_tek]);

          $db->commit();
          $mesaj = "İş başarıyla atandı ve takvime eklendi!";

      } catch (Exception $e) {
          $db->rollBack();
          $mesaj = "Hata oluştu: " . $e->getMessage();
      }
    }
  } else {
    $mesaj = "Bu işlemi yapma yetkiniz yok.";
  }
}

if (isset($_POST['durum_guncelle'])) {
  $is_id = $_POST['is_id'];
  $yeni_durum = $_POST['yeni_durum'];
  $stmt_guncelle = $db->prepare("UPDATE islerim SET durum = ? WHERE id = ? AND calisan_id = ?");
  $stmt_guncelle->execute([$yeni_durum, $is_id, $kullanici_id]);
  $mesaj = "İş durumu güncellendi!";
}

if (isset($_GET['sil_id']) && $kullanici_rutbe === 'patron') {
  $sil_id = $_GET['sil_id'];
  $stmt_sil = $db->prepare("DELETE FROM islerim WHERE id = ?");
  $stmt_sil->execute([$sil_id]);
  header("Location: is_atama.php?mesaj=silindi");
  exit;
}

$calisanlar = [];
if ($kullanici_rutbe === 'patron') {
  $calisanlar = $db->query("SELECT id, isim, soyisim, rutbe FROM kullanicilar ORDER BY isim")->fetchAll(PDO::FETCH_ASSOC);
}

$sql_isler = "SELECT i.*, k.isim, k.soyisim FROM islerim i JOIN kullanicilar k ON i.calisan_id = k.id";
if ($kullanici_rutbe !== 'patron') {
  $sql_isler .= " WHERE i.calisan_id = :kullanici_id";
}
$sql_isler .= " ORDER BY i.atama_tarihi DESC";
$stmt_isler = $db->prepare($sql_isler);
if ($kullanici_rutbe !== 'patron') {
  $stmt_isler->bindParam(':kullanici_id', $kullanici_id);
}
$stmt_isler->execute();
$isler = $stmt_isler->fetchAll(PDO::FETCH_ASSOC);

$istat = array_fill_keys(['verildi', 'baslandi', 'durduruldu', 'bitirildi', 'iptal'], 0);
foreach ($isler as $is) {
  if (isset($istat[$is['durum']])) {
    $istat[$is['durum']]++;
  }
}
$toplam_is = count($isler);

if(isset($_GET['mesaj']) && $_GET['mesaj'] == 'silindi' && empty($mesaj)) {
  $mesaj = "İş başarıyla silindi!";
}
?>
<!DOCTYPE html>
<html lang="tr">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <title>İş Atama - Piar Panel</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.6/dist/css/bootstrap.min.css" rel="stylesheet" />
  <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet" />
  <style>
    :root {
      --primary-gradient: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
      --secondary-gradient: linear-gradient(135deg, #f093fb 0%, #f5576c 100%);
      --success-gradient: linear-gradient(135deg, #4facfe 0%, #00f2fe 100%);
      --warning-gradient: linear-gradient(135deg, #43e97b 0%, #38f9d7 100%);
      --danger-gradient: linear-gradient(135deg, #fa709a 0%, #fee140 100%);
      --glass-bg: rgba(255, 255, 255, 0.1);
      --glass-border: rgba(255, 255, 255, 0.2);
    }
    body {
      background: var(--primary-gradient);
      min-height: 100vh;
      font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
      overflow-x: hidden;
      position: relative;
      margin: 30px;
      color: white;
    }
    .main-container {
      margin-left: 0;
      padding-top: 20px;
      padding-bottom: 40px;
      max-width: 1200px;
      margin-left: auto;
      margin-right: auto;
    }
    .page-header {
      background: var(--glass-bg);
      backdrop-filter: blur(20px);
      border: 1px solid var(--glass-border);
      border-radius: 20px;
      padding: 30px;
      margin-bottom: 30px;
      box-shadow: 0 8px 32px rgba(0, 0, 0, 0.1);
      text-align: center;
    }
    .page-title {
      font-size: 2.5rem;
      font-weight: 700;
      margin: 0;
      text-shadow: 0 2px 4px rgba(0, 0, 0, 0.3);
    }
    .page-subtitle {
      font-size: 1.1rem;
      margin: 10px 0 0 0;
      color: rgba(255, 255, 255, 0.8);
    }
    .stats-container {
      display: flex;
      gap: 20px;
      justify-content: center;
      margin-bottom: 30px;
      flex-wrap: wrap;
    }
    .stat-card {
      flex: 1 1 180px;
      background: var(--glass-bg);
      backdrop-filter: blur(20px);
      border: 1px solid var(--glass-border);
      border-radius: 20px;
      padding: 25px;
      text-align: center;
      box-shadow: 0 8px 32px rgba(0, 0, 0, 0.1);
      transition: all 0.3s ease;
      color: white;
      min-width: 180px;
    }
    .stat-card:hover {
      transform: translateY(-5px);
      box-shadow: 0 15px 40px rgba(0, 0, 0, 0.2);
    }
    .stat-icon {
      font-size: 2rem;
      margin-bottom: 10px;
      display: inline-block;
      width: 50px;
      height: 50px;
      line-height: 50px;
      border-radius: 50%;
      color: white;
    }
    .stat-card:nth-child(1) .stat-icon {
      background: var(--warning-gradient);
    }
    .stat-card:nth-child(2) .stat-icon {
      background: var(--success-gradient);
    }
    .stat-card:nth-child(3) .stat-icon {
      background: var(--danger-gradient);
    }
    .stat-card:nth-child(4) .stat-icon {
      background: var(--primary-gradient);
    }
    .stat-number {
      font-size: 2rem;
      font-weight: 700;
      margin-bottom: 5px;
    }
    .stat-label {
      font-size: 1rem;
      font-weight: 600;
      color: rgba(255, 255, 255, 0.8);
    }
    .content-container {
      background: var(--glass-bg);
      backdrop-filter: blur(20px);
      border: 1px solid var(--glass-border);
      border-radius: 20px;
      padding: 30px;
      margin-bottom: 30px;
      box-shadow: 0 8px 32px rgba(0, 0, 0, 0.1);
    }
    .section-title {
      font-size: 1.5rem;
      font-weight: 600;
      margin-bottom: 25px;
      display: flex;
      align-items: center;
      gap: 10px;
      color: white;
    }
    .btn-modern {
      background: var(--glass-bg);
      backdrop-filter: blur(20px);
      border: 1px solid var(--glass-border);
      color: white;
      padding: 10px 20px;
      border-radius: 15px;
      font-weight: 600;
      transition: all 0.3s ease;
      text-decoration: none;
      display: inline-flex;
      align-items: center;
      gap: 8px;
      cursor: pointer;
      border: none;
    }
    .btn-modern:hover {
      background: rgba(255, 255, 255, 0.2);
      color: white;
      transform: translateY(-2px);
      box-shadow: 0 5px 15px rgba(0, 0, 0, 0.2);
    }
    .btn-success-modern {
      background: var(--success-gradient);
      border: none;
    }
    .btn-danger-modern {
      background: var(--danger-gradient);
      border: none;
    }
    .form-control,
    .form-select {
      background: var(--glass-bg);
      backdrop-filter: blur(20px);
      border: 1px solid var(--glass-border);
      color: white;
      border-radius: 15px;
      padding: 10px 15px;
      font-size: 1rem;
    }
    .form-control:focus,
    .form-select:focus {
      background: rgba(255, 255, 255, 0.15);
      border-color: rgba(255, 255, 255, 0.5);
      color: white;
      box-shadow: 0 0 0 0.2rem rgba(255, 255, 255, 0.25);
      outline: none;
    }
    .form-label {
      color: white;
      font-weight: 600;
      margin-bottom: 8px;
      display: inline-block;
    }
    .table-modern {
      background: var(--glass-bg);
      backdrop-filter: blur(20px);
      border: 1px solid var(--glass-border);
      border-radius: 20px;
      overflow: hidden;
      box-shadow: 0 8px 32px rgba(0, 0, 0, 0.08);
      width: 100%;
      color: white;
    }
    .table-modern th {
      background: rgba(255, 255, 255, 0.15);
      color: #fff;
      font-weight: 700;
      padding: 15px;
      font-size: 1.05rem;
      text-align: left;
    }
    .table-modern td {
      padding: 15px;
      vertical-align: middle;
      font-size: 1rem;
      background: rgba(255, 255, 255, 0.07);
      border-top: 1px solid rgba(255, 255, 255, 0.1);
    }
    .table-modern tbody tr:nth-child(even) td {
      background: rgba(255, 255, 255, 0.12);
    }
    .table-modern tbody tr:hover td {
      background: rgba(102, 126, 234, 0.18);
      box-shadow: 0 2px 16px rgba(102, 126, 234, 0.10);
      transition: background 0.2s;
    }
    .priority-badge {
      padding: 6px 14px;
      border-radius: 16px;
      font-size: 0.9rem;
      font-weight: 600;
      display: inline-block;
      color: white;
      text-align: center;
      min-width: 70px;
    }
    .priority-low {
      background: linear-gradient(90deg, #2ed573, #1eae98);
    }
    .priority-medium {
      background: linear-gradient(90deg, #ffa502, #fffa65);
      color: #222;
    }
    .priority-high {
      background: linear-gradient(90deg, #ff4757, #ff6b81);
    }
    .status-badge {
      padding: 6px 14px;
      border-radius: 16px;
      font-size: 0.9rem;
      font-weight: 600;
      color: white;
      text-align: center;
      display: inline-block;
      min-width: 90px;
      text-shadow: 0 1px 2px #0002;
    }
    .status-verildi {
      background: linear-gradient(90deg, #43e97b, #38f9d7);
    }
    .status-baslandi {
      background: linear-gradient(90deg, #667eea, #764ba2);
    }
    .status-durduruldu {
      background: linear-gradient(90deg, #fa709a, #fee140);
      color: #222;
    }
    .status-bitirildi {
      background: linear-gradient(90deg, #4facfe, #00f2fe);
    }
    .status-iptal {
      background: #888;
    }
    .avatar-circle {
      width: 36px;
      height: 36px;
      border-radius: 50%;
      background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
      color: #fff;
      display: flex;
      align-items: center;
      justify-content: center;
      font-weight: 700;
      font-size: 1.1rem;
      box-shadow: 0 2px 8px rgba(102, 126, 234, 0.15);
      text-transform: uppercase;
    }
    .text-center {
      text-align: center;
    }
    .mb-15 {
      margin-bottom: 15px;
    }
  </style>
          <style>select{ background: #000 !important; color: #fff !important; border-color: #444 !important; }</style>';

</head>
<body>
    
    <?php   include"parcalar/navbar.php"; ?>
    <?php   include"parcalar/sidebar.php"; ?>
    
  <div class="main-container">
    <header class="page-header">
      <h1 class="page-title"><i class="fa-solid fa-clipboard-list me-3"></i>İş Atama</h1>
      <p class="page-subtitle">Görevlerinizi buradan yönetebilirsiniz.</p>
      <?php if (!empty($mesaj)): ?>
        <div class="alert alert-info mt-3"><?=htmlspecialchars($mesaj)?></div>
      <?php endif; ?>
    </header>

    <section class="stats-container">
      <div class="stat-card">
        <div class="stat-icon"><i class="fa-solid fa-paper-plane"></i></div>
        <div class="stat-number"><?= $istat['verildi'] ?></div>
        <div class="stat-label">Verilen İş</div>
      </div>
      <div class="stat-card">
        <div class="stat-icon"><i class="fa-solid fa-play"></i></div>
        <div class="stat-number"><?= $istat['baslandi'] ?></div>
        <div class="stat-label">Başlanan</div>
      </div>
      <div class="stat-card">
        <div class="stat-icon"><i class="fa-solid fa-pause"></i></div>
        <div class="stat-number"><?= $istat['durduruldu'] ?></div>
        <div class="stat-label">Durdurulan</div>
      </div>
      <div class="stat-card">
        <div class="stat-icon"><i class="fa-solid fa-check"></i></div>
        <div class="stat-number"><?= $istat['bitirildi'] ?></div>
        <div class="stat-label">Bitirilen</div>
      </div>
    </section>

    <?php if ($kullanici_rutbe === 'patron'): ?>
    <section class="content-container">
      <h2 class="section-title"><i class="fa-solid fa-plus-circle me-2"></i>Yeni İş Ekle</h2>
      <form method="POST" action="">
        <div class="mb-3">
          <label for="baslik" class="form-label">Başlık *</label>
          <input type="text" class="form-control" id="baslik" name="baslik" required>
        </div>
        <div class="mb-3">
          <label for="aciklama" class="form-label">Açıklama</label>
          <textarea class="form-control" id="aciklama" name="aciklama" rows="3"></textarea>
        </div>
        <div class="mb-3">
          <label for="calisan_id" class="form-label">Atanacak Kişi *</label>
          <select class="form-select" id="calisan_id" name="calisan_id" required>
            <option value="">Seçiniz...</option>
            <?php foreach($calisanlar as $calisan): ?>
              <option value="<?= $calisan['id'] ?>"><?= htmlspecialchars($calisan['isim'] . ' ' . $calisan['soyisim']) ?> (<?= $calisan['rutbe'] ?>)</option>
            <?php endforeach; ?>
          </select>
        </div>
        <div class="mb-3">
          <label for="oncelik" class="form-label">Öncelik</label>
          <select class="form-select" id="oncelik" name="oncelik">
            <option value="Düşük">Düşük</option>
            <option value="Orta" selected>Orta</option>
            <option value="Yüksek">Yüksek</option>
          </select>
        </div>
        <div class="mb-3 row">
          <div class="col-md-6">
            <label for="baslangic_tarihi" class="form-label">Başlangıç Tarihi *</label>
            <input type="date" class="form-control" id="baslangic_tarihi" name="baslangic_tarihi" required>
          </div>
          <div class="col-md-6">
            <label for="bitis_tarihi" class="form-label">Bitiş Tarihi *</label>
            <input type="date" class="form-control" id="bitis_tarihi" name="bitis_tarihi" required>
          </div>
        </div>
        <button type="submit" name="is_ekle" class="btn btn-success btn-modern"><i class="fa-solid fa-check me-2"></i>İşi Ekle</button>
      </form>
    </section>
    <?php endif; ?>

    <section class="content-container">
      <h2 class="section-title"><i class="fa-solid fa-list me-2"></i>Mevcut İşler (<?= $toplam_is ?>)</h2>
      <div class="table-responsive">
        <table class="table-modern table">
          <thead>
            <tr>
              <th>Başlık</th>
              <th>Açıklama</th>
              <th>Atanan</th>
              <th>Öncelik</th>
              <th>Başlangıç</th>
              <th>Bitiş</th>
              <th>Durum</th>
              <?php if($kullanici_rutbe === 'patron'): ?>
              <th>İşlem</th>
              <?php else: ?>
              <th>Durum Güncelle</th>
              <?php endif; ?>
            </tr>
          </thead>
          <tbody>
          <?php if (empty($isler)): ?>
            <tr>
              <td colspan="<?= $kullanici_rutbe === 'patron' ? 8 : 8 ?>" class="text-center">Kayıt bulunamadı.</td>
            </tr>
          <?php else: foreach ($isler as $is): ?>
            <tr>
              <td><?= htmlspecialchars($is['baslik']) ?></td>
              <td><?= nl2br(htmlspecialchars($is['aciklama'])) ?></td>
              <td>
                <div class="avatar-circle" title="<?= htmlspecialchars($is['isim'] . ' ' . $is['soyisim']) ?>">
                  <?= mb_substr($is['isim'],0,1) . mb_substr($is['soyisim'],0,1) ?>
                </div>
              </td>
              <td>
                <?php
                  $priorityClass = 'priority-medium';
                  if ($is['oncelik'] === 'Düşük') $priorityClass = 'priority-low';
                  else if ($is['oncelik'] === 'Yüksek') $priorityClass = 'priority-high';
                ?>
                <span class="priority-badge <?= $priorityClass ?>"><?= htmlspecialchars($is['oncelik']) ?></span>
              </td>
              <td><?= htmlspecialchars($is['baslama_tarihi']) ?></td>
              <td><?= htmlspecialchars($is['bitis_tarihi']) ?></td>
              <td>
                <?php
                $durumClassMap = [
                  'verildi' => 'status-verildi',
                  'baslandi' => 'status-baslandi',
                  'durduruldu' => 'status-durduruldu',
                  'bitirildi' => 'status-bitirildi',
                  'iptal' => 'status-iptal',
                ];
                $durumClass = $durumClassMap[$is['durum']] ?? 'status-iptal';
                ?>
                <span class="status-badge <?= $durumClass ?>"><?= htmlspecialchars(ucfirst($is['durum'])) ?></span>
              </td>
              <?php if($kullanici_rutbe === 'patron'): ?>
              <td>
                <a href="?sil_id=<?= $is['id'] ?>" class="btn btn-danger btn-modern btn-sm" onclick="return confirm('İşi silmek istediğinize emin misiniz?')">
                  <i class="fa-solid fa-trash"></i>
                </a>
              </td>
              <?php else: ?>
              <td>
                <form method="POST" action="" style="display:inline-flex;gap:6px;align-items:center;">
                  <input type="hidden" name="is_id" value="<?= $is['id'] ?>">
                  <select name="yeni_durum" class="form-select form-select-sm" style="width:auto; min-width:120px;" onchange="this.form.submit()">
                    <option value="verildi" <?= $is['durum']=='verildi' ? 'selected' : '' ?>>Verildi</option>
                    <option value="baslandi" <?= $is['durum']=='baslandi' ? 'selected' : '' ?>>Başlandı</option>
                    <option value="durduruldu" <?= $is['durum']=='durduruldu' ? 'selected' : '' ?>>Durduruldu</option>
                    <option value="bitirildi" <?= $is['durum']=='bitirildi' ? 'selected' : '' ?>>Bitirildi</option>
                    <option value="iptal" <?= $is['durum']=='iptal' ? 'selected' : '' ?>>İptal</option>
                  </select>
                  <button type="submit" name="durum_guncelle" class="btn btn-success btn-modern btn-sm" title="Güncelle"><i class="fa-solid fa-check"></i></button>
                </form>
              </td>
              <?php endif; ?>
            </tr>
          <?php endforeach; endif; ?>
          </tbody>
        </table>
      </div>
    </section>
  </div>
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.6/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
