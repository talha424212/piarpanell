<?php
session_start();

if (!isset($_SESSION['kullanici'])) {
    header("Location: giris.php"); // Giriş ekranına yönlendir
    exit;
}
?>


