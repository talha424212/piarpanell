<?php
session_start();
require_once 'baglan.php';
header('Content-Type: application/json');

if(!isset($_SESSION['kullanici'])){
  echo json_encode(['ok'=>false, 'hata'=>'Yetkisiz erişim']);
  exit;
}

$id = $_POST['id'] ?? '';
if(!$id){
  echo json_encode(['ok'=>false, 'hata'=>'ID belirtilmedi']);
  exit;
}

try{
  $stmt = $db->prepare("DELETE FROM etkinlikler WHERE id = ?");
  $stmt->execute([$id]);
  echo json_encode(['ok'=>true]);
}catch(PDOException $e){
  echo json_encode(['ok'=>false, 'hata'=>$e->getMessage()]);
}
