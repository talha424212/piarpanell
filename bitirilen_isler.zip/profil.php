<?php
session_start();
if (!isset($_SESSION['kullanici'])) {
    header("Location: giris.php");
    exit;
}

require_once 'baglan.php';

$kullanici_id = $_SESSION['kullanici']['id'];
$sorgu = $db->prepare("SELECT * FROM kullanicilar WHERE id = ?");
$sorgu->execute([$kullanici_id]);
$kullanici = $sorgu->fetch(PDO::FETCH_ASSOC);

if (!$kullanici) {
    // Kullanıcı bulunamazsa oturumu sonlandır ve girişe yönlendir
    session_destroy();
    header("Location: giris.php");
    exit;
}
?>

<!doctype html>
<html lang="tr">
<head>
  <meta charset="UTF-8">
  <title>Profil Bilgileri - Piar Panel</title>
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.6/dist/css/bootstrap.min.css" rel="stylesheet">
  <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet" />
  <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap" rel="stylesheet" />
  <style>
    * {
      font-family: 'Inter', sans-serif;
    }
    
    body {
      background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
      min-height: 100vh;
      position: relative;
    }
    
    body::before {
      content: '';
      position: fixed;
      top: 0;
      left: 0;
      width: 100%;
      height: 100%;
      background: url('data:image/svg+xml,<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 100 100"><defs><pattern id="grain" width="100" height="100" patternUnits="userSpaceOnUse"><circle cx="25" cy="25" r="1" fill="rgba(255,255,255,0.1)"/><circle cx="75" cy="75" r="1" fill="rgba(255,255,255,0.1)"/><circle cx="50" cy="10" r="0.5" fill="rgba(255,255,255,0.1)"/><circle cx="10" cy="60" r="0.5" fill="rgba(255,255,255,0.1)"/><circle cx="90" cy="40" r="0.5" fill="rgba(255,255,255,0.1)"/></pattern></defs><rect width="100" height="100" fill="url(%23grain)"/></svg>');
      pointer-events: none;
      z-index: -1;
    }
    
    .main-content {
      margin-left: 280px;
      padding: 2rem;
      min-height: 100vh;
    }
    
    .page-header {
      background: rgba(255, 255, 255, 0.1);
      backdrop-filter: blur(20px);
      border-radius: 20px;
      padding: 2rem;
      margin-bottom: 2rem;
      border: 1px solid rgba(255, 255, 255, 0.2);
      box-shadow: 0 8px 32px rgba(0, 0, 0, 0.1);
    }
    
    .page-title {
      color: white;
      font-weight: 700;
      font-size: 2.5rem;
      margin: 0;
      text-shadow: 0 2px 4px rgba(0, 0, 0, 0.3);
      display: flex;
      align-items: center;
      gap: 1rem;
    }
    
    .page-subtitle {
      color: rgba(255, 255, 255, 0.8);
      font-weight: 400;
      margin: 0.5rem 0 0 0;
      font-size: 1.1rem;
    }
    
    .content-container {
      background: rgba(255, 255, 255, 0.95);
      backdrop-filter: blur(20px);
      border-radius: 20px;
      padding: 2rem;
      box-shadow: 0 20px 40px rgba(0, 0, 0, 0.1);
      border: 1px solid rgba(255, 255, 255, 0.2);
      transition: transform 0.3s ease, box-shadow 0.3s ease;
      margin-bottom: 2rem;
    }
    
    .content-container:hover {
      transform: translateY(-5px);
      box-shadow: 0 25px 50px rgba(0, 0, 0, 0.15);
    }
    
    .profile-card {
      background: rgba(255, 255, 255, 0.9);
      border-radius: 15px;
      border: none;
      box-shadow: 0 8px 25px rgba(0, 0, 0, 0.1);
      transition: all 0.3s ease;
      overflow: hidden;
    }
    
    .profile-card:hover {
      transform: translateY(-5px);
      box-shadow: 0 15px 35px rgba(0, 0, 0, 0.15);
    }
    
    .profile-header {
      background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
      color: white;
      border: none;
      padding: 1.5rem;
      font-weight: 600;
      font-size: 1.2rem;
    }
    
    .profile-body {
      padding: 1.5rem;
    }
    
    .profile-info {
      display: flex;
      align-items: center;
      padding: 1rem;
      margin-bottom: 1rem;
      background: rgba(102, 126, 234, 0.05);
      border-radius: 10px;
      border-left: 4px solid #667eea;
      transition: all 0.3s ease;
    }
    
    .profile-info:hover {
      background: rgba(102, 126, 234, 0.1);
      transform: translateX(5px);
    }
    
    .profile-icon {
      width: 50px;
      height: 50px;
      background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
      border-radius: 50%;
      display: flex;
      align-items: center;
      justify-content: center;
      color: white;
      font-size: 1.2rem;
      margin-right: 1rem;
    }
    
    .profile-details h5 {
      margin: 0;
      color: #2c3e50;
      font-weight: 600;
    }
    
    .profile-details p {
      margin: 0;
      color: #6c757d;
      font-size: 0.9rem;
    }
    
    .btn {
      border-radius: 10px;
      font-weight: 500;
      padding: 0.75rem 1.5rem;
      transition: all 0.3s ease;
      border: none;
      display: inline-flex;
      align-items: center;
      gap: 0.5rem;
    }
    
    .btn:hover {
      transform: translateY(-2px);
      box-shadow: 0 5px 15px rgba(0, 0, 0, 0.2);
    }
    
    .btn-primary {
      background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
    }
    
    .btn-warning {
      background: linear-gradient(135deg, #ffc107 0%, #fd7e14 100%);
    }
    
    .form-control {
      border-radius: 10px;
      border: 2px solid #e9ecef;
      padding: 0.75rem;
      transition: all 0.3s ease;
    }
    
    .form-control:focus {
      border-color: #667eea;
      box-shadow: 0 0 0 0.2rem rgba(102, 126, 234, 0.25);
    }
    
    .stats-cards {
      display: grid;
      grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
      gap: 1.5rem;
      margin-bottom: 2rem;
    }
    
    .stat-card {
      background: rgba(255, 255, 255, 0.1);
      backdrop-filter: blur(20px);
      border-radius: 15px;
      padding: 1.5rem;
      border: 1px solid rgba(255, 255, 255, 0.2);
      box-shadow: 0 8px 32px rgba(0, 0, 0, 0.1);
      transition: all 0.3s ease;
      color: white;
      text-align: center;
    }
    
    .stat-card:hover {
      transform: translateY(-5px);
      box-shadow: 0 15px 40px rgba(0, 0, 0, 0.2);
    }
    
    .stat-icon {
      font-size: 2rem;
      margin-bottom: 1rem;
      opacity: 0.9;
    }
    
    .stat-number {
      font-size: 1.8rem;
      font-weight: 700;
      margin-bottom: 0.5rem;
    }
    
    .stat-label {
      font-size: 0.9rem;
      opacity: 0.8;
      font-weight: 500;
    }
    
    @media (max-width: 768px) {
      .main-content {
        margin-left: 0;
        padding: 1rem;
      }
      
      .page-title {
        font-size: 2rem;
      }
      
      .stats-cards {
        grid-template-columns: 1fr;
      }
    }
  </style>
</head>
<body>

<?php include 'parcalar/sidebar.php'; ?>
<?php include 'parcalar/navbar.php'; ?>

<div class="main-content">
  <div class="page-header">
    <h1 class="page-title">
      <i class="fas fa-user"></i>
      Profil Bilgileri
    </h1>
    <p class="page-subtitle">Kişisel bilgilerinizi görüntüleyin ve yönetin</p>
  </div>

  <div class="stats-cards">
    <div class="stat-card">
      <div class="stat-icon">
        <i class="fas fa-user-circle"></i>
      </div>
      <div class="stat-number"><?= htmlspecialchars($kullanici['isim'] ?? 'Kullanıcı') ?></div>
      <div class="stat-label">Hoş Geldiniz</div>
    </div>
    <div class="stat-card">
      <div class="stat-icon">
        <i class="fas fa-envelope"></i>
      </div>
      <div class="stat-number"><?= htmlspecialchars($kullanici['mail'] ?? 'E-posta yok') ?></div>
      <div class="stat-label">E-posta</div>
    </div>
    <div class="stat-card">
      <div class="stat-icon">
        <i class="fas fa-crown"></i>
      </div>
      <div class="stat-number"><?= htmlspecialchars($kullanici['rutbe'] ?? 'Belirsiz') ?></div>
      <div class="stat-label">Rütbe</div>
    </div>
    <div class="stat-card">
      <div class="stat-icon">
        <i class="fas fa-calendar-alt"></i>
      </div>
      <div class="stat-number"><?= date('d.m.Y') ?></div>
      <div class="stat-label">Bugün</div>
    </div>
  </div>

  <div class="content-container">
    <div class="profile-card">
      <div class="profile-header">
        <i class="fas fa-user-circle me-2"></i>
        Kişisel Bilgiler
      </div>
      <div class="profile-body">
        <div class="profile-info">
          <div class="profile-icon">
            <i class="fas fa-envelope"></i>
          </div>
          <div class="profile-details">
            <h5>E-posta Adresi</h5>
            <p><?= htmlspecialchars($kullanici['email'] ?? '') ?></p>
          </div>
        </div>
        
        <div class="profile-info">
          <div class="profile-icon">
            <i class="fas fa-user"></i>
          </div>
          <div class="profile-details">
            <h5>Ad Soyad</h5>
            <p><?= htmlspecialchars(($kullanici['isim'] ?? '') . ' ' . ($kullanici['soyisim'] ?? '')) ?></p>
          </div>
        </div>
        
        <div class="profile-info">
          <div class="profile-icon">
            <i class="fas fa-crown"></i>
          </div>
          <div class="profile-details">
            <h5>Rütbe</h5>
            <p><?= htmlspecialchars($kullanici['rutbe']) ?></p>
          </div>
        </div>
        
        <?php if (isset($kullanici['numara']) && !empty($kullanici['numara'])): ?>
        <div class="profile-info">
          <div class="profile-icon">
            <i class="fas fa-phone"></i>
          </div>
          <div class="profile-details">
            <h5>Telefon Numarası</h5>
            <p><?= htmlspecialchars($kullanici['numara']) ?></p>
          </div>
        </div>
        <?php endif; ?>
        
        <div class="profile-info">
          <div class="profile-icon">
            <i class="fas fa-calendar"></i>
          </div>
          <div class="profile-details">
            <h5>Kayıt Tarihi</h5>
            <p><?= isset($kullanici['kayit_tarihi']) ? date('d.m.Y', strtotime($kullanici['kayit_tarihi'])) : 'Belirtilmemiş' ?></p>
          </div>
        </div>
      </div>
    </div>
  </div>

  <div class="content-container">
    <div class="profile-card">
      <div class="profile-header">
        <i class="fas fa-cog me-2"></i>
        Hesap Ayarları
      </div>
      <div class="profile-body">
        <div class="row">
          <div class="col-md-6 mb-3">
            <button class="btn btn-warning w-100" data-bs-toggle="modal" data-bs-target="#sifreModal">
              <i class="fas fa-key"></i>
              Şifre Değiştir
            </button>
          </div>
          <div class="col-md-6 mb-3">
            <button class="btn btn-primary w-100" data-bs-toggle="modal" data-bs-target="#profilModal">
              <i class="fas fa-edit"></i>
              Profil Düzenle
            </button>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>

<!-- Şifre Değiştirme Modal -->
<div class="modal fade" id="sifreModal" tabindex="-1" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title">
          <i class="fas fa-key me-2"></i>
          Şifre Değiştir
        </h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
      </div>
      <form>
        <div class="modal-body">
          <div class="mb-3">
            <label class="form-label">
              <i class="fas fa-lock me-2"></i>
              Mevcut Şifre
            </label>
            <input type="password" class="form-control" required>
          </div>
          <div class="mb-3">
            <label class="form-label">
              <i class="fas fa-lock me-2"></i>
              Yeni Şifre
            </label>
            <input type="password" class="form-control" required>
          </div>
          <div class="mb-3">
            <label class="form-label">
              <i class="fas fa-lock me-2"></i>
              Yeni Şifre (Tekrar)
            </label>
            <input type="password" class="form-control" required>
          </div>
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">İptal</button>
          <button type="submit" class="btn btn-primary">
            <i class="fas fa-save me-1"></i>
            Kaydet
          </button>
        </div>
      </form>
    </div>
  </div>
</div>

<!-- Profil Düzenleme Modal -->
<div class="modal fade" id="profilModal" tabindex="-1" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title">
          <i class="fas fa-edit me-2"></i>
          Profil Düzenle
        </h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
      </div>
      <form>
        <div class="modal-body">
          <div class="mb-3">
            <label class="form-label">
              <i class="fas fa-user me-2"></i>
              Ad
            </label>
            <input type="text" class="form-control" value="<?= htmlspecialchars($kullanici['isim']) ?>" required>
          </div>
          <div class="mb-3">
            <label class="form-label">
              <i class="fas fa-user me-2"></i>
              Soyad
            </label>
            <input type="text" class="form-control" value="<?= htmlspecialchars($kullanici['soyisim']) ?>" required>
          </div>
          <div class="mb-3">
            <label class="form-label">
              <i class="fas fa-envelope me-2"></i>
              E-posta
            </label>
            <input type="email" class="form-control" value="<?= htmlspecialchars($kullanici['email'] ?? '') ?>" required>
          </div>
          <div class="mb-3">
            <label class="form-label">
              <i class="fas fa-phone me-2"></i>
              Telefon
            </label>
            <input type="tel" class="form-control" value="<?= htmlspecialchars($kullanici['numara'] ?? '') ?>">
          </div>
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">İptal</button>
          <button type="submit" class="btn btn-primary">
            <i class="fas fa-save me-1"></i>
            Kaydet
          </button>
        </div>
      </form>
    </div>
  </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.6/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
